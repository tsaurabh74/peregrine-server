var cmpThemecleanComponentsHeader = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  var script = {
    props: ['model'],
    mounted: function mounted() {
      $('body').scrollspy({target: '.navbar'});
      $('.nav-link').click(function (e) {
        $('.navbar-collapse').collapse('hide');
      });
    },
    computed: {
      isEditAndEmpty: function isEditAndEmpty() {
        if (!$peregrineApp.isAuthorMode()) {
          return false
        }
        return this.$helper.areAllEmpty(this.model.logo, this.model.links, this.model.buttons)
      }
    },
    created: function created() {
      this.$root.$on('block.mounted', this.onBlockMountede);
    },
    methods: {
      onBlockMounted: function onBlockMounted() {
        // Add top margin to perApp to account for fixed header when sticky is true
        if( this.model.sticky === 'true' && !$peregrineApp.isAuthorMode()) {
          if( this.$refs.section.style.position === 'fixed' ){
            var height = this.$refs.section.clientHeight;
            this.$refs.section.parentElement.style.marginTop = height + 'px';
          }
        }
        var navSection = this.$refs.nav.parentElement.parentElement.parentElement;
        var navPosition = navSection.style.position;
        var navSticky = navPosition === "sticky" || navPosition === "fixed";
        var navOffset = navSticky ? navSection.clientHeight : 0;

        navSection.style.top = "0px";
        navSection.style.marginTop = "-" + navOffset + "px";
        navSection.style.paddingTop = navOffset + "px";
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "themeclean-components-block",
      { attrs: { model: _vm.model }, on: { mounted: _vm.onBlockMounted } },
      [
        _c(
          "nav",
          {
            ref: "nav",
            staticClass: "navbar align-items-center navbar-light w-100",
            class: {
              "navbar-expand-lg": _vm.model.collapsed === "false",
              "navbar-light": _vm.model.colorscheme === "light",
              "navbar-dark": _vm.model.colorscheme === "dark"
            }
          },
          [
            _vm.editAndEmpty ? _c("h1", [_vm._v("Configure Header")]) : _vm._e(),
            _vm._v(" "),
            _c("span", { staticClass: "navbar-logo" }, [
              _vm.model.logo
                ? _c(
                    "a",
                    { attrs: { href: _vm.$helper.pathToUrl(_vm.model.logourl) } },
                    [
                      _c("img", {
                        staticClass: "menu-logo",
                        style: "height:" + parseInt(_vm.model.logosize) + "px;",
                        attrs: {
                          src: _vm.$helper.pathToUrl(_vm.model.logo),
                          alt: _vm.model.logoalttext
                        }
                      })
                    ]
                  )
                : _vm._e()
            ]),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass: "navbar-toggler navbar-toggler-right",
                attrs: {
                  "data-toggle": "collapse",
                  "data-target": "#navbarSupportedContent",
                  "aria-expanded": "false",
                  "aria-controls": "navbarSupportedContent",
                  "aria-label": "navigation"
                }
              },
              [_c("span", { staticClass: "navbar-toggler-icon" })]
            ),
            _vm._v(" "),
            _c(
              "div",
              {
                staticClass: "collapse navbar-collapse justify-content-end",
                attrs: { id: "navbarSupportedContent" }
              },
              [
                _c("themeclean-components-textlinks", {
                  attrs: { model: _vm.model }
                }),
                _vm._v(" "),
                _c("themeclean-components-menubuttons", {
                  attrs: { model: _vm.model }
                })
              ],
              1
            ),
            _vm._v(" "),
            _vm.isEditAndEmpty
              ? _c("div", [_vm._v("no content defined for component")])
              : _vm._e()
          ]
        )
      ]
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
