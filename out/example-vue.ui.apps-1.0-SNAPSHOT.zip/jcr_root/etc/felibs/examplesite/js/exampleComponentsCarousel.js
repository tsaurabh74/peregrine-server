var cmpExampleComponentsCarousel = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  var script = {
    props: ['model'],
    computed: {
      name: function name() {
          return this.model.path.split('/').slice(1).join('-').slice(4)
      }
    },
    methods: {
      // beforeSave(data) {
      //   while(data.children.length > 0) {
      //     let name = data.children[0].name
      //     if(data.children[0].path) {
      //       name = data.children[0].path.split('/').pop()
      //     }
      //     delete data.children[0].path
      //     delete data.children[0].component
      //     data.children[0]['sling:resourceType'] = 'example/components/carouselItem'
      //     data[name] = data.children[0]
      //     data.children = data.children.slice(1)
      //   }
      //   return data
      // }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      {
        staticClass: "carousel slide",
        staticStyle: { "min-height": "300px", "background-color": "#eceff1" },
        attrs: {
          id: _vm.name,
          "data-interval": _vm.model.interval,
          "data-pause": _vm.model.pause,
          "data-ride": _vm.model.ride,
          "data-indicators": _vm.model.indicators,
          "data-controls": _vm.model.controls,
          "data-wrap": _vm.model.wrap,
          "data-keyboard": _vm.model.keyboard,
          "data-per-path": _vm.model.path
        }
      },
      [
        _vm.model.indicators
          ? _c(
              "ol",
              { staticClass: "carousel-indicators" },
              _vm._l(_vm.model.children, function(slide, index) {
                return _c("li", {
                  attrs: { "data-target": "#" + _vm.name, "data-slide-to": index }
                })
              }),
              0
            )
          : _vm._e(),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "carousel-inner", attrs: { role: "listbox" } },
          _vm._l(_vm.model.children, function(slide, index) {
            return _c(
              "div",
              { class: "carousel-item " + (index === 0 ? "active" : "") },
              [
                slide.imagePath
                  ? _c("img", { attrs: { src: slide.imagePath, alt: slide.alt } })
                  : _vm._e(),
                _vm._v(" "),
                slide.heading || slide.text
                  ? _c("div", { staticClass: "carousel-caption" }, [
                      slide.heading
                        ? _c(
                            "h3",
                            {
                              attrs: {
                                "data-per-inline":
                                  "model.children." + index + ".heading"
                              }
                            },
                            [
                              _vm._v(
                                "\n          " +
                                  _vm._s(slide.heading) +
                                  "\n        "
                              )
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      slide.text
                        ? _c("p", {
                            attrs: {
                              "data-per-inline":
                                "model.children." + index + ".text"
                            },
                            domProps: { innerHTML: _vm._s(slide.text) }
                          })
                        : _vm._e()
                    ])
                  : _vm._e()
              ]
            )
          }),
          0
        ),
        _vm._v(" "),
        _vm.model.controls
          ? [
              _c(
                "a",
                {
                  staticClass: "carousel-control-prev",
                  attrs: {
                    href: "#" + _vm.name,
                    role: "button",
                    "data-slide": "prev"
                  }
                },
                [_c("span", { staticClass: "carousel-control-prev-icon" })]
              ),
              _vm._v(" "),
              _c(
                "a",
                {
                  staticClass: "carousel-control-next",
                  attrs: {
                    href: "#" + _vm.name,
                    role: "button",
                    "data-slide": "next"
                  }
                },
                [_c("span", { staticClass: "carousel-control-next-icon" })]
              )
            ]
          : _vm._e()
      ],
      2
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
