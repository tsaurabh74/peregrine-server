//
// Simple Script to showcase the execution of the script within Node.js
//
console.log('Hello Node.js')