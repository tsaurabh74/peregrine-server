var cmpAdminComponentsRecyclebin = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        data: function() {
                return {
                    page: 0,
            }
        },
        computed: {
            results: function results() {
                return $perAdminApp.getNodeFromViewOrNull('/admin/recyclebin')
            },
            hasPrevious: function hasPrevious(){
                return this.page > 0
            },
            hasNext: function hasNext(){
                return this.results.more
            }
        },
        methods: {
            loadPage: function(increment) {
                if( (this.hasNext && increment > 0) || (this.hasPrevious && increment < 0) ) {
                    this.page = this.page + increment;
                }
            },
            getTenant: function getTenant() {
              return $perAdminApp.getView().state.tenant || {name: 'No site selected'}
            },
            restoreRecyclable: function restoreRecyclable(me, target) {
               var heading = (me.$i18n('Restore')) + " \"" + (target.path) + "\" " + (me.$i18n('from')) + " " + (target.date_deleted);
               $perAdminApp.askUser(heading, me.$i18n('Are you sure you want to restore this?'), {
                    yes: function yes() {
                        $perAdminApp.stateAction('recycleItem', {
                           recyclebinItemPath: target.recyclebin
                        });
                    }
                });
            },
            deleteRecyclable: function deleteRecyclable(me, target) {
                var heading = (me.$i18n('Delete')) + " \"" + (target.path) + "\" " + (me.$i18n('from')) + " " + (target.date_deleted);
                $perAdminApp.askUser(heading, me.$i18n('Delete this item forever?'), {
                    yes: function yes() {
                        $perAdminApp.stateAction('deleteRecyclable', target.recyclebin );
                    }
                });

            }
        },
        watch: {
            page: function(val){
                $perAdminApp.getApi().populateRecyclebin(val);
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col s12" }, [
            _c("h1", [
              _c("b", [_vm._v(_vm._s(_vm.getTenant().title))]),
              _vm._v(_vm._s(_vm.$i18n(" Recycle Bin")))
            ]),
            _vm._v(" "),
            _c("table", [
              _vm._m(0),
              _vm._v(" "),
              _c(
                "tbody",
                _vm._l(_vm.results.data, function(result) {
                  return _c("tr", { key: "" + result.recyclebin }, [
                    _c("td", [_vm._v(_vm._s(result.path))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(result.date_deleted))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(result.deleted_by))]),
                    _vm._v(" "),
                    _c(
                      "td",
                      [
                        _c(
                          "admin-components-action",
                          {
                            attrs: {
                              model: {
                                target: result,
                                command: "restoreRecyclable",
                                tooltipTitle:
                                  _vm.$i18n("restore version from") +
                                  " " +
                                  result.date_deleted
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("restore_page")
                            ])
                          ]
                        ),
                        _vm._v(" "),
                        _c(
                          "admin-components-action",
                          {
                            attrs: {
                              model: {
                                target: result,
                                command: "deleteRecyclable",
                                tooltipTitle:
                                  _vm.$i18n("delete forever") +
                                  " " +
                                  result.recyclebin
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("delete_forever")
                            ])
                          ]
                        )
                      ],
                      1
                    )
                  ])
                }),
                0
              )
            ]),
            _vm._v(" "),
            _c("ul", { staticClass: "pagination" }, [
              _c(
                "li",
                {
                  staticClass: "waves-effect",
                  class: { disabled: !_vm.hasPrevious }
                },
                [
                  _c(
                    "a",
                    {
                      attrs: { href: "", disabled: !_vm.hasPrevious },
                      on: {
                        click: function($event) {
                          $event.stopPropagation();
                          $event.preventDefault();
                          return _vm.loadPage(-1)
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("chevron_left")
                      ])
                    ]
                  )
                ]
              ),
              _vm._v(" "),
              _c("li", [
                _vm._v("Page " + _vm._s(_vm.page + 1) + "\n              ")
              ]),
              _c(
                "li",
                { staticClass: "waves-effect", class: { disabled: !_vm.hasNext } },
                [
                  _c(
                    "a",
                    {
                      attrs: { href: "", disabled: !_vm.hasNext },
                      on: {
                        click: function($event) {
                          $event.stopPropagation();
                          $event.preventDefault();
                          return _vm.loadPage(1)
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("chevron_right")
                      ])
                    ]
                  )
                ]
              )
            ])
          ])
        ])
      ])
    };
    var __vue_staticRenderFns__ = [
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("thead", [
          _c("tr", [
            _c("th", [_vm._v("Path")]),
            _vm._v(" "),
            _c("th", [_vm._v("Deleted on")]),
            _vm._v(" "),
            _c("th", [_vm._v("by")]),
            _vm._v(" "),
            _c("th", [_vm._v("Actions")])
          ])
        ])
      }
    ];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-48760130_0", { source: "\nh1 {\n    font-size: 2.5em;\n}\ntbody tr {\n    border-bottom: 1px dashed lightgray;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/recyclebin/template.vue"],"names":[],"mappings":";AAqIA;IACA,gBAAA;AACA;AACA;IACA,mCAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n\n  Contributed by Cris Rockwell University of Michigan\n  -->\n<template>\n<div>\n    <div class=\"row\">\n        <div class=\"col s12\">\n            <h1><b>{{getTenant().title}}</b>{{$i18n(' Recycle Bin')}}</h1>\n            <table>\n               <thead>\n                  <tr>\n                      <th>Path</th>\n                      <th>Deleted on</th>\n                      <th>by</th>\n                      <th>Actions</th>\n                  </tr>\n                </thead>\n                <tbody>\n                  <tr v-for=\"result in results.data\" v-bind:key=\"`${result.recyclebin}`\">\n                    <td>{{result.path}}</td>\n                    <td>{{result.date_deleted}}</td>\n                    <td>{{result.deleted_by}}</td>\n                    <td>\n                        <admin-components-action\n                            v-bind:model=\"{\n                                target: result,\n                                command: 'restoreRecyclable',\n                                tooltipTitle: `${$i18n('restore version from')} ${result.date_deleted}`\n                            }\">\n                            <i class=\"material-icons\">restore_page</i>\n                        </admin-components-action>\n                        <admin-components-action\n                                v-bind:model=\"{\n                                target: result,\n                                command: 'deleteRecyclable',\n                                tooltipTitle: `${$i18n('delete forever')} ${result.recyclebin}`\n                            }\">\n                            <i class=\"material-icons\">delete_forever</i>\n                        </admin-components-action>\n                    </td>\n                  </tr>\n              </tbody>\n          </table>\n          <ul class=\"pagination\">\n              <li class=\"waves-effect\" v-bind:class=\"{'disabled': !hasPrevious }\"><a href=\"\" v-bind:disabled=\"!hasPrevious\" v-on:click.stop.prevent=\"loadPage(-1)\"><i class=\"material-icons\">chevron_left</i></a></li>\n              <li>Page {{page + 1 }}\n              <li class=\"waves-effect\" v-bind:class=\"{'disabled': !hasNext }\"><a href=\"\" v-bind:disabled=\"!hasNext\" v-on:click.stop.prevent=\"loadPage(1)\"><i class=\"material-icons\">chevron_right</i></a></li>\n          </ul>\n       </div>\n    </div>\n</div>\n</template>\n\n<script>\n    export default {\n        props: ['model'],\n        data: function() {\n                return {\n                    page: 0,\n            }\n        },\n        computed: {\n            results() {\n                return $perAdminApp.getNodeFromViewOrNull('/admin/recyclebin')\n            },\n            hasPrevious(){\n                return this.page > 0\n            },\n            hasNext(){\n                return this.results.more\n            }\n        },\n        methods: {\n            loadPage: function(increment) {\n                if( (this.hasNext && increment > 0) || (this.hasPrevious && increment < 0) ) {\n                    this.page = this.page + increment\n                }\n            },\n            getTenant() {\n              return $perAdminApp.getView().state.tenant || {name: 'No site selected'}\n            },\n            restoreRecyclable(me, target) {\n               const heading = `${me.$i18n('Restore')} \"${target.path}\" ${me.$i18n('from')} ${target.date_deleted}`\n               $perAdminApp.askUser(heading, me.$i18n('Are you sure you want to restore this?'), {\n                    yes() {\n                        $perAdminApp.stateAction('recycleItem', {\n                           recyclebinItemPath: target.recyclebin\n                        })\n                    }\n                })\n            },\n            deleteRecyclable(me, target) {\n                const heading = `${me.$i18n('Delete')} \"${target.path}\" ${me.$i18n('from')} ${target.date_deleted}`\n                $perAdminApp.askUser(heading, me.$i18n('Delete this item forever?'), {\n                    yes() {\n                        $perAdminApp.stateAction('deleteRecyclable', target.recyclebin )\n                    }\n                })\n\n            }\n        },\n        watch: {\n            page: function(val){\n                $perAdminApp.getApi().populateRecyclebin(val)\n            }\n        }\n    }\n</script>\n\n<style>\n    h1 {\n        font-size: 2.5em;\n    }\n    tbody tr {\n        border-bottom: 1px dashed lightgray;\n    }\n</style>"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
