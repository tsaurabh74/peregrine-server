var cmpAdminComponentsContentview = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var Attribute = {
    INLINE: 'data-per-inline',
    PATH: 'data-per-path',
    DROPTARGET: 'data-per-droptarget',
    LOCATION: 'data-per-location'
  };

  var Key = {
    A: 65,
    BACKSPACE: 8,
    DELETE: 46,
    DOT: 190,
    COMMA: 188,
    ARROW_LEFT: 37,
    ARROW_UP: 38,
    ARROW_RIGHT: 39,
    ARROW_DOWN: 40,
    ESC: 27
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function set(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(vue) {
          Vue.set(node, path[0], value);
      }
      else {
          node[path[0]] = value;
      }
  }

  function get(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(value !== undefined && !node[path[0]]) {
          if(vue) {
              Vue.set(node, path[0], value);
          } else {
              node[path[0]] = value;
          }
      }
      return node[path[0]]
  }

  var getCaretCharacterOffsetWithin = function (element)  {
      var caretOffset = 0;
      var doc = element.ownerDocument || element.document;
      var win = doc.defaultView || doc.parentWindow;
      var sel;
      if (typeof win.getSelection != 'undefined') {
          sel = win.getSelection();
          if (sel.rangeCount > 0) {
              var range = win.getSelection().getRangeAt(0);
              var preCaretRange = range.cloneRange();
              preCaretRange.selectNodeContents(element);
              preCaretRange.setEnd(range.endContainer, range.endOffset);
              caretOffset = preCaretRange.toString().length;
          }
      } else if ( (sel = doc.selection) && sel.type !== 'Control') {
          var textRange = sel.createRange();
          var preCaretTextRange = doc.body.createTextRange();
          preCaretTextRange.moveToElementText(element);
          preCaretTextRange.setEndPoint('EndToEnd', textRange);
          caretOffset = preCaretTextRange.text.length;
      }
      return caretOffset
  };

  var saveSelection = function (containerEl, document) {
    if ( document === void 0 ) document=document;

    var window = document.defaultView;
    if (window.getSelection && document.createRange) {
      var range = window.getSelection().getRangeAt(0);
      var preSelectionRange = range.cloneRange();
      preSelectionRange.selectNodeContents(containerEl);
      preSelectionRange.setEnd(range.startContainer, range.startOffset);
      var start = preSelectionRange.toString().length;

      return {
        start: start,
        end: start + range.toString().length
      }
    } else if (document.selection) {
      var selectedTextRange = document.selection.createRange();
      var preSelectionTextRange = document.body.createTextRange();
      preSelectionTextRange.moveToElementText(containerEl);
      preSelectionTextRange.setEndPoint('EndToStart', selectedTextRange);
      var start$1 = preSelectionTextRange.text.length;

      return {
        start: start$1,
        end: start$1 + selectedTextRange.text.length
      }
    }
  };

  var restoreSelection = function (containerEl, savedSel, doc) {
    if ( doc === void 0 ) doc = document;

    var win = doc.defaultView;

    if (win.getSelection && doc.createRange) {
      var charIndex = 0, range = doc.createRange();
      range.setStart(containerEl, 0);
      range.collapse(true);
      var nodeStack = [containerEl], node, foundStart = false, stop = false;

      while (!stop && (node = nodeStack.pop())) {
        if (node.nodeType === 3) {
          var nextCharIndex = charIndex + node.length;
          if (!foundStart && savedSel.start >= charIndex && savedSel.start
              <= nextCharIndex) {
            range.setStart(node, savedSel.start - charIndex);
            foundStart = true;
          }
          if (foundStart && savedSel.end >= charIndex && savedSel.end
              <= nextCharIndex) {
            range.setEnd(node, savedSel.end - charIndex);
            stop = true;
          }
          charIndex = nextCharIndex;
        } else {
          var i = node.childNodes.length;
          while (i--) {
            nodeStack.push(node.childNodes[i]);
          }
        }
      }

      var sel = win.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } else if (doc.selection) {
      var textRange = doc.body.createTextRange();
      textRange.moveToElementText(containerEl);
      textRange.collapse(true);
      textRange.moveEnd('character', savedSel.end);
      textRange.moveStart('character', savedSel.start);
      textRange.select();
    }
  };

  //

  var script = {
    props: ['model'],
    data: function data() {
      return {
        rootWin: window,
        target: null,
        previousTarget: null,
        inline: null,
        scrollTop: 0,
        dragging: false,
        autoSave: false,
        editing: false,
        editable: {
          visible: false,
          class: null,
          timer: null,
          delay: 200,
          styles: {
            top: 0,
            left: 0,
            width: 0,
            height: 0
          }
        },
        selected: {
          draggable: true
        },
        iframe: {
          loaded: false,
          win: null, doc: null, html: null, body: null, head: null, app: null,
          scrollTop: 0,
          timeout: null,
          delay: 0,
          mouseOverCmp: null,
          dimension: {w: 0, h: 0, x: 0, y: 0}
        },
        clipboard: null,
        ctrlDown: false,
        isTouch: false,
        isIOS: false,
        caret: {
          pos: -1,
          counter: 0
        },
        holdingDown: false,
        inlineEdit: {
          firstTime: [],
          selection: null
        }
      }
    },
    computed: {
      component: function component() {
        if (this.target) {
          return this.findComponentEl(this.target)
        } else {
          return null
        }
      },
      previousComponent: function previousComponent() {
        if (this.previousTarget) {
          return this.findComponentEl(this.previousTarget)
        } else {
          return null
        }
      },
      path: function path() {
        if (this.component) {
          return this.getPath(this.component)
        } else {
          return null
        }
      },
      dropTarget: function dropTarget() {
        if (!this.target) { return }
        return this.target.getAttribute(Attribute.DROPTARGET) === 'true'
      },
      dropLocation: function dropLocation() {
        return this.target.getAttribute(Attribute.LOCATION)
      },
      targetInline: function targetInline() {
        return this.target.getAttribute(Attribute.INLINE)
      },
      view: function view() {
        return $perAdminApp.getView()
      },
      pageView: function pageView() {
        return this.view.pageView
      },
      node: function node() {
        var path = get(this.view, '/state/editor/path', null);
        if (path) {
          return $perAdminApp.findNodeFromPath(this.view.pageView.page, path)
        } else {
          return null
        }
      },
      isSelected: function isSelected() {
        return this.component && this.path && this.path !== '/jcr:content'
      },
      pagePath: function pagePath() {
        return $perAdminApp.getNodeFromView('/pageView/path') + '.html'
      },
      previewMode: function previewMode() {
        var ws = $perAdminApp.getNodeFromViewOrNull('/state/tools/workspace');
        return ws ? ws.preview : ''
      },
      viewMode: function viewMode() {
        var viewMode = $perAdminApp.getNodeFromViewOrNull('/state/tools/workspace/view');
        var previewMode = $perAdminApp.getNodeFromViewOrNull('/state/tools/workspace/preview');
        var ret;
        if (viewMode) {
          ret = viewMode + (previewMode ? ' ' + previewMode : '');
        } else {
          ret = 'desktop' + (previewMode ? ' ' + previewMode : '');
        }
        return ret
      },
      viewModeClass: function viewModeClass() {
        return this.viewMode
      },
      enableEditableFeatures: function enableEditableFeatures() {
        if (this.path === undefined || this.path === null || this.dragging) { return false }

        var node = $perAdminApp.findNodeFromPath(this.view.pageView.page, this.path);
        if (!node) {
          return false
        }
        return !node.fromTemplate
      },
      isTemplateNode: function isTemplateNode() {
        return $perAdminApp.findNodeFromPath(this.pageView.page, this.path).fromTemplate === true
      },
      isRich: function isRich() {
        return get(this.view, '/state/inline/rich', false)
      },
      componentTitle: function componentTitle() {
        var componentName = this.view.state.editor.component.split('-').join('/');
        var components = this.view.admin.components.data;
        for (var i = 0; i < components.length; i++) {
          var component = components[i];
          if (component.path.endsWith(componentName)) {
            return component.title
          }
        }
      },
      componentIsDropTarget: function componentIsDropTarget() {
        if (!this.component) { return false }

        var selector = "[" + (Attribute.PATH) + "=\"" + (this.path) + "\"][" + (Attribute.DROPTARGET) + "]";
        var dropTargetElements = this.component.querySelectorAll(selector);

        return dropTargetElements.length > 0;
      }
    },
    watch: {
      target: function target(val, oldVal) {
        this.previousTarget = oldVal;
        if (val) {
          this.selectComponent(this);
        } else {
          this.unselect(this);
        }
      },
      scrollTop: function scrollTop() {
        if (this.target) {
          this.wrapEditableAroundSelected();
        } else {
          this.wrapEditableAroundElement(this.iframe.mouseOverCmp);
        }
      },
      'view.state.tools.workspace.view': function view_state_tools_workspace_view() {
        var this$1 = this;

        this.$nextTick(function () {
          this$1.wrapEditableAroundSelected();
        });
      },
      'pageView.path': function pageView_path() {
        this.unselect(this);
      },
      node: {
        deep: true,
        handler: function handler(val) {
          var this$1 = this;

          if (!this.component) { return }
          this.wrapEditableAroundSelected();
          this.$nextTick(function () {
            this$1.refreshIframeElements();
          });
        }
      },
      previewMode: function previewMode(val) {
        var this$1 = this;

        if (val === 'preview') {
          this.iframePreviewMode();
          this.editable.class = null;
        } else {
          this.iframeEditMode();
          if (this.component) {
            clearTimeout(this.editable.timer);
            this.editable.timer = setTimeout(function () {
              this$1.editable.class = 'selected';
              this$1.wrapEditableAroundSelected();
            }, this.editable.delay);
          }
        }
      },
      'iframe.dimension': {
        deep: true,
        handler: function handler() {
          if (this.target) {
            this.wrapEditableAroundSelected();
          } else {
            this.wrapEditableAroundElement(this.iframe.mouseOverCmp);
          }
        }
      }
    },
    mounted: function mounted() {
      var this$1 = this;

      var vm = this;
      vm.$nextTick(function () {
        /* is this a touch device */
        vm.isTouch = 'ontouchstart' in window || navigator.maxTouchPoints;
        vm.isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
        if (vm.isTouch) {
          /* selected components are not immediatly draggable on touch devices */
          vm.selected.draggable = false;
        }
        set(vm.view, '/state/editorVisible', false);
        set(vm.view, '/state/editor/path', null);
        set(vm.view, '/state/inline/rich', null);

        if (this$1.previewMode !== 'preview') {
          set($perAdminApp.getView(), '/state/contentview/editor/active', true);
        } else {
          set($perAdminApp.getView(), '/state/contentview/editor/active', false);
        }
      });
    },
    beforeDestroy: function beforeDestroy() {
      set($perAdminApp.getView(), '/state/contentview/editor/active', false);
    },
    methods: {
      componentKey: function componentKey(component) {
        if (component.variation) {
          return component.path + ':' + component.variation
        } else {
          return component.path
        }
      },
      componentDisplayName: function componentDisplayName(component) {
        if (component.title) {
          return component.title
        } else {
          return component.path.split('/')[2] + ' ' + component.name
        }
      },

      selectComponent: function selectComponent(vm, el) {
        if ( el === void 0 ) el = vm.target;

        vm.target = el;
        if (!vm.target || !vm.component || !vm.path) { return }

        if (!vm.dragging && vm.isTemplateNode) {
          vm.unselect(vm);
          $perAdminApp.toast(vm.$i18n('fromTemplateNotifyMsg'), 'warn');
        } else {
          if (vm.dragging || vm.path !== '/jcr:content') {
            vm.wrapEditableAroundSelected();
            vm.editable.class = 'selected';
          }
          if (!vm.dragging) {
            if (vm.component !== vm.previousComponent) {
              set(this.view, '/state/inline/rich', null);
              set(this.view, '/state/inline/model', null);
              if (vm.autoSave && vm.node && vm.view.state.editor.path) {
                vm.autoSave = false;
                $perAdminApp.stateAction('savePageEdit', {
                  data: vm.node,
                  path: vm.view.state.editor.path
                }).then(function () {
                  $perAdminApp.action(vm, 'showComponentEdit', vm.path).then(function () {
                    vm.flushInlineState();
                    vm.$nextTick(vm.pingToolbar);
                  });
                });
              } else {
                $perAdminApp.action(vm, 'showComponentEdit', vm.path).then(function () {
                  vm.flushInlineState();
                  vm.$nextTick(vm.pingToolbar);
                });
              }
            } else {
              vm.flushInlineState();
            }
          }
        }
      },

      unselect: function unselect(vm) {
        vm.target = null;
        vm.editable.class = null;
        vm.autoSave = false;
        set(vm.view, '/state/inline/rich', false);
      },

      flushInlineState: function flushInlineState() {
        if (this.inline) {
          set(this.view, '/state/inline/model', this.inline);
          this.inline = null;
        }
      },

      findComponentEl: function findComponentEl(targetEl) {
        var el = targetEl;
        while (!el.getAttribute(Attribute.PATH) || el.getAttribute(Attribute.DROPTARGET)) {
          el = el.parentElement;
          if (!el) {
            break
          }
        }
        return el
      },

      findVnode: function findVnode(vmCmp, fullPath) {
        fullPath.reverse();
        var vnode = vmCmp._vnode;
        var startIndex = 1;
        fullPath.some(function (el) {
          if (el !== vnode.elm) {
            startIndex++;
          } else {
            return true
          }
        });
        var path = fullPath.slice(startIndex);
        path.reverse();
        var loop = function () {
          var wanted = path.pop();
          vnode.children.some(function (child) {
            if (child.elm === wanted) {
              vnode = child;
              return true
            }
          });
        };

        while (path.length > 0 && vnode.children && vnode.children.length > 0) loop();
        return vnode
      },

      writeInlineToModel: function writeInlineToModel(vm) {
        if ( vm === void 0 ) vm = this;

        var content = '';
        if (vm.isRich) {
          content = vm.target.innerHTML.replace(/(?:\r\n|\r|\n)/g, '<br>');
        } else {
          content = vm.target.innerText;
        }
        var dataInline = vm.targetInline.split('.').slice(1);
        dataInline.reverse();
        var parentProp = vm.node;
        while (dataInline.length > 1) {
          parentProp = parentProp[dataInline.pop()];
        }
        parentProp[dataInline.pop()] = content;
      },

      onInlineEdit: function onInlineEdit(event) {
        var this$1 = this;

        if (!this.inlineEdit.firstTime.includes(event.target)) {
          this.inlineEdit.firstTime.push(event.target);
          this.inlineEdit.selection = saveSelection(event.target, this.iframe.doc);
        }

        this.target = event.target;
        var vnode = this.findVnode(this.component.__vue__, event.path);
        var attr = this.isRich ? 'innerHTML' : 'innerText';
        if (vnode.data.domProps) {
          if (this.isRich) {
            vnode.data.domProps.innerHTML = this.target.innerHTML.replace(/(?:\r\n|\r|\n)/g, '<br>');
          } else {
            vnode.data.domProps.innerHTML = this.target.innerText;
          }
        }
        this.writeInlineToModel();

        if (this.inlineEdit.selection) {
          this.$nextTick(function () {
            this$1.$nextTick(function () {
              restoreSelection(event.target, this$1.inlineEdit.selection, this$1.iframe.doc);
              this$1.inlineEdit.selection = null;
            });
          });
        }

        this.autoSave = true;
        this.reWrapEditable();
      },

      onInlineClick: function onInlineClick(event) {
        this.pingToolbar();
      },

      onInlineFocus: function onInlineFocus(event) {
        event.target.classList.add('inline-editing');
        if (event.target.innerHTML) {
          event.target.innerHTML = event.target.innerHTML.trim();
        }
        this.editing = true;
        this.caret.pos = -1;
        this.caret.counter = 0;
        this.target = event.target;
        var dataInline = this.targetInline.split('.').slice(1);
        this.inline = dataInline.join('.');
        set(this.view, '/state/inline/doc', this.iframe.doc);
      },

      onInlineFocusOut: function onInlineFocusOut(event) {
        event.target.classList.remove('inline-editing');
        this.editing = false;
        set(this.view, '/state/inline/doc', null);
      },

      onInlineKeyDown: function onInlineKeyDown(event) {
        this.pingToolbar();
        var key = event.which;
        var shift = event.shiftKey;
        var ctrlOrCmd = event.ctrlKey || event.metaKey;
        var backspaceOrDelete = key === Key.BACKSPACE || key === Key.DELETE;
        var arrowKey = key >= Key.ARROW_LEFT && key <= Key.ARROW_DOWN;

        if (key === Key.A && ctrlOrCmd) {
          this.onInlineSelectAll(event);
        } else if (backspaceOrDelete) {
          this.onInlineDelete(event);
        } else if (arrowKey && !shift) {
          this.onInlineArrowKey(event);
        }
        this.holdingDown = true;
      },

      onInlineKeyUp: function onInlineKeyUp(event) {
        this.pingToolbar();
        var key = event.which;
        var shift = event.shiftKey;
        var ctrlOrCmd = event.ctrlKey || event.metaKey;
        var arrowKey = key >= Key.ARROW_LEFT && key <= Key.ARROW_DOWN;

        if (arrowKey && !shift) {
          this.onInlineArrowKey(event, true);
        }
        this.holdingDown = false;
      },

      onInlineDblClick: function onInlineDblClick(event) {
        if (event.target.tagName === 'IMG') {
          $perAdminApp.action(this, 'editImage', event.target);
        }
      },

      onInlineSelectAll: function onInlineSelectAll(event) {
        event.preventDefault();
        var range, selection;
        selection = this.iframe.win.getSelection();
        range = this.iframe.doc.createRange();
        range.selectNodeContents(event.target);
        selection.removeAllRanges();
        selection.addRange(range);
      },

      onInlineDelete: function onInlineDelete(event) {
        var selection = this.iframe.win.getSelection();
        if (selection.rangeCount > 1 && selection.anchorNode === this.target) {
          event.preventDefault();
          this.iframe.doc.execCommand('delete');
          this.target.innerHTML = '';
          this.writeInlineToModel();
        }
      },

      onInlineArrowKey: function onInlineArrowKey(event, isKeyUp) {
        if ( isKeyUp === void 0 ) isKeyUp = false;

        var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);
        if (chrome) { return }

        var key = event.which;
        var newCaretPos = getCaretCharacterOffsetWithin(event.target);
        if (this.caret.pos === newCaretPos && (isKeyUp || this.holdingDown)) {
          this.caret.counter++;
          if (this.caret.counter < 2) { return }
          var inlineEditNodes = this.iframe.app.querySelectorAll(("[" + (Attribute.INLINE) + "]"));
          if (inlineEditNodes.length <= 1) { return }
          var len = inlineEditNodes.length;

          for (var i = 0; i < len; i++) {
            if (inlineEditNodes[i] === this.target) {
              if (i > 0 && (key === Key.ARROW_LEFT || key === Key.ARROW_UP)) {
                this.placeCaretAtEnd(inlineEditNodes[i - 1]);
              } else if (i < len - 1 && (key === Key.ARROW_RIGHT || key === Key.ARROW_DOWN)) {
                inlineEditNodes[i + 1].focus();
              }
              break
            }
          }
        }
        this.caret.pos = newCaretPos;
      },

      onIframeLoaded: function onIframeLoaded(ev) {
        this.iframe.loaded = true;
        this.iframe.win = this.$refs.editview.contentWindow;
        this.iframe.doc = this.iframe.win.document;
        this.iframe.html = this.iframe.doc.querySelector('html');
        this.iframe.body = this.iframe.doc.querySelector('body');
        this.iframe.head = this.iframe.doc.querySelector('head');
        this.iframe.app = this.iframe.doc.querySelector('#peregrine-app');
        this.iframe.win.addEventListener('resize', this.updateIframeDimensions);
        this.updateIframeDimensions();
        this.addIframeExtraStyles();
        this.refreshIframeElements();
        if (this.previewMode !== 'preview') {
          this.iframeEditMode();
        } else {
          this.iframePreviewMode();
        }
      },

      onIframeClick: function onIframeClick(ev) {
        if (!this.isContentEditableOrNested(ev.target)) {
          this.target = ev.target;
        }
      },

      onIframeScroll: function onIframeScroll() {
        this.scrollTop = this.iframe.html.scrollTop;
      },

      onIframeDragOver: function onIframeDragOver(event) {
        event.preventDefault();
        this.dragging = true;
        this.target = event.target;

        if (this.component) {
          var isRoot = this.isTemplateNode;
          var relMousePos = this.getRelativeMousePosition(event);

          if (this.dropTarget) {
            var dropLocation = this.dropLocation;
            if (relMousePos.yPercentage <= 30 && dropLocation === 'before' && !isRoot) {
              this.dropPosition = 'before';
              this.editable.class = 'drop-top';
            } else if (relMousePos.yPercentage >= 70 && dropLocation === 'after' && !isRoot) {
              this.dropPosition = 'after';
              this.editable.class = 'drop-bottom';
            } else if (dropLocation) {
              this.dropPosition = 'into-' + dropLocation;
              this.editable.class = 'selected';
            } else {
              this.dropPosition = 'none';
            }
          } else if (!isRoot) {
            if (relMousePos.yPercentage <= 43.5) {
              this.dropPosition = 'before';
              this.editable.class = 'drop-top';
            } else {
              this.dropPosition = 'after';
              this.editable.class = 'drop-bottom';
            }
          } else {
            this.editable.class = 'selected';
            if (relMousePos.yPercentage <= 43.5) {
              this.dropPosition = 'into-before';
            } else {
              this.dropPosition = 'into-after';
            }
          }
        } else {
          this.dropPosition = 'none';
        }
      },

      onIframeDrop: function onIframeDrop(event) {
        var this$1 = this;

        event.preventDefault();
        this.dragging = false;
        this.target = event.target;
        if (this.isTouch) {
          this.selected.draggable = false;
        }
        if (typeof this.component === 'undefined' || this.component === null) { return false }

        var componentPath = event.dataTransfer.getData('text');
        if (this.path === componentPath) {
          event.dataTransfer.clearData('text');
          return false
        }
        var view = this.view;
        var payload = {
          pagePath: view.pageView.path,
          path: this.path,
          component: componentPath,
          drop: this.dropPosition
        };
        var addOrMove;
        if (componentPath.includes('/components/')) {
          addOrMove = 'addComponentToPath';
        } else {
          addOrMove = 'moveComponentToPath';
          var targetNode = $perAdminApp.findNodeFromPath(this.view.pageView.page, this.path);
          if (!targetNode || targetNode.fromTemplate) {
            $perAdminApp.notifyUser('template component',
                'You cannot drag a component into a template section');
            this.unselect(this);
            return false;
          }
          this.cleanUpAfterDelete(componentPath);
        }
        $perAdminApp.stateAction(addOrMove, payload).then(function (data) {
          this$1.refreshIframeElements();
        });
        this.unselect(this);
        event.dataTransfer.clearData('text');
      },

      onIframeMouseOver: function onIframeMouseOver(event) {
        if (this.editable.class === 'selected') { return }

        var cmpEl = this.findComponentEl(event.target);

        if (!cmpEl) {
          this.editable.visible = false;
          return
        }

        this.iframe.mouseOverCmp = cmpEl;
        this.wrapEditableAroundElement(cmpEl);

        if (this.isFromTemplate(cmpEl)) {
          this.editable.class = 'mouseover-orange';
        } else {
          this.editable.class = 'mouseover-green';
        }

        this.editable.visible = true;
      },

      refreshIframeElements: function refreshIframeElements() {
        this.refreshInlineEditElements();
      },

      refreshInlineEditElements: function refreshInlineEditElements() {
        var this$1 = this;

        var selector = "[" + (Attribute.INLINE) + "]:not(.inline-edit)";
        var elements = this.iframe.app.querySelectorAll(selector);
        if (!elements || elements.length <= 0) { return }

        elements.forEach(function (el) {
          if (this$1.isFromTemplate(el)) { return }

          el.classList.add('inline-edit');
          if (el.children.length === 0) {
            el.appendChild(document.createTextNode(' '));
          }
          el.addEventListener('input', this$1.onInlineEdit);
          el.addEventListener('click', this$1.onInlineClick);
          el.addEventListener('focus', this$1.onInlineFocus);
          el.addEventListener('focusout', this$1.onInlineFocusOut);
          el.addEventListener('keydown', this$1.onInlineKeyDown);
          el.addEventListener('keyup', this$1.onInlineKeyUp);
          el.addEventListener('dblclick', this$1.onInlineDblClick);
          el.setAttribute('contenteditable', this$1.previewMode !== 'preview' + '');
        });
      },

      iframeEditMode: function iframeEditMode() {
        var this$1 = this;

        set($perAdminApp.getView(), '/state/contentview/editor/active', true);
        this.iframe.doc.addEventListener('click', this.onIframeClick);
        this.iframe.doc.addEventListener('scroll', this.onIframeScroll);
        this.iframe.doc.addEventListener('dragover', this.onIframeDragOver);
        this.iframe.doc.addEventListener('drop', this.onIframeDrop);
        this.iframe.doc.addEventListener('mouseover', this.onIframeMouseOver);
        this.iframe.html.classList.add('edit-mode');
        var elements = this.iframe.app.querySelectorAll(("[" + (Attribute.INLINE) + "]"));
        elements.forEach(function (el, index) {
          if (this$1.isFromTemplate(el)) { return }
          el.setAttribute('contenteditable', 'true');
        });
        this.iframe.body.setAttribute('contenteditable', 'true');
        this.iframe.doc.getElementById('peregrine-app').setAttribute('contenteditable', 'false');
      },

      iframePreviewMode: function iframePreviewMode() {
        var this$1 = this;

        set($perAdminApp.getView(), '/state/contentview/editor/active', false);
        try {
          this.iframe.doc.removeEventListener('click', this.onIframeClick);
          this.iframe.doc.removeEventListener('scroll', this.onIframeScroll);
          this.iframe.doc.removeEventListener('mouseover', this.onIframeScroll);
        } catch (err) {
          console.debug('no event listener to be removed from iframe', err);
        }
        if (this.iframe.body) {
          this.iframe.body.setAttribute('contenteditable', 'false');
        }
        if (this.iframe.html) {
          this.iframe.html.classList.remove('edit-mode');
        }
        if (this.iframe.app) {
          var elements = this.iframe.app.querySelectorAll(("[" + (Attribute.INLINE) + "]"));
          elements.forEach(function (el, index) {
            if (this$1.isFromTemplate(el)) { return }
            el.setAttribute('contenteditable', 'false');
          });
        }
      },

      addIframeExtraStyles: function addIframeExtraStyles() {
        if (this.iframe.head.querySelector('#editing-extra-styles')) { return }
        var css = "\n        html.edit-mode body {\n          cursor: default !important\n        }\n        html.edit-mode #peregrine-app [contenteditable=\"true\"]:focus {\n          outline: 1px dotted #fe9701 !important;\n        }\n\n        html.edit-mode #peregrine-app [contenteditable=\"true\"]:hover:not(:focus) {\n          outline: 1px dotted #ffc171 !important;\n        }\n\n        html.edit-mode #peregrine-app .from-template {\n          cursor: not-allowed !important;\n        }\n\n        html.edit-mode #peregrine-app .from-template * {\n          cursor: not-allowed !important;\n        }\n\n        html.edit-mode #peregrine-app .inline-edit {\n          cursor: text !important\n        }";
        var style = this.iframe.doc.createElement('style');
        this.iframe.head.appendChild(style);
        style.type = 'text/css';
        style.appendChild(this.iframe.doc.createTextNode(css));
        style.setAttribute('id', 'editing-extra-styles');
      },

      isContentEditableOrNested: function isContentEditableOrNested(el) {
        var component = this.findComponentEl(el);

        if (el === component) { return el.getAttribute('contenteditable') === 'true' }

        while (el.getAttribute('contenteditable') !== 'true') {
          el = el.parentElement;
          if (!el || el === component) {
            return false
          }
        }
        return el.getAttribute('contenteditable') === 'true'
      },

      wrapEditableAroundElement: function wrapEditableAroundElement(el) {
        var this$1 = this;

        if (!el) { return }

        this.$nextTick(function () {
          var ref = this$1.getBoundingClientRect(el);
          var top = ref.top;
          var left = ref.left;
          var width = ref.width;
          var height = ref.height;
          var offset = this$1.getBoundingClientRect(this$1.$refs.editview);

          this$1.editable.styles.top = top + "px";
          this$1.editable.styles.left = (left + offset.left) + "px";
          this$1.editable.styles.width = width + "px";
          this$1.editable.styles.height = height + "px";
        });
      },

      wrapEditableAroundSelected: function wrapEditableAroundSelected() {
        this.wrapEditableAroundElement(this.component);
      },

      reWrapEditable: function reWrapEditable(vm) {
        if ( vm === void 0 ) vm = this;

        vm.editable.timer = setTimeout(function () {
          vm.editable.class = 'selected';
          vm.wrapEditableAroundSelected();
        }, vm.editable.delay);
      },

      getElementStyle: function getElementStyle(e, styleName) {
        var styleValue = '';
        if (document.defaultView && document.defaultView.getComputedStyle) {
          styleValue = document.defaultView.getComputedStyle(e, '').getPropertyValue(styleName);
        } else if (e.currentStyle) {
          styleName = styleName.replace(/-(\w)/g, function (strMatch, p1) {
            return p1.toUpperCase();
          });
          styleValue = e.currentStyle[styleName];
        }
        return styleValue;
      },

      getBoundingClientRect: function getBoundingClientRect(e) {
        var rect = e.getBoundingClientRect();
        var marginTop = parseFloat(this.getElementStyle(e, 'margin-top'));
        var marginLeft = parseFloat(this.getElementStyle(e, 'margin-left'));
        var marginRight = parseFloat(this.getElementStyle(e, 'margin-right'));
        var marginBottom = parseFloat(this.getElementStyle(e, 'margin-bottom'));
        var newRect = {
          left: rect.left - (marginLeft > 0 ? marginLeft : 0),
          right: rect.right + (marginRight > 0 ? marginRight : 0),
          top: rect.top - marginTop,
          bottom: rect.bottom + marginBottom,
        };
        newRect.width = newRect.right - newRect.left;
        newRect.height = newRect.bottom - newRect.top;
        return newRect;
      },

      removeEditable: function removeEditable() {
        this.target = null;
        this.editable.class = null;
        if (this.isTouch) {
          this.selected.draggable = false;
        }
      },

      getRelativeMousePosition: function getRelativeMousePosition(event) {
        var offset = this.getBoundingClientRect(this.component);
        return {
          width: offset.width,
          x: event.pageX - offset.left,
          xPercentage: (event.pageX - offset.left) / offset.width * 100,
          height: offset.height,
          y: event.pageY - offset.top - this.scrollTop,
          yPercentage: (event.pageY - offset.top - this.scrollTop) / offset.height * 100
        }
      },

      getPath: function getPath(el) {
        var component = this.findComponentEl(el);
        return component.getAttribute(Attribute.PATH)
      },

      isFromTemplate: function isFromTemplate(el) {
        return $perAdminApp.findNodeFromPath(this.pageView.page, this.getPath(el)).fromTemplate
      },

      /* Drag and Drop ===========================
      ============================================ */
      onEditableDragStart: function onEditableDragStart(ev) {
        if (this.component === null) { return }

        this.editable.class = 'dragging';
        ev.dataTransfer.setData('text', this.path);
        ev.dataTransfer.setDragImage(this.component, 400, 0);
      },

      /* Editable methods ========================
      ============================================ */
      onEditableTouchStart: function onEditableTouchStart(ev) {
        this.editable.timer = setTimeout(this.onLongTouchOverlay, 800);
      },

      onEditableTouchEnd: function onEditableTouchEnd(ev) {
        clearTimeout(this.editable.timer);
      },

      onLongTouchOverlay: function onLongTouchOverlay() {
        if (this.component === null) { return }

        this.selected.draggable = true;
        this.editable.class = 'draggable';
      },

      onDelete: function onDelete(e) {
        var this$1 = this;

        var view = this.view;
        var pagePath = view.pageView.path;
        var payload = {
          pagePath: view.pageView.path,
          path: this.path
        };
        if (payload.path !== '/jcr:content') {
          $perAdminApp.stateAction('deletePageNode', payload).then(function (data) {
            this$1.cleanUpAfterDelete(payload.path);
            this$1.refreshIframeElements();
          });
        }
        this.unselect(this);
      },

      cleanUpAfterDelete: function cleanUpAfterDelete(path) {
        var selector = "[" + (Attribute.PATH) + "=\"" + path + "\"]";
        var remains = this.iframe.app.querySelectorAll(selector);
        if (remains.length <= 0) { return }
        remains.forEach(function (remain) {
          remain.remove();
        });
      },

      onCopy: function onCopy(e) {
        this.clipboard = $perAdminApp.findNodeFromPath(
            this.view.pageView.page,
            this.path
        );
      },

      onPaste: function onPaste(e) {
        var this$1 = this;

        var nodeFromClipboard = this.clipboard;
        var view = this.view;
        var isDropTarget = this.dropTarget === 'true';
        var dropPosition;
        isDropTarget ? dropPosition = 'into' : dropPosition = 'after';
        var payload = {
          pagePath: view.pageView.path,
          data: nodeFromClipboard,
          path: this.path,
          drop: dropPosition
        };
        $perAdminApp.stateAction('addComponentToPath', payload).then(function (data) {
          this$1.refreshIframeElements();
        });
      },

      placeCaretAtEnd: function placeCaretAtEnd(el) {
        var doc = el.ownerDocument;
        var win = doc.defaultView || doc.parentWindow;
        el.focus();
        if (typeof win.getSelection != 'undefined' && typeof doc.createRange != 'undefined') {
          var range = doc.createRange();
          range.selectNodeContents(el);
          range.collapse(false);
          var sel = win.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
        } else if (typeof doc.body.createTextRange != 'undefined') {
          var textRange = doc.body.createTextRange();
          textRange.moveToElementText(el);
          textRange.collapse(false);
          textRange.select();
        }
      },

      pingToolbar: function pingToolbar() {
        $perAdminApp.action(this, 'pingRichToolbar');
      },

      onAddComponentModalComponentAdded: function onAddComponentModalComponentAdded(newNode) {
        var this$1 = this;

        this.refreshIframeElements();
        var selector = "[" + (Attribute.PATH) + "=\"" + (newNode.path) + "\"]";
        var newNodeEl = this.iframe.app.querySelector(selector);
        var firstInlineEditEl = newNodeEl.querySelector(("[" + (Attribute.INLINE) + "]"));

        if (firstInlineEditEl) {
          firstInlineEditEl.focus();
        } else {
          this.$nextTick(function () {
            newNodeEl.click();
            this$1.scrollIntoViewCenter(newNodeEl, this$1.iframe.doc, this$1.iframe.win);
          });
        }
      },

      scrollIntoViewCenter: function scrollIntoViewCenter(el, doc, win) {
        el.scrollIntoView(true);
        var viewportH = Math.max(doc.documentElement.clientHeight, win.innerHeight || 0);
        win.scrollBy(0, (el.getBoundingClientRect().height - viewportH) / 2);
      },

      onComponentMouseEnter: function onComponentMouseEnter(event) {
        event.stopPropagation();
        var cls = event.target.getAttribute('class');

        if (this.isFromTemplate(event.target)) {
          event.target.setAttribute('class', 'outline-orange ' + cls);
        } else {
          event.target.setAttribute('class', 'outline-green ' + cls);
        }
      },

      onComponentMouseLeave: function onComponentMouseLeave(event) {
        event.stopPropagation();
        event.target.classList.remove('outline-orange', 'outline-green');
      },

      updateIframeDimensions: function updateIframeDimensions() {
        var this$1 = this;

        clearTimeout(this.iframe.timeout);
        this.iframe.timeout = setTimeout(function () {
          this$1.iframe.dimension.w = this$1.iframe.doc.documentElement.clientWidth;
          this$1.iframe.dimension.h = this$1.iframe.doc.documentElement.clientHeight;
        }, this.iframe.delay);
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      { class: "peregrine-content-view " + _vm.viewModeClass },
      [
        _c(
          "div",
          {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.previewMode !== "preview",
                expression: "previewMode !== 'preview'"
              }
            ],
            ref: "editable",
            class: _vm.editable.class,
            style: _vm.editable.styles,
            attrs: { id: "editable", draggable: "true" },
            on: {
              dragstart: _vm.onEditableDragStart,
              touchstart: _vm.onEditableTouchStart,
              touchend: _vm.onEditableTouchEnd
            }
          },
          [
            _vm.enableEditableFeatures
              ? _c(
                  "a",
                  {
                    staticClass: "drag-handle top-right",
                    attrs: {
                      draggable: "false",
                      href: "#",
                      title: "move component"
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("drag_handle")
                    ])
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.enableEditableFeatures
              ? _c(
                  "a",
                  {
                    staticClass: "drag-handle bottom-left",
                    attrs: {
                      draggable: "false",
                      href: "#",
                      title: "move component"
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("drag_handle")
                    ])
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.enableEditableFeatures
              ? _c("div", { staticClass: "editable-actions" }, [
                  _c("ul", [
                    _c("li", { staticClass: "waves-effect waves-light" }, [
                      _c(
                        "a",
                        {
                          attrs: { href: "#", title: _vm.$i18n("copy") },
                          on: {
                            click: function($event) {
                              $event.stopPropagation();
                              $event.preventDefault();
                              return _vm.onCopy($event)
                            }
                          }
                        },
                        [
                          _c("i", { staticClass: "material-icons" }, [
                            _vm._v("content_copy")
                          ])
                        ]
                      )
                    ]),
                    _vm._v(" "),
                    _vm.clipboard
                      ? _c("li", { staticClass: "waves-effect waves-light" }, [
                          _c(
                            "a",
                            {
                              attrs: { title: _vm.$i18n("paste"), href: "#" },
                              on: {
                                click: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.onPaste($event)
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "material-icons" }, [
                                _vm._v("content_paste")
                              ])
                            ]
                          )
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.isSelected
                      ? _c("li", { staticClass: "waves-effect waves-light" }, [
                          _c(
                            "a",
                            {
                              attrs: {
                                href: "#",
                                title: _vm.$i18n("deleteComponent")
                              },
                              on: {
                                click: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.onDelete($event)
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "material-icons" }, [
                                _vm._v("delete")
                              ])
                            ]
                          )
                        ])
                      : _vm._e()
                  ])
                ])
              : _vm._e()
          ]
        ),
        _vm._v(" "),
        [
          !_vm.iframe.loaded
            ? _c(
                "div",
                { staticClass: "spinner-wrapper" },
                [_c("admin-components-materializespinner")],
                1
              )
            : _vm._e(),
          _vm._v(" "),
          _c("iframe", {
            directives: [
              {
                name: "show",
                rawName: "v-show",
                value: _vm.iframe.loaded,
                expression: "iframe.loaded"
              }
            ],
            ref: "editview",
            attrs: {
              id: "editview",
              src: _vm.pagePath,
              "data-per-mode": _vm.previewMode
            },
            on: { load: _vm.onIframeLoaded }
          })
        ],
        _vm._v(" "),
        _vm.iframe.win
          ? _c("admin-components-addcomponentmodal", {
              attrs: {
                "selected-component": _vm.component,
                "is-drop-target": _vm.componentIsDropTarget,
                windows: [_vm.rootWin, _vm.iframe.win]
              },
              on: { "component-added": _vm.onAddComponentModalComponentAdded }
            })
          : _vm._e()
      ],
      2
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
