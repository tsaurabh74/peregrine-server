var cmpAdminComponentsPagebrowser = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        data: function() {
            return {
                tab: 'browse',
                cardSize: 120,
                search: '',
                preview: '', 
                linkModel: {
                    url: '',
                    newWindow: false
                },
                linkSchema: {
                    fields: [
                        {
                            type: "input",
                            inputType: "text",
                            label: "Url",
                            model: "url",
                            placeholder: 'https://',
                            min: 6,
                            required: true
                        },
                        {
                            type: "checkbox",
                            label: "Open in new window?",
                            model: "newWindow",
                            default: false
                        }
                    ]
                },
                linkFormOptions: {
                    validateAfterLoad: true,
                    validateAfterChanged: true
                }
            }
        },
        watch: {
            cardSize: function (newCardSize) {
                this.updatedIsotopeLayout('masonry');
            }
        },
        computed: {
            selectedPath: function selectedPath(){
                return $perAdminApp.getNodeFromViewOrNull('/state/pagebrowser/selectedPath')
            },
            withLinkTab: function withLinkTab(){
                return $perAdminApp.getNodeFromViewOrNull('/state/pagebrowser/withLinkTab')
            },
            tabIndicatorPosition: function tabIndicatorPosition(){
                var position;
                switch(this.tab) {
                    case ('browse'):
                        position = 0;
                        break
                    case ('cards'):
                        position = 72;
                        break
                    case ('link'):
                        position = 144;
                        break
                    default:
                        position = 0;
                        break
                }
                return position
            },
            searchTabOffset: function searchTabOffset(){
                if(this.withLinkTab){
                    return 216
                } else {
                    return 144
                }
            },
            path: function path() {
                var root = $perAdminApp.getNodeFromViewOrNull('/state/pagebrowser/root');
                return root
            },
            nodes: function nodes() {
                var view = $perAdminApp.getView();
                var nodes = view.admin.pathBrowser;
                if(nodes && this.path) {
                    var nodesFromPath = $perAdminApp.findNodeFromPath(nodes, this.path);
                    return nodesFromPath
                }
                return {}
            },
            list: function list(){
                return this.nodes.children || []
            }
        },
        methods: {
            cardIconSize: function(cardSize){
                return Math.floor(cardSize/3)
            },
            getImagesLoadedCbs: function() {
              return {
                progress: function (instance, img ) {
                },
                always: function (instance) {
                },
                done: function (instance) {
                },
                fail: function (instance) {
                }
              }
            },
            updatedIsotopeLayout: function(layout){
                this.$refs.isotope.layout(layout);
            },
            getIsotopeOptions: function() {
                return {
                    layoutMode: 'masonry',
                    itemSelector: '.card',
                    stamp: '.stamp',
                    masonry: {
                        gutter: 15
                    },
                    getSortData: {
                        name: function(itemElem){
                            return itemElem.name.toLowerCase()
                        },
                        created: function(itemElem){
                            return Date.parse(itemElem.created)
                        }
                    }
                }
            },

            onSort: function onSort(sortType){
                this.sortBy = sortType;
                this.$refs.isotope.sort(sortType);
            },

            select: function select(name) {
                this.tab = name;
            },
            searchFilter: function searchFilter(item) {
                if(this.search.length === 0) { return true }
                return (item.name.indexOf(this.search) >= 0)
            },
            selectParent: function selectParent() {
                var parentFolder = this.path.split('/');
                parentFolder.pop();
                var newPath = parentFolder.join('/');
                this.selectFolder({ path: newPath} );
            },
            display: function display(item) {
                return item.name !== 'jcr:content'
            },
            isFolder: function isFolder(item) {
                var FOLDERS = [
                    'per:Page',
                    'nt:folder',
                    'sling:Folder',
                    'sling:OrderedFolder'
                ];
                return FOLDERS.indexOf(item.resourceType) >= 0
            },
            isSelected: function isSelected(path) {
                return this.selectedPath === path 
            },
            selectFolder: function selectFolder(item) {
                var this$1 = this;

                $perAdminApp.getApi().populateNodesForBrowser(item.path, 'pathBrowser').then( function () {
                    var pb = $perAdminApp.getNodeFromView('/state/pagebrowser');
                    pb.root = item.path;
                    if(this$1.tab === 'cards'){
                        this$1.updatedIsotopeLayout('masonry');
                    }
                    this$1.preview = item;
                });
            },
            selectItem: function selectItem(path) {
                return $perAdminApp.getNodeFromView('/state/pagebrowser').selectedPath = path
            },
            onUnlink: function onUnlink() {
                this.setItemPath('');
                this.onHide();
            },
            onHide: function onHide() {
                return $('#pageBrowserModal').modal('close')
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        {
          staticClass: "pathbrowser pagebrowser modal default modal-fixed-footer",
          attrs: { id: "pageBrowserModal" }
        },
        [
          _c("ul", { ref: "pbtabs", staticClass: "pathbrowser-tabs" }, [
            _c("li", { staticClass: "tab" }, [
              _c(
                "a",
                {
                  class: _vm.tab === "browse" ? "active" : "",
                  attrs: { href: "#" },
                  on: {
                    click: function($event) {
                      return _vm.select("browse")
                    }
                  }
                },
                [_c("i", { staticClass: "material-icons" }, [_vm._v("list")])]
              )
            ]),
            _vm._v(" "),
            _c("li", { staticClass: "tab" }, [
              _c(
                "a",
                {
                  class: _vm.tab === "cards" ? "active" : "",
                  attrs: { href: "#" },
                  on: {
                    click: function($event) {
                      return _vm.select("cards")
                    }
                  }
                },
                [
                  _c("i", { staticClass: "material-icons" }, [
                    _vm._v("view_module")
                  ])
                ]
              )
            ]),
            _vm._v(" "),
            _vm.withLinkTab
              ? _c("li", { staticClass: "tab" }, [
                  _c(
                    "a",
                    {
                      class: _vm.tab === "link" ? "active" : "",
                      attrs: { href: "#" },
                      on: {
                        click: function($event) {
                          return _vm.select("link")
                        }
                      }
                    },
                    [_c("i", { staticClass: "material-icons" }, [_vm._v("link")])]
                  )
                ])
              : _vm._e(),
            _vm._v(" "),
            _c("li", {
              staticClass: "indicator",
              style: "transform: translateX(" + _vm.tabIndicatorPosition + "px)"
            })
          ]),
          _vm._v(" "),
          _c(
            "div",
            {
              staticClass: "pathbrowser-filter",
              style: "width: calc(100% - " + _vm.searchTabOffset + "px)"
            },
            [
              _c("input", {
                directives: [
                  {
                    name: "model",
                    rawName: "v-model",
                    value: _vm.search,
                    expression: "search"
                  }
                ],
                attrs: { placeholder: "search", type: "search" },
                domProps: { value: _vm.search },
                on: {
                  input: function($event) {
                    if ($event.target.composing) {
                      return
                    }
                    _vm.search = $event.target.value;
                  }
                }
              })
            ]
          ),
          _vm._v(" "),
          _c("div", { staticClass: "modal-content" }, [
            _c(
              "div",
              { staticClass: "col-browse" },
              [
                _vm.search
                  ? _c("div", [
                      _c("table", [
                        _vm._m(0),
                        _vm._v(" "),
                        _c(
                          "tbody",
                          _vm._l(_vm.nodes.children, function(item) {
                            return _vm.searchFilter(item)
                              ? _c("tr", [
                                  _c("td", [_vm._v(_vm._s(item.name))]),
                                  _vm._v(" "),
                                  _c("td", [_vm._v(_vm._s(item.path))])
                                ])
                              : _vm._e()
                          }),
                          0
                        )
                      ])
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _vm.tab === "browse" && !_vm.search
                  ? [
                      _c("span", { staticClass: "current-folder" }, [
                        _c(
                          "button",
                          {
                            staticClass: "btn-flat",
                            attrs: {
                              disabled: _vm.path === "/content",
                              type: "button"
                            },
                            on: {
                              click: function($event) {
                                $event.stopPropagation();
                                $event.preventDefault();
                                return _vm.selectParent($event)
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("keyboard_arrow_left")
                            ])
                          ]
                        ),
                        _vm._v(
                          "\n                    " +
                            _vm._s(_vm.path) +
                            " (" +
                            _vm._s(_vm.list.length) +
                            ")\n                "
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "ul",
                        { staticClass: "browse-list" },
                        _vm._l(_vm.nodes.children, function(item, index) {
                          return _vm.isFolder(item)
                            ? _c(
                                "li",
                                {
                                  class: _vm.isSelected(item.path)
                                    ? "selected"
                                    : "",
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation();
                                      $event.preventDefault();
                                      return _vm.selectFolder(item)
                                    }
                                  }
                                },
                                [
                                  _c("input", {
                                    staticClass: "with-gap",
                                    attrs: { name: "selectedItem", type: "radio" },
                                    domProps: { checked: _vm.isSelected(item.path) }
                                  }),
                                  _vm._v(" "),
                                  _c("label", {
                                    on: {
                                      click: function($event) {
                                        $event.stopPropagation();
                                        $event.preventDefault();
                                        return _vm.selectItem(item.path)
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v("folder")
                                  ]),
                                  _vm._v(" "),
                                  _c("span", [_vm._v(_vm._s(item.name))])
                                ]
                              )
                            : _vm._e()
                        }),
                        0
                      )
                    ]
                  : _vm._e(),
                _vm._v(" "),
                _vm.tab === "cards" && !_vm.search
                  ? [
                      _vm.list.length > 0
                        ? [
                            _c("ul", { staticClass: "cards-toolbar sort-nav" }, [
                              _vm._m(1),
                              _vm._v(" "),
                              _c("li", [
                                _c("input", {
                                  staticClass: "with-gap",
                                  attrs: {
                                    name: "pagebrowser_sort_cards",
                                    type: "radio",
                                    id: "pagebrowser_sort_cards_name"
                                  },
                                  domProps: { checked: _vm.sortBy === "name" }
                                }),
                                _vm._v(" "),
                                _c(
                                  "label",
                                  {
                                    attrs: { for: "pagebrowser_sort_cards_name" },
                                    on: {
                                      click: function($event) {
                                        return _vm.onSort("name")
                                      }
                                    }
                                  },
                                  [_vm._v("name")]
                                )
                              ]),
                              _vm._v(" "),
                              _c("li", [
                                _c("input", {
                                  staticClass: "with-gap",
                                  attrs: {
                                    name: "pagebrowser_sort_cards",
                                    type: "radio",
                                    id: "pagebrowser_sort_cards_date"
                                  },
                                  domProps: { checked: _vm.sortBy === "created" }
                                }),
                                _vm._v(" "),
                                _c(
                                  "label",
                                  {
                                    attrs: { for: "pagebrowser_sort_cards_date" },
                                    on: {
                                      click: function($event) {
                                        return _vm.onSort("created")
                                      }
                                    }
                                  },
                                  [_vm._v("date")]
                                )
                              ])
                            ]),
                            _vm._v(" "),
                            _c("p", { staticClass: "range-field" }, [
                              _c("input", {
                                directives: [
                                  {
                                    name: "model",
                                    rawName: "v-model",
                                    value: _vm.cardSize,
                                    expression: "cardSize"
                                  }
                                ],
                                attrs: { type: "range", min: "120", max: "400" },
                                domProps: { value: _vm.cardSize },
                                on: {
                                  __r: function($event) {
                                    _vm.cardSize = $event.target.value;
                                  }
                                }
                              })
                            ]),
                            _vm._v(" "),
                            _c(
                              "isotope",
                              {
                                directives: [
                                  {
                                    name: "images-loaded",
                                    rawName: "v-images-loaded:on",
                                    value: _vm.getImagesLoadedCbs(),
                                    expression: "getImagesLoadedCbs()",
                                    arg: "on"
                                  }
                                ],
                                ref: "isotope",
                                staticClass: "isotopes",
                                attrs: {
                                  options: _vm.getIsotopeOptions(),
                                  list: _vm.list
                                }
                              },
                              _vm._l(_vm.list, function(item, index) {
                                return _c("div", { key: item.path }, [
                                  _vm.isFolder(item)
                                    ? _c(
                                        "div",
                                        {
                                          staticClass: "item-folder",
                                          style:
                                            "width: " +
                                            _vm.cardSize +
                                            "px; height: " +
                                            _vm.cardSize +
                                            "px",
                                          on: {
                                            click: function($event) {
                                              $event.stopPropagation();
                                              $event.preventDefault();
                                              return _vm.selectFolder(item)
                                            }
                                          }
                                        },
                                        [
                                          _c(
                                            "div",
                                            { staticClass: "item-content" },
                                            [
                                              _c(
                                                "i",
                                                {
                                                  staticClass: "material-icons",
                                                  style:
                                                    "font-size: " +
                                                    _vm.cardIconSize(_vm.cardSize) +
                                                    "px"
                                                },
                                                [_vm._v("folder_open")]
                                              ),
                                              _vm._v(" "),
                                              _c("br"),
                                              _vm._v(
                                                _vm._s(item.name) +
                                                  "\n                                    "
                                              )
                                            ]
                                          )
                                        ]
                                      )
                                    : _vm._e()
                                ])
                              }),
                              0
                            )
                          ]
                        : _c("p", { staticClass: "flow-text" }, [
                            _vm._v("This folder is empty.")
                          ])
                    ]
                  : _vm._e(),
                _vm._v(" "),
                _vm.withLinkTab && _vm.tab === "link" && !_vm.search
                  ? [
                      _c("vue-form-generator", {
                        attrs: {
                          schema: _vm.linkSchema,
                          model: _vm.linkModel,
                          options: _vm.linkFormOptions
                        }
                      })
                    ]
                  : _vm._e()
              ],
              2
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "col-preview" },
              [
                _vm.preview
                  ? [
                      _vm.isFolder(_vm.preview)
                        ? _c("div", { staticClass: "preview-folder" }, [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("folder_open")
                            ])
                          ])
                        : _c("img", {
                            staticClass: "preview-image",
                            attrs: { src: _vm.preview.path }
                          }),
                      _vm._v(" "),
                      _c("dl", { staticClass: "preview-data" }, [
                        _c("dt", [_vm._v("Name")]),
                        _vm._v(" "),
                        _c("dd", [_vm._v(_vm._s(_vm.preview.name))]),
                        _vm._v(" "),
                        _c("dt", [_vm._v("Type")]),
                        _vm._v(" "),
                        _c("dd", [_vm._v(_vm._s(_vm.preview.resourceType))]),
                        _vm._v(" "),
                        _c("dt", [_vm._v("Path")]),
                        _vm._v(" "),
                        _c("dd", [_vm._v(_vm._s(_vm.preview.path))]),
                        _vm._v(" "),
                        _c("dt", [_vm._v("Created")]),
                        _vm._v(" "),
                        _c("dd", [_vm._v(_vm._s(_vm.preview.created))])
                      ])
                    ]
                  : _c("div", { staticClass: "no-asset-selected" }, [
                      _c("span", [_vm._v(_vm._s(_vm.$i18n("noAssetSelected")))]),
                      _vm._v(" "),
                      _c("i", { staticClass: "material-icons" }, [_vm._v("info")])
                    ])
              ],
              2
            )
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "modal-footer" }, [
            _c("span", { staticClass: "selected-path" }, [
              _vm._v(_vm._s(_vm.selectedPath))
            ]),
            _vm._v(" "),
            _vm.withLinkTab
              ? _c(
                  "button",
                  {
                    staticClass:
                      "modal-action modal-close waves-effect waves-light btn-flat",
                    on: { click: _vm.onUnlink }
                  },
                  [_vm._v("unlink")]
                )
              : _vm._e(),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass:
                  "modal-action modal-close waves-effect waves-light btn-flat"
              },
              [_vm._v("cancel")]
            ),
            _vm._v(" "),
            _c(
              "button",
              {
                staticClass:
                  "modal-action modal-close waves-effect waves-light btn-flat"
              },
              [_vm._v("select")]
            )
          ])
        ]
      )
    };
    var __vue_staticRenderFns__ = [
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("thead", [
          _c("tr", [
            _c("th", [_vm._v("Name")]),
            _vm._v(" "),
            _c("th", [_vm._v("Path")])
          ])
        ])
      },
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("li", [
          _c("span", { staticClass: "cards-toolbar-title" }, [_vm._v("Sort")])
        ])
      }
    ];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
