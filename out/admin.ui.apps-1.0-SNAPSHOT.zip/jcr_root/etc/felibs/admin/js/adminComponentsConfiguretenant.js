var cmpAdminComponentsConfiguretenant = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        methods: {
            editRootTemplate: function editRootTemplate(me, target) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction('editTemplate', ("/content/" + tenant + "/templates") );
            },
            tenantSetupReplication: function tenantSetupReplication(me, target) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction('tenantSetupReplication', ("/content/" + tenant), 'true');
            },
            backupTenant: function backupTenant(me, target) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction('backupTenant', ("/content/" + tenant));
            },
            uploadBackupTenant: function uploadBackupTenant(me, target) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction('uploadBackupTenant', ("/content/" + tenant), 'test-file.zip');
            },
            restoreTenant: function restoreTenant(me, target) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction('restoreTenant', ("/content/" + tenant));
            },
            addFiles: function addFiles (ev) {
                this.uploadFile(ev.target.files);
            },
            uploadFile: function uploadFile(files) {
                var tenant = $perAdminApp.getView().state.tenant.name;
                $perAdminApp.stateAction(
                    'uploadBackupTenant',
                    {
                        path: ("/content/" + tenant),
                        files: files,
                        cb: this.fileUploadComplete
                    }
                );
            },
            fileUploadComplete: function fileUploadComplete(percentCompleted) {
                return
            }
        },
        computed: {
            // Build up the Download URL with the tenant name
            downloadUrl: function downloadUrl() {
                var tenant = $perAdminApp.getView().state.tenant;
                return tenant ? '/perapi/admin/downloadBackupTenant.zip/content/' + tenant.name : '';
            },
            backupInfo: function backupInfo() {
                return $perAdminApp.getView().state.tools.backup
            },
            backupDate: function backupDate() {
                var backup = $perAdminApp.getView().state.tools.backup;
                return backup ? backup.last : "No Backup Info for Date";
            },
            backupState: function backupState() {
                var backup = $perAdminApp.getView().state.tools.backup;
                var state = backup ? backup.state : '';
                if(state === '') {
                   state = 'No Backup Info for State';
                } else if(state === 'SUCCEEDED') {
                    state = 'Successfully Built';
                } else {
                    state = 'Failed Build';
                }
                return state;
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", [
        _c(
          "div",
          [
            _c("admin-components-action", {
              attrs: {
                model: {
                  command: "editRootTemplate",
                  title: "configure website root template",
                  target: "/content/admin/pages/templates/edit",
                  classes: "btn"
                }
              }
            }),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "\n            The root template references all your domain names this website\n            is exposed at as well as yout js/css includes, prefetch domains and\n            your brand slug \n        "
              )
            ])
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          [
            _c("admin-components-action", {
              attrs: {
                model: {
                  command: "tenantSetupReplication",
                  title: "site setup replication",
                  target: "/content/admin/pages/templates/edit",
                  classes: "btn"
                }
              }
            }),
            _vm._v(" "),
            _c("p", [
              _vm._v(
                "\n            Use the 'site setup replication' button to go live with your whole\n            site and push all the necessary information out to your web server.\n            Once you're live you can easily push any new pages or page changes\n            out in the admin console.   \n        "
              )
            ])
          ],
          1
        ),
        _vm._v(" "),
        _c("h2", [_vm._v("backup and restore")]),
        _vm._v(" "),
        _c(
          "div",
          [
            _c("admin-components-action", {
              attrs: {
                model: {
                  command: "backupTenant",
                  title: "backup site",
                  target: "/content/admin/pages/templates/edit",
                  tooltipTitle: "Create Backup of this Site",
                  classes: "btn"
                }
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c("div", [
          _c(
            "a",
            {
              staticClass: "btn",
              attrs: {
                href: _vm.downloadUrl,
                title: "Download the latest Backup",
                target: "_blank"
              }
            },
            [_vm._v("download site backup")]
          )
        ]),
        _vm._v(" "),
        _c("div", [
          _c(
            "label",
            {
              staticClass: "btn",
              attrs: { title: "Upload a Site Backup to this Server" }
            },
            [
              _vm._v("\n            Upload Site Backup File\n            "),
              _c("input", {
                ref: "file_upload",
                staticStyle: { display: "none" },
                attrs: { type: "file" },
                on: { change: _vm.addFiles }
              }),
              _vm._v(" "),
              _c("i", { staticClass: "material-icons" }, [_vm._v("file_upload")])
            ]
          )
        ]),
        _vm._v(" "),
        _c(
          "div",
          [
            _c("admin-components-action", {
              attrs: {
                model: {
                  command: "restoreTenant",
                  title: "restore site",
                  target: "/content/admin/pages/templates/edit",
                  tooltipTitle: "Restore the latest Site Backup",
                  classes: "btn"
                }
              }
            })
          ],
          1
        ),
        _vm._v(" "),
        _c("div", [
          _c("p", [_vm._v("Latest Site Backup")]),
          _vm._v(" "),
          _c("p", [
            _c("b", [_vm._v("Date:")]),
            _vm._v(" " + _vm._s(_vm.backupDate))
          ]),
          _vm._v(" "),
          _c("p", [
            _c("b", [_vm._v("Result:")]),
            _vm._v(" " + _vm._s(_vm.backupState))
          ])
        ])
      ])
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
