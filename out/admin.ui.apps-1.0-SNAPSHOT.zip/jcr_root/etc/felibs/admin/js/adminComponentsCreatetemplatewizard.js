var cmpAdminComponentsCreatetemplatewizard = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        data:
            function() {
                var this$1 = this;

                var path = $perAdminApp.getNodeFromView('/state/tools/templates');
                var siteName = path.split('/')[3];
                return {
                    formErrors: {
                        unselectedComponentError: false
                    },
                    formmodel: {
                        path: path,
                        name: '',
                        title: '',
                        component: null
                    },
                    formOptions: {
                        validationErrorClass: "has-error",
                        validationSuccessClass: "has-success",
                        validateAfterChanged: true,
                        focusFirstField: true
                    },
                    nameChanged: false,
                    nameSchema: {
                        fields: [
                            {
                                type: "input",
                                inputType: "text",
                                label: "Template Title",
                                model: "title",
                                required: true,
                                onChanged: function (model, newVal, oldVal, field) {
                                    if(!this$1.nameChanged) {
                                        this$1.formmodel.name = $perAdminApp.normalizeString(newVal);
                                    }
                                }
                            },
                            {
                            type: "input",
                            inputType: "text",
                            label: "Template Name",
                            model: "name",
                            required: true,
                            onChanged: function (model, newVal, oldVal, field) {
                                this$1.nameChanged = true;
                            },
                            validator: [this.nameAvailable, this.validTemplateName]
                        }
                        ]
                    }
                }

        },
        created: function() {
            //By default select the first item in the list;
            this.selectComponent(this, this.components[0].path);
        },
        computed: {
            components: function() {
                var tenant = $perAdminApp.getView().state.tenant || {name: 'example'};
                var components = $perAdminApp.getNodeFromViewOrNull('/admin/components/data');
                var siteRootParts = this.formmodel.path.split('/').slice(0,4);
                siteRootParts[1] = 'apps';
                siteRootParts[2] = tenant.name;
                var siteRoot = siteRootParts.slice(0,3).join('/');
                return components.filter( function (component) { return component.path.startsWith(siteRoot)
                    && (component.name === 'page' || component.templateComponent); }
                )
            }
        }
        ,
        methods: {
            selectComponent: function(me, target){
                if(me === null) { me = this; }
                me.formmodel.component = target;

                this.validateTabOne(me);
            },
            nameAvailable: function nameAvailable(value) {
                if(!value || value.length === 0) {
                    return ['name is required']
                } else {
                    var folder = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, this.formmodel.path);
                    for(var i = 0; i < folder.children.length; i++) {
                        if(folder.children[i].name === value) {
                            return ['name aready in use']
                        }
                    }
                    return []
                }
            },
            validTemplateName: function validTemplateName(value) {
                if(!value || value.length === 0) {
                    return ['name is required']
                }
                if(value.match(/[^0-9a-zA-Z_-]/)) {
                    return ['template names may only contain letters, numbers, underscores, and dashes']
                }
                return [];
            },
            isSelected: function(target) {
                return this.formmodel.component === target
            },
            onComplete: function() {
                var path = this.formmodel.path;
                var siteName = path.split('/')[3];
                var component = this.formmodel.component.substring(this.formmodel.component.indexOf('/',1)+1);
                $perAdminApp.stateAction('createTemplate', { parent: this.formmodel.path, name: this.formmodel.name, component: component, title: this.formmodel.title });
            },
            validateTabOne: function(me) {
                me.formErrors.unselectedComponentError = (!me.formmodel.component);

                return !me.formErrors.unselectedComponentError;
            },
            leaveTabOne: function() {
                return this.validateTabOne(this);
            },
            leaveTabTwo: function() {
                return this.$refs.nameTab.validate()
            }


        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        { staticClass: "container" },
        [
          _c(
            "form-wizard",
            {
              attrs: {
                title: "create a template",
                subtitle: "",
                "error-color": "#d32f2f",
                color: "#546e7a"
              },
              on: { "on-complete": _vm.onComplete }
            },
            [
              _c(
                "tab-content",
                {
                  attrs: {
                    title: "select component",
                    "before-change": _vm.leaveTabOne
                  }
                },
                [
                  _c("fieldset", { staticClass: "vue-form-generator" }, [
                    _c("div", { staticClass: "form-group required" }, [
                      _c("label", [_vm._v("Select Component")]),
                      _vm._v(" "),
                      _c(
                        "ul",
                        { staticClass: "collection" },
                        _vm._l(_vm.components, function(component) {
                          return _c(
                            "li",
                            {
                              staticClass: "collection-item",
                              class: _vm.isSelected(component.path) ? "active" : "",
                              on: {
                                click: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.selectComponent(null, component.path)
                                }
                              }
                            },
                            [
                              _c("admin-components-action", {
                                attrs: {
                                  model: {
                                    command: "selectComponent",
                                    target: component.path,
                                    title: component.name
                                  }
                                }
                              })
                            ],
                            1
                          )
                        }),
                        0
                      ),
                      _vm._v(" "),
                      _vm.formErrors.unselectedComponentError
                        ? _c("div", { staticClass: "errors" }, [
                            _c("span", { attrs: { "track-by": "index" } }, [
                              _vm._v("selection required")
                            ])
                          ])
                        : _vm._e()
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "tab-content",
                {
                  attrs: { title: "choose name", "before-change": _vm.leaveTabTwo }
                },
                [
                  _c("vue-form-generator", {
                    ref: "nameTab",
                    attrs: {
                      model: _vm.formmodel,
                      schema: _vm.nameSchema,
                      options: _vm.formOptions
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c("tab-content", { attrs: { title: "verify" } }, [
                _c("pre", {
                  domProps: {
                    innerHTML: _vm._s(JSON.stringify(_vm.formmodel, true, 2))
                  }
                })
              ])
            ],
            1
          )
        ],
        1
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
