var cmpAdminComponentsExplorer = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function set(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(vue) {
          Vue.set(node, path[0], value);
      }
      else {
          node[path[0]] = value;
      }
  }

  //

  var script = {
      props: ['model'],

      data: function data() {
          return {
              isDraggingFile: false,
              isDraggingUiEl: false,
              isFileUploadVisible: false,
              uploadProgress: 0
          }
      },

      computed: {
          showNavigateToParent: function showNavigateToParent() {
              return this.path.split('/').length > 4
          },
          path: function() {
              var dataFrom = this.model.dataFrom;
              var node = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom);
              return node
          },
          pt: function() {
              var node = this.path;
              return $perAdminApp.findNodeFromPath(this.$root.$data.admin.nodes, node)
          },
          children: function() {
              var this$1 = this;

              if ( this.pt.children ) {
                  return this.pt.children.filter( function (child) { return this$1.checkIfAllowed(child.resourceType); } )
              }
          },
          parentPath: function() {
              var segments = this.$data.path.value.toString().split('/');
              var joined = segments.slice(0, segments.length - 1).join('/');
              return joined
          },
          pathSegments: function() {
              var segments = this.path.toString().split('/');
              var ret = [];
              for(var i = 1; i < segments.length; i++) {
                  ret.push( { name: segments[i], path: segments.slice(0, i+1).join('/') } );
              }
              return ret;
          },
          hasEdit: function() {
              return this.model.children && this.model.children[0]
          }
      },
      methods: {
          getTenant: function getTenant() {
            return $perAdminApp.getView().state.tenant || {name: 'example'}
          },

          isAssets: function isAssets(path) {
              return path.startsWith(("/content/" + (this.getTenant().name) + "/assets"))
          },

          isPages: function isPages(path) {
              return path.startsWith(("/content/" + (this.getTenant().name) + "/pages"))
          },

          isObjects: function isObjects(path) {
              return path.startsWith(("/content/" + (this.getTenant().name) + "/objects"))
          },

          isTemplates: function isTemplates(path) {

              return path.startsWith(("/content/" + (this.getTenant().name) + "/templates"))
          },

          selectParent: function selectParent(me, target) {
              var dataFrom = !me ? this.model.dataFrom : me.model.dataFrom;
              var path = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom);
              var pathSegments = path.split('/');
              pathSegments.pop();
              path = pathSegments.join('/');
              $perAdminApp.action(!me ? this: me, 'selectPath', { path: path, resourceType: 'sling:OrderedFolder'});
          },

          selectItem: function selectItem(item) {
              $perAdminApp.action(this, 'selectPath', item);
          },

          replicatedClass: function replicatedClass(item) {
              if(item.ReplicationStatus) {
                  var created = item.created;
                  var modified = item.lastModified ? item.lastModified : created;
                  var replicated = item.Replicated;
                  if(replicated > modified) {
                      return 'item-'+item.ReplicationStatus
                  } else {
                      return 'item-'+item.ReplicationStatus+'-modified'
                  }
              }
              return 'item-replication-unknown'
          },

          replicate: function replicate(me, path) {
              $perAdminApp.stateAction('replicate', path);
          },

          replicable: function replicable(item) {
              return true
          },

          onDragRowStart: function onDragRowStart(item, ev) {
              ev.srcElement.classList.add("dragging");
              ev.dataTransfer.setData('text', item.path);
              if(this.isDraggingFile) { this.isDraggingFile = false; }
              this.isDraggingUiEl = true;
          },

          onDragRow: function onDragRow(ev) {
              ev.srcElement.classList.remove("dragging");
          },

          onDragRowEnd: function onDragRowEnd(item, ev) {
              this.isDraggingUiEl = false;
          },

          onDragOverRow: function onDragOverRow(ev) {
              if(this.isDraggingUiEl) {
                  var center = ev.target.offsetHeight / 2 ;
                  this.dropType = ev.offsetY > center ? 'after' : 'before';
                  ev.target.classList.toggle('drop-after', ev.offsetY > center );
                  ev.target.classList.toggle('drop-before', ev.offsetY < center );
              }
          },

          onDragEnterRow: function onDragEnterRow(ev) {
          },

          onDragLeaveRow: function onDragLeaveRow(ev) {
              if(this.isDraggingUiEl) {
                  ev.target.classList.remove('drop-after','drop-before');
              }
          },

          onDropRow: function onDropRow(item, ev, type) {
              if(this.isDraggingUiEl) {
                  ev.target.classList.remove('drop-after','drop-before');
                  var dataFrom = this.model.dataFrom;
                  var path = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom);
                  var action;
                  switch(true) {
                      case (this.isPages(path)):
                          action = 'movePage';
                          break
                      case (this.isTemplates(path)):
                          action = 'moveTemplate';
                          break
                      case (this.isObjects(path)):
                          action = 'moveObject';
                          break
                      case (this.isAssets(path)):
                          action = 'moveAsset';
                          break
                      default:
                          console.warn('path is not a site, asset, template or object.');
                  }
                  $perAdminApp.stateAction(action, {
                      path: ev.dataTransfer.getData("text"),
                      to: item.path,
                      type: this.dropType
                  });
              }
          },

          onDragOverExplorer: function onDragOverExplorer(ev) {
          },

          onDragEnterExplorer: function onDragEnterExplorer(ev) {
              if(!this.isAssets(this.path)) { return }
              if(this.isDraggingUiEl) { return }
              this.isDraggingFile = true;
              this.isFileUploadVisible = true;
          },

          onDragLeaveExplorer: function onDragLeaveExplorer(ev) {
              /* hide upload overlay */
              /* TODO: fix upload unexpectedly closing
              if(this.isDraggingFile) {
                  this.isDraggingFile = false
              }
              */
          },

          onDropExplorer: function onDropExplorer(ev) {
              if(!this.isAssets(this.path)) { return }
              if(this.isDraggingUiEl) { return }
              if(this.isDraggingFile) {
                  this.uploadFile(ev.dataTransfer.files);
                  this.isDraggingFile = false;
              }
          },

          uploadFile: function uploadFile(files) {
            $perAdminApp.stateAction('uploadFiles', {
              path: $perAdminApp.getView().state.tools.assets,
              files: files,
              cb: this.setUploadProgress
            });
          },

          setUploadProgress: function setUploadProgress(percentCompleted) {
            this.uploadProgress = percentCompleted;
          },

          onDoneFileUpload: function onDoneFileUpload() {
              this.isFileUploadVisible = false;
              this.uploadProgress = 0;
          },

          isSelected: function(child) {
              if(this.model.selectionFrom && child) {
                  return $perAdminApp.getNodeFromViewOrNull(this.model.selectionFrom) === child.path
              } else if(child.path === $perAdminApp.getNodeFromViewOrNull('/state/tools/page')) {
                  return true
              }
              return false

          },

          hasChildren: function(child) {
              return child && child.childCount && child.childCount > 0;
          },

          editable: function(child) {
              return ['per:Page', 'per:Object'].indexOf(child.resourceType) >= 0
          },

          composumEditable: function(child) {
              return ['nt:file'].indexOf(child.resourceType) >= 0
          },

          viewable: function(child) {
              return ['per:Page', 'per:Object', 'nt:file'].indexOf(child.resourceType) >= 0
          },

          viewUrl: function(child) {
              var path = child.path;
              var segments = path.split('/');
              var last = segments.pop();
              if(last.indexOf('.') >= 0) {
                  return path
              }
              if(child.resourceType === 'per:Page') {
                  return path + '.html'
              }
              return path + '.json'
          },

          nodeTypeToIcon: function(nodeType) {
              if(nodeType === 'per:Page')             { return 'description' }
              if(nodeType === 'per:Object')           { return 'layers' }
              if(nodeType === 'nt:file')              { return 'insert_drive_file' }
              if(nodeType === 'per:Asset')            { return 'image' }
              if(nodeType === 'sling:Folder')         { return 'folder' }
              if(nodeType === 'sling:OrderedFolder')  { return 'folder' }
              return 'unknown'
          },

          checkIfAllowed: function(resourceType) {
              return ['per:Asset', 'nt:file', 'sling:Folder', 'sling:OrderedFolder', 'per:Page', 'sling:OrderedFolder', 'per:Object'].indexOf(resourceType) >= 0
          },

          showInfo: function(me, target) {
              var tenant = $perAdminApp.getView().state.tenant;
              if(target.startsWith(("/content/" + (tenant.name) + "/objects"))) {
                  var node = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, target);
                  $perAdminApp.stateAction('selectObject', { selected: node.path, path: me.model.dataFrom });
              } else if (target.startsWith(("/content/" + (tenant.name) + "/templates"))) {
                  $perAdminApp.stateAction('showTemplateInfo', { selected: target });
              } else {
                  $perAdminApp.stateAction('showPageInfo', { selected: target });
              }
          },

          showRow: function(item, ev) {
              if (this.editable(item)) {
                  this.showInfo(this, item.path);
              }
          },

          selectPath: function(me, target) {
              var resourceType = target.resourceType;
              if(resourceType) {
                  if(resourceType === 'per:Object') {
                      $perAdminApp.stateAction('selectObject', { selected: target.path, path: me.model.dataFrom });
                      return
                  }
                  if(resourceType === 'per:Asset') {
                      $perAdminApp.stateAction('selectAsset', { selected: target.path });
                      return
                  } else if(resourceType === 'nt:file') {
                      return
                  }
              }
              if($perAdminApp.getNodeFromView('/state/tools/object/show')) {
                  $perAdminApp.stateAction('unselectObject', { });
              }
              if($perAdminApp.getNodeFromView('/state/tools/asset/show')) {
                  $perAdminApp.stateAction('unselectAsset', { });
              }
              var payload = { selected: target.path, path: me.model.dataFrom };
              $perAdminApp.stateAction('selectToolsNodesPath', payload).then( function () {
                  $('div.brand-logo span').last().click(); //TODO: quick and dirty solution!!!!
              });
          },

          selectPathInNav: function(me, target) {
              this.selectPath(me, target);
          },

          addSite: function(me, target) {
              $perAdminApp.stateAction('createTenantWizard', '/content');
          },

          addPage: function(me, target) {
              var tenant = $perAdminApp.getView().state.tenant;
              var path = me.pt.path;
              if(path.startsWith(("/content/" + (tenant.name) + "/pages"))) {
                  $perAdminApp.stateAction('createPageWizard', path);
              }
          },

          addTemplate: function(me, target) {
              var tenant = $perAdminApp.getView().state.tenant;
              var path = me.pt.path;
              if(path.startsWith(("/content/" + (tenant.name) + "/templates"))) {
                  $perAdminApp.stateAction('createTemplateWizard', path);
              }
          },

          addObject: function(me, target) {
              var tenant = $perAdminApp.getView().state.tenant;
              var path = me.pt.path;
              if(path.startsWith(("/content/" + (tenant.name) + "/objects"))) {
                  $perAdminApp.stateAction('createObjectWizard', { path: path, target: target });
              }
          },

          addFolder: function(me, target) {
              var tenant = $perAdminApp.getView().state.tenant;
              var path = me.pt.path;
              if(path.startsWith(("/content/" + (tenant.name) + "/assets"))) {
                  $perAdminApp.stateAction('createAssetFolderWizard', path);
              } else if(path.startsWith(("/content/" + (tenant.name) + "/objects"))) {
                  $perAdminApp.stateAction('createObjectFolderWizard', path);
              }
          },

          sourceImage: function(me, target) {
              $perAdminApp.stateAction('sourceImageWizard', me.pt.path);
          },

          deleteTenantOrPage: function(me, target) {
              if(me.path === '/content') {
                  me.deleteTenant(me, target);
              } else {
                  me.deletePage(me, target);
              }
          },

          deletePage: function(me, target) {
              $perAdminApp.askUser('Delete Page', me.$i18n('Are you sure you want to delete this node and all its children?'), {
                  yes: function yes() {
                      var resourceType = target.resourceType;
                      if(resourceType === 'per:Object') {
                          $perAdminApp.stateAction('deleteObject', target.path);
                      } else if(resourceType === 'per:Asset') {
                          $perAdminApp.stateAction('deleteAsset', target.path);
                      } else if(resourceType === 'sling:OrderedFolder') {
                          $perAdminApp.stateAction('deleteFolder', target.path);
                      } else if(resourceType === 'per:Page') {
                          $perAdminApp.stateAction('deletePage', target.path);
                      } else if(resourceType === 'nt:file') {
                          $perAdminApp.stateAction('deleteFile', target.path);
                      }else {
                          $perAdminApp.stateAction('deleteFolder', target.path);
                      }
                  }
              });
          },

          deleteTenant: function(me, target) {
              $perAdminApp.askUser('Delete Site', me.$i18n('Are you sure you want to delete this site, its children, and generated content and components?'), {
                  yes: function yes() {
                      $perAdminApp.stateAction('deleteTenant', target);
                  }
              });
          },

          editReference: function(me, target) {
              if(target.load) {
                  $perAdminApp.loadContent(target.load);
              } else {
                  me.editPage(me, target.target);
              }
          },

          editPage: function(me, target) {

              var view = $perAdminApp.getView();
              var tenant = view.state.tenant;
              var path = me.pt.path;

              if(target.startsWith(("/content/" + (tenant.name) + "/pages"))) {
                  set(view, '/state/tools/page', target);
              } else if(target.startsWith(("/content/" + (tenant.name) + "/templates"))) {
                  set(view, '/state/tools/template', target);
              }

              if(target.startsWith(("/content/" + (tenant.name) + "/objects"))) {
                  var node = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, target);
                  me.selectedObject = path;
                  $perAdminApp.stateAction('editObject', { selected: node.path, path: me.model.dataFrom });
              } else if (target.startsWith(("/content/" + (tenant.name) + "/templates"))) {
                  $perAdminApp.stateAction('editTemplate', target );
              } else {
                  $perAdminApp.stateAction('editPage', target );
              }
          },

          editFile: function(me, target) {
              window.open(("/bin/cpm/edit/code.html" + target), 'composum');
          }
      }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
  function createInjector(context) {
    return function (id, style) {
      return addStyle(id, style);
    };
  }
  var HEAD = document.head || document.getElementsByTagName('head')[0];
  var styles = {};

  function addStyle(id, css) {
    var group = isOldIE ? css.media || 'default' : id;
    var style = styles[group] || (styles[group] = {
      ids: new Set(),
      styles: []
    });

    if (!style.ids.has(id)) {
      style.ids.add(id);
      var code = css.source;

      if (css.map) {
        // https://developer.chrome.com/devtools/docs/javascript-debugging
        // this makes source maps inside style tags work properly in Chrome
        code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

        code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
      }

      if (!style.element) {
        style.element = document.createElement('style');
        style.element.type = 'text/css';
        if (css.media) { style.element.setAttribute('media', css.media); }
        HEAD.appendChild(style.element);
      }

      if ('styleSheet' in style.element) {
        style.styles.push(code);
        style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
      } else {
        var index = style.ids.size - 1;
        var textNode = document.createTextNode(code);
        var nodes = style.element.childNodes;
        if (nodes[index]) { style.element.removeChild(nodes[index]); }
        if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
      }
    }
  }

  var browser = createInjector;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      {
        staticClass: "explorer",
        on: {
          dragover: function($event) {
            $event.preventDefault();
            return _vm.onDragOverExplorer($event)
          },
          dragenter: function($event) {
            $event.preventDefault();
            return _vm.onDragEnterExplorer($event)
          },
          dragleave: function($event) {
            $event.preventDefault();
            return _vm.onDragLeaveExplorer($event)
          },
          drop: function($event) {
            $event.preventDefault();
            return _vm.onDropExplorer($event)
          }
        }
      },
      [
        _c("div", { staticClass: "explorer-layout" }, [
          _c(
            "div",
            { staticClass: "row" },
            [
              _vm.pt
                ? _c("div", { staticClass: "col s12 m8 explorer-main" }, [
                    _c(
                      "ul",
                      { staticClass: "collection" },
                      [
                        _vm.showNavigateToParent
                          ? _c(
                              "li",
                              {
                                staticClass: "collection-item",
                                on: {
                                  click: function($event) {
                                    $event.stopPropagation();
                                    $event.preventDefault();
                                    return _vm.selectParent()
                                  }
                                }
                              },
                              [
                                _c(
                                  "admin-components-action",
                                  {
                                    attrs: {
                                      model: {
                                        target: null,
                                        command: "selectParent",
                                        tooltipTitle: _vm.$i18n("backToParentDir")
                                      }
                                    }
                                  },
                                  [
                                    _c("i", { staticClass: "material-icons" }, [
                                      _vm._v("folder_open")
                                    ]),
                                    _c("i", { staticClass: "material-icons" }, [
                                      _vm._v("arrow_upward")
                                    ])
                                  ]
                                )
                              ],
                              1
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm._l(_vm.children, function(child) {
                          return _c(
                            "li",
                            {
                              key: child.path,
                              class:
                                "collection-item " +
                                (_vm.isSelected(child)
                                  ? "explorer-item-selected"
                                  : ""),
                              attrs: { draggable: "true" },
                              on: {
                                dragstart: function($event) {
                                  return _vm.onDragRowStart(child, $event)
                                },
                                drag: _vm.onDragRow,
                                click: function($event) {
                                  return _vm.showRow(child, $event)
                                },
                                dragend: function($event) {
                                  return _vm.onDragRowEnd(child, $event)
                                },
                                dragenter: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.onDragEnterRow($event)
                                },
                                dragover: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.onDragOverRow($event)
                                },
                                dragleave: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.onDragLeaveRow($event)
                                },
                                drop: function($event) {
                                  $event.preventDefault();
                                  return _vm.onDropRow(child, $event)
                                }
                              }
                            },
                            [
                              _c("admin-components-draghandle"),
                              _vm._v(" "),
                              _vm.editable(child)
                                ? _c(
                                    "admin-components-action",
                                    {
                                      attrs: {
                                        model: {
                                          target: child,
                                          command: "selectPath",
                                          tooltipTitle:
                                            _vm.$i18n("select") +
                                            " '" +
                                            (child.title || child.name) +
                                            "'"
                                        }
                                      }
                                    },
                                    [
                                      _c("i", { staticClass: "material-icons" }, [
                                        _vm._v("folder")
                                      ])
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _vm.editable(child)
                                ? _c(
                                    "admin-components-action",
                                    {
                                      attrs: {
                                        model: {
                                          target: child.path,
                                          command: "editPage",
                                          dblClickTarget: child,
                                          dblClickCommand: "selectPath",
                                          tooltipTitle:
                                            _vm.$i18n("edit") +
                                            " '" +
                                            (child.title || child.name) +
                                            "'"
                                        }
                                      }
                                    },
                                    [
                                      _c("i", { staticClass: "material-icons" }, [
                                        _vm._v(
                                          _vm._s(
                                            _vm.nodeTypeToIcon(child.resourceType)
                                          )
                                        )
                                      ]),
                                      _vm._v(
                                        " " +
                                          _vm._s(
                                            child.title ? child.title : child.name
                                          ) +
                                          "\n                    "
                                      )
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              !_vm.editable(child)
                                ? _c(
                                    "admin-components-action",
                                    {
                                      attrs: {
                                        model: {
                                          target: child,
                                          command: "selectPath",
                                          tooltipTitle:
                                            _vm.$i18n("select") +
                                            " '" +
                                            (child.title || child.name) +
                                            "'"
                                        }
                                      }
                                    },
                                    [
                                      _c("i", { staticClass: "material-icons" }, [
                                        _vm._v(
                                          _vm._s(
                                            _vm.nodeTypeToIcon(child.resourceType)
                                          )
                                        )
                                      ]),
                                      _vm._v(
                                        " " +
                                          _vm._s(
                                            child.title ? child.title : child.name
                                          ) +
                                          "\n                    "
                                      )
                                    ]
                                  )
                                : _vm._e(),
                              _vm._v(" "),
                              _c("admin-components-extensions", {
                                attrs: {
                                  model: {
                                    id: "admin.components.explorer",
                                    item: child
                                  }
                                }
                              }),
                              _vm._v(" "),
                              _c(
                                "div",
                                { staticClass: "secondary-content" },
                                [
                                  _vm.editable(child)
                                    ? _c(
                                        "admin-components-action",
                                        {
                                          attrs: {
                                            model: {
                                              target: child.path,
                                              command: "editPage",
                                              tooltipTitle:
                                                _vm.$i18n("edit") +
                                                " '" +
                                                (child.title || child.name) +
                                                "'"
                                            }
                                          }
                                        },
                                        [_c("admin-components-iconeditpage")],
                                        1
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.composumEditable(child)
                                    ? _c(
                                        "admin-components-action",
                                        {
                                          attrs: {
                                            model: {
                                              target: child.path,
                                              command: "editFile",
                                              tooltipTitle:
                                                _vm.$i18n("editFile") +
                                                " '" +
                                                (child.title || child.name) +
                                                "'"
                                            }
                                          }
                                        },
                                        [_c("admin-components-iconeditpage")],
                                        1
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.replicable(child)
                                    ? _c(
                                        "admin-components-action",
                                        {
                                          attrs: {
                                            model: {
                                              target: child.path,
                                              command: "replicate",
                                              tooltipTitle:
                                                _vm.$i18n("replicate") +
                                                " '" +
                                                (child.title || child.name) +
                                                "'"
                                            }
                                          }
                                        },
                                        [
                                          _c(
                                            "i",
                                            {
                                              staticClass: "material-icons",
                                              class: _vm.replicatedClass(child)
                                            },
                                            [_vm._v("public")]
                                          )
                                        ]
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.editable(child)
                                    ? _c(
                                        "admin-components-action",
                                        {
                                          attrs: {
                                            model: {
                                              target: child.path,
                                              command: "showInfo",
                                              tooltipTitle:
                                                "'" +
                                                (child.title || child.name) +
                                                "' " +
                                                _vm.$i18n("info")
                                            }
                                          }
                                        },
                                        [
                                          _c(
                                            "i",
                                            { staticClass: "material-icons" },
                                            [_vm._v("info")]
                                          )
                                        ]
                                      )
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _vm.viewable(child)
                                    ? _c("span", [
                                        _c(
                                          "a",
                                          {
                                            attrs: {
                                              target: "viewer",
                                              href: _vm.viewUrl(child),
                                              title:
                                                _vm.$i18n("view") +
                                                " '" +
                                                (child.title || child.name) +
                                                "' " +
                                                _vm.$i18n("inNewTab")
                                            },
                                            on: {
                                              click: function($event) {
                                                $event.stopPropagation();
                                              }
                                            }
                                          },
                                          [
                                            _c(
                                              "i",
                                              { staticClass: "material-icons" },
                                              [_vm._v("visibility")]
                                            )
                                          ]
                                        )
                                      ])
                                    : _vm._e(),
                                  _vm._v(" "),
                                  _c(
                                    "admin-components-action",
                                    {
                                      attrs: {
                                        model: {
                                          target: child,
                                          command: "deleteTenantOrPage",
                                          tooltipTitle:
                                            _vm.$i18n("delete") +
                                            " '" +
                                            (child.title || child.name) +
                                            "'"
                                        }
                                      }
                                    },
                                    [
                                      _c("i", { staticClass: "material-icons" }, [
                                        _vm._v("delete")
                                      ])
                                    ]
                                  )
                                ],
                                1
                              )
                            ],
                            1
                          )
                        }),
                        _vm._v(" "),
                        _vm.isPages(_vm.path)
                          ? _c(
                              "li",
                              { staticClass: "collection-item" },
                              [
                                _c(
                                  "admin-components-action",
                                  {
                                    attrs: {
                                      model: {
                                        target: "",
                                        command: "addPage",
                                        tooltipTitle: "" + _vm.$i18n("add page")
                                      }
                                    }
                                  },
                                  [
                                    _c("i", { staticClass: "material-icons" }, [
                                      _vm._v("add_circle")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.$i18n("add page")) +
                                        "\n                    "
                                    )
                                  ]
                                )
                              ],
                              1
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.isObjects(_vm.path)
                          ? _c(
                              "li",
                              { staticClass: "collection-item" },
                              [
                                _c(
                                  "admin-components-action",
                                  {
                                    attrs: {
                                      model: {
                                        target: "",
                                        command: "addObject",
                                        tooltipTitle: "" + _vm.$i18n("add object")
                                      }
                                    }
                                  },
                                  [
                                    _c("i", { staticClass: "material-icons" }, [
                                      _vm._v("add_circle")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.$i18n("add object")) +
                                        "\n                    "
                                    )
                                  ]
                                )
                              ],
                              1
                            )
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.isTemplates(_vm.path)
                          ? _c(
                              "li",
                              { staticClass: "collection-item" },
                              [
                                _c(
                                  "admin-components-action",
                                  {
                                    attrs: {
                                      model: {
                                        target: "",
                                        command: "addTemplate",
                                        tooltipTitle:
                                          "" + _vm.$i18n("add template")
                                      }
                                    }
                                  },
                                  [
                                    _c("i", { staticClass: "material-icons" }, [
                                      _vm._v("add_circle")
                                    ]),
                                    _vm._v(
                                      " " +
                                        _vm._s(_vm.$i18n("add template")) +
                                        "\n                    "
                                    )
                                  ]
                                )
                              ],
                              1
                            )
                          : _vm._e()
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _vm.children && _vm.children.length == 0
                      ? _c("div", { staticClass: "empty-explorer" }, [
                          _vm.path.includes("assets")
                            ? _c("div", [
                                _vm._v(
                                  "\n                    " +
                                    _vm._s(_vm.$i18n("emptyExplorerHintAssets")) +
                                    ".\n                "
                                )
                              ])
                            : _c("div", [
                                _vm._v(
                                  "\n                    " +
                                    _vm._s(_vm.$i18n("emptyExplorerHint")) +
                                    "...\n                "
                                )
                              ])
                        ])
                      : _vm._e()
                  ])
                : _c(
                    "div",
                    { staticClass: "col s12 m8 explorer-main explorer-empty" },
                    [
                      _c("div", [
                        _c("span", [_vm._v(_vm._s(_vm.$i18n("nothing to show")))])
                      ])
                    ]
                  ),
              _vm._v(" "),
              _vm.hasEdit
                ? _c(
                    "admin-components-explorerpreview",
                    [
                      _c(_vm.model.children[0].component, {
                        tag: "component",
                        attrs: { model: _vm.model.children[0] }
                      })
                    ],
                    1
                  )
                : _vm._e()
            ],
            1
          )
        ]),
        _vm._v(" "),
        _vm.isFileUploadVisible
          ? _c("div", { staticClass: "file-upload" }, [
              _c("div", { staticClass: "file-upload-inner" }, [
                _c("i", { staticClass: "material-icons" }, [
                  _vm._v("file_download")
                ]),
                _vm._v(" "),
                _c("span", { staticClass: "file-upload-text" }, [
                  _vm._v("Drag & Drop files anywhere")
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "progress-bar" }, [
                  _c("div", {
                    staticClass: "progress-bar-value",
                    style: "width: " + _vm.uploadProgress + "%"
                  })
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "progress-text" }, [
                  _vm._v(_vm._s(_vm.uploadProgress) + "%")
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "file-upload-action" }, [
                  _c(
                    "button",
                    {
                      staticClass: "btn",
                      attrs: { type: "button" },
                      on: { click: _vm.onDoneFileUpload }
                    },
                    [_vm._v("ok")]
                  )
                ])
              ])
            ])
          : _vm._e()
      ]
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = function (inject) {
      if (!inject) { return }
      inject("data-v-5aeef192_0", { source: "\n.item-activated {\n    color: green;\n}\n.item-replication-unknown {\n}\n.item-deactivated {\n    color: red;\n}\n.item-activated-modified {\n    color: purple;\n}\n.explorer-empty {\n    display: flex;\n    justify-content: center;\n    align-items: center;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/explorer/template.vue"],"names":[],"mappings":";AAopBA;IACA,YAAA;AACA;AAEA;AACA;AAEA;IACA,UAAA;AACA;AAEA;IACA,aAAA;AACA;AAEA;IACA,aAAA;IACA,uBAAA;IACA,mBAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n\n  http://www.apache.org/licenses/LICENSE-2.0\n\n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n<div class=\"explorer\"\n    v-on:dragover.prevent  =\"onDragOverExplorer\"\n    v-on:dragenter.prevent =\"onDragEnterExplorer\"\n    v-on:dragleave.prevent =\"onDragLeaveExplorer\"\n    v-on:drop.prevent      =\"onDropExplorer\">\n\n    <div class=\"explorer-layout\">\n    <div class=\"row\">\n        <div v-if=\"pt\" class=\"col s12 m8 explorer-main\">\n            <ul class=\"collection\">\n                <li v-if=\"showNavigateToParent\"\n                    v-on:click.stop.prevent=\"selectParent()\"\n                    class=\"collection-item\">\n                    <admin-components-action\n                            v-bind:model=\"{\n                            target: null,\n                            command: 'selectParent',\n                            tooltipTitle: $i18n('backToParentDir')\n                        }\"><i class=\"material-icons\">folder_open</i><i class=\"material-icons\">arrow_upward</i>\n                    </admin-components-action>\n                </li>\n                <li\n                    v-for =\"child in children\"\n                    v-bind:key=\"child.path\"\n                    v-bind:class=\"`collection-item ${isSelected(child) ? 'explorer-item-selected' : ''}`\"\n                    draggable =\"true\"\n                    v-on:dragstart =\"onDragRowStart(child,$event)\"\n                    v-on:drag      =\"onDragRow\"\n                    v-on:click     =\"showRow(child,$event)\"\n                    v-on:dragend   =\"onDragRowEnd(child,$event)\"\n                    v-on:dragenter.stop.prevent =\"onDragEnterRow\"\n                    v-on:dragover.stop.prevent  =\"onDragOverRow\"\n                    v-on:dragleave.stop.prevent =\"onDragLeaveRow\"\n                    v-on:drop.prevent      =\"onDropRow(child, $event)\">\n\n                    <admin-components-draghandle/>\n\n                    <admin-components-action v-if=\"editable(child)\"\n                                             v-bind:model=\"{\n                                target: child,\n                                command: 'selectPath',\n                                tooltipTitle: `${$i18n('select')} '${child.title || child.name}'`\n                            }\">\n                        <i class=\"material-icons\">folder</i>\n                    </admin-components-action>\n\n                    <admin-components-action v-if=\"editable(child)\"\n                        v-bind:model=\"{\n                            target: child.path,\n                            command: 'editPage',\n                            dblClickTarget: child,\n                            dblClickCommand: 'selectPath',\n                            tooltipTitle: `${$i18n('edit')} '${child.title || child.name}'`\n                        }\"><i class=\"material-icons\">{{nodeTypeToIcon(child.resourceType)}}</i> {{child.title ? child.title : child.name}}\n                    </admin-components-action>\n\n                    <admin-components-action v-if=\"!editable(child)\"\n                        v-bind:model=\"{\n                            target: child,\n                            command: 'selectPath',\n                            tooltipTitle: `${$i18n('select')} '${child.title || child.name}'`\n                        }\"><i class=\"material-icons\">{{nodeTypeToIcon(child.resourceType)}}</i> {{child.title ? child.title : child.name}}\n                    </admin-components-action>\n\n                    <admin-components-extensions v-bind:model=\"{id: 'admin.components.explorer', item: child}\"></admin-components-extensions>\n\n                    <div class=\"secondary-content\">\n                        <admin-components-action v-if=\"editable(child)\"\n                            v-bind:model=\"{\n                                target: child.path,\n                                command: 'editPage',\n                                tooltipTitle: `${$i18n('edit')} '${child.title || child.name}'`\n                            }\">\n                            <admin-components-iconeditpage></admin-components-iconeditpage>\n                        </admin-components-action>\n\n                        <admin-components-action v-if=\"composumEditable(child)\"\n                            v-bind:model=\"{\n                                target: child.path,\n                                command: 'editFile',\n                                tooltipTitle: `${$i18n('editFile')} '${child.title || child.name}'`\n                            }\">\n                            <admin-components-iconeditpage></admin-components-iconeditpage>\n                        </admin-components-action>\n\n                        <admin-components-action v-if=\"replicable(child)\"\n                            v-bind:model=\"{\n                                target: child.path,\n                                command: 'replicate',\n                                tooltipTitle: `${$i18n('replicate')} '${child.title || child.name}'`\n                            }\">\n                            <i class=\"material-icons\" v-bind:class=\"replicatedClass(child)\">public</i>\n                        </admin-components-action>\n\n                        <admin-components-action v-if=\"editable(child)\"\n                            v-bind:model=\"{\n                                target: child.path,\n                                command: 'showInfo',\n                                tooltipTitle: `'${child.title || child.name}' ${$i18n('info')}`\n                            }\">\n                            <i class=\"material-icons\">info</i>\n                        </admin-components-action>\n\n                        <span v-if=\"viewable(child)\">\n                            <a\n                                target      =\"viewer\"\n                                v-bind:href =\"viewUrl(child)\"\n                                v-on:click.stop  =\"\"\n                                v-bind:title=\"`${$i18n('view')} '${child.title || child.name}' ${$i18n('inNewTab')}`\"\n                                >\n                                <i class=\"material-icons\">visibility</i>\n                            </a>\n                        </span>\n\n                        <admin-components-action\n                            v-bind:model=\"{\n                                target: child,\n                                command: 'deleteTenantOrPage',\n                                tooltipTitle: `${$i18n('delete')} '${child.title || child.name}'`\n                            }\">\n                            <i class=\"material-icons\">delete</i>\n                        </admin-components-action>\n                    </div>\n                </li>\n                <li class=\"collection-item\" v-if=\"isPages(path)\">\n                    <admin-components-action\n                        v-bind:model=\"{\n                            target: '',\n                            command: 'addPage',\n                            tooltipTitle: `${$i18n('add page')}`\n                        }\">\n                            <i class=\"material-icons\">add_circle</i> {{$i18n('add page')}}\n                    </admin-components-action>\n                </li>\n                <li class=\"collection-item\" v-if=\"isObjects(path)\">\n                    <admin-components-action\n                        v-bind:model=\"{\n                            target: '',\n                            command: 'addObject',\n                            tooltipTitle: `${$i18n('add object')}`\n                        }\">\n                            <i class=\"material-icons\">add_circle</i> {{$i18n('add object')}}\n                    </admin-components-action>\n                </li>\n                <li class=\"collection-item\" v-if=\"isTemplates(path)\">\n                    <admin-components-action\n                        v-bind:model=\"{\n                            target: '',\n                            command: 'addTemplate',\n                            tooltipTitle: `${$i18n('add template')}`\n                        }\">\n                            <i class=\"material-icons\">add_circle</i> {{$i18n('add template')}}\n                    </admin-components-action>\n                </li>\n            </ul>\n            <div v-if=\"children && children.length == 0\" class=\"empty-explorer\">\n                <div v-if=\"path.includes('assets')\">\n                    {{ $i18n('emptyExplorerHintAssets') }}.\n                </div>\n                <div v-else>\n                    {{ $i18n('emptyExplorerHint') }}...\n                </div>\n            </div>\n        </div>\n        <div v-else class=\"col s12 m8 explorer-main explorer-empty\">\n            <div>\n                <span>{{ $i18n(`nothing to show`) }}</span>\n            </div>\n        </div>\n        <admin-components-explorerpreview v-if=\"hasEdit\">\n            <component v-bind:is=\"model.children[0].component\" v-bind:model=\"model.children[0]\"></component>\n        </admin-components-explorerpreview>\n    </div>\n    </div>\n\n    <div v-if=\"isFileUploadVisible\" class=\"file-upload\">\n        <div class=\"file-upload-inner\">\n            <i class=\"material-icons\">file_download</i>\n            <span class=\"file-upload-text\">Drag &amp; Drop files anywhere</span>\n            <div class=\"progress-bar\">\n                <div class=\"progress-bar-value\" v-bind:style=\"`width: ${uploadProgress}%`\"></div>\n            </div>\n            <div class=\"progress-text\">{{uploadProgress}}%</div>\n            <div class=\"file-upload-action\">\n                <button\n                    type=\"button\"\n                    class=\"btn\"\n                    v-on:click=\"onDoneFileUpload\">ok</button>\n            </div>\n            <!-- <progress class=\"file-upload-progress\" v-bind:value=\"uploadProgress\" max=\"100\"></progress> -->\n        </div>\n    </div>\n    <!--\n    <template v-for=\"child in model.children[0].children\">\n        <component v-bind:is=\"child.component\" v-bind:model=\"child\"></component>\n    </template>\n    -->\n</div>\n</template>\n\n<script>\n\n    import {set} from '../../../../../../js/utils';\n\n    export default {\n        props: ['model'],\n\n        data() {\n            return {\n                isDraggingFile: false,\n                isDraggingUiEl: false,\n                isFileUploadVisible: false,\n                uploadProgress: 0\n            }\n        },\n\n        computed: {\n            showNavigateToParent() {\n                return this.path.split('/').length > 4\n            },\n            path: function() {\n                var dataFrom = this.model.dataFrom\n                var node = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom)\n                return node\n            },\n            pt: function() {\n                var node = this.path\n                return $perAdminApp.findNodeFromPath(this.$root.$data.admin.nodes, node)\n            },\n            children: function() {\n                if ( this.pt.children ) {\n                    return this.pt.children.filter( child => this.checkIfAllowed(child.resourceType) )\n                }\n            },\n            parentPath: function() {\n                var segments = this.$data.path.value.toString().split('/')\n                var joined = segments.slice(0, segments.length - 1).join('/')\n                return joined\n            },\n            pathSegments: function() {\n                var segments = this.path.toString().split('/')\n                var ret = []\n                for(var i = 1; i < segments.length; i++) {\n                    ret.push( { name: segments[i], path: segments.slice(0, i+1).join('/') } )\n                }\n                return ret;\n            },\n            hasEdit: function() {\n                return this.model.children && this.model.children[0]\n            }\n        },\n        methods: {\n            getTenant() {\n              return $perAdminApp.getView().state.tenant || {name: 'example'}\n            },\n\n            isAssets(path) {\n                return path.startsWith(`/content/${this.getTenant().name}/assets`)\n            },\n\n            isPages(path) {\n                return path.startsWith(`/content/${this.getTenant().name}/pages`)\n            },\n\n            isObjects(path) {\n                return path.startsWith(`/content/${this.getTenant().name}/objects`)\n            },\n\n            isTemplates(path) {\n\n                return path.startsWith(`/content/${this.getTenant().name}/templates`)\n            },\n\n            selectParent(me, target) {\n                var dataFrom = !me ? this.model.dataFrom : me.model.dataFrom\n                var path = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom)\n                var pathSegments = path.split('/')\n                pathSegments.pop()\n                path = pathSegments.join('/')\n                $perAdminApp.action(!me ? this: me, 'selectPath', { path: path, resourceType: 'sling:OrderedFolder'})\n            },\n\n            selectItem(item) {\n                $perAdminApp.action(this, 'selectPath', item)\n            },\n\n            replicatedClass(item) {\n                if(item.ReplicationStatus) {\n                    const created = item.created\n                    const modified = item.lastModified ? item.lastModified : created\n                    const replicated = item.Replicated\n                    if(replicated > modified) {\n                        return 'item-'+item.ReplicationStatus\n                    } else {\n                        return 'item-'+item.ReplicationStatus+'-modified'\n                    }\n                }\n                return 'item-replication-unknown'\n            },\n\n            replicate(me, path) {\n                $perAdminApp.stateAction('replicate', path)\n            },\n\n            replicable(item) {\n                return true\n            },\n\n            onDragRowStart(item, ev) {\n                ev.srcElement.classList.add(\"dragging\");\n                ev.dataTransfer.setData('text', item.path)\n                if(this.isDraggingFile) { this.isDraggingFile = false }\n                this.isDraggingUiEl = true\n            },\n\n            onDragRow(ev) {\n                ev.srcElement.classList.remove(\"dragging\");\n            },\n\n            onDragRowEnd(item, ev) {\n                this.isDraggingUiEl = false\n            },\n\n            onDragOverRow(ev) {\n                if(this.isDraggingUiEl) {\n                    const center = ev.target.offsetHeight / 2 ;\n                    this.dropType = ev.offsetY > center ? 'after' : 'before';\n                    ev.target.classList.toggle('drop-after', ev.offsetY > center );\n                    ev.target.classList.toggle('drop-before', ev.offsetY < center );\n                }\n            },\n\n            onDragEnterRow(ev) {\n            },\n\n            onDragLeaveRow(ev) {\n                if(this.isDraggingUiEl) {\n                    ev.target.classList.remove('drop-after','drop-before')\n                }\n            },\n\n            onDropRow(item, ev, type) {\n                if(this.isDraggingUiEl) {\n                    ev.target.classList.remove('drop-after','drop-before')\n                    const dataFrom = this.model.dataFrom\n                    const path = $perAdminApp.getNodeFrom($perAdminApp.getView(), dataFrom)\n                    let action\n                    switch(true) {\n                        case (this.isPages(path)):\n                            action = 'movePage'\n                            break\n                        case (this.isTemplates(path)):\n                            action = 'moveTemplate'\n                            break\n                        case (this.isObjects(path)):\n                            action = 'moveObject'\n                            break\n                        case (this.isAssets(path)):\n                            action = 'moveAsset'\n                            break\n                        default:\n                            console.warn('path is not a site, asset, template or object.')\n                    }\n                    $perAdminApp.stateAction(action, {\n                        path: ev.dataTransfer.getData(\"text\"),\n                        to: item.path,\n                        type: this.dropType\n                    })\n                }\n            },\n\n            onDragOverExplorer(ev) {\n            },\n\n            onDragEnterExplorer(ev) {\n                if(!this.isAssets(this.path)) return\n                if(this.isDraggingUiEl) return\n                this.isDraggingFile = true\n                this.isFileUploadVisible = true\n            },\n\n            onDragLeaveExplorer(ev) {\n                /* hide upload overlay */\n                /* TODO: fix upload unexpectedly closing\n                if(this.isDraggingFile) {\n                    this.isDraggingFile = false\n                }\n                */\n            },\n\n            onDropExplorer(ev) {\n                if(!this.isAssets(this.path)) return\n                if(this.isDraggingUiEl) return\n                if(this.isDraggingFile) {\n                    this.uploadFile(ev.dataTransfer.files)\n                    this.isDraggingFile = false\n                }\n            },\n\n            uploadFile(files) {\n              $perAdminApp.stateAction('uploadFiles', {\n                path: $perAdminApp.getView().state.tools.assets,\n                files: files,\n                cb: this.setUploadProgress\n              })\n            },\n\n            setUploadProgress(percentCompleted) {\n              this.uploadProgress = percentCompleted\n            },\n\n            onDoneFileUpload() {\n                this.isFileUploadVisible = false\n                this.uploadProgress = 0\n            },\n\n            isSelected: function(child) {\n                if(this.model.selectionFrom && child) {\n                    return $perAdminApp.getNodeFromViewOrNull(this.model.selectionFrom) === child.path\n                } else if(child.path === $perAdminApp.getNodeFromViewOrNull('/state/tools/page')) {\n                    return true\n                }\n                return false\n\n            },\n\n            hasChildren: function(child) {\n                return child && child.childCount && child.childCount > 0;\n            },\n\n            editable: function(child) {\n                return ['per:Page', 'per:Object'].indexOf(child.resourceType) >= 0\n            },\n\n            composumEditable: function(child) {\n                return ['nt:file'].indexOf(child.resourceType) >= 0\n            },\n\n            viewable: function(child) {\n                return ['per:Page', 'per:Object', 'nt:file'].indexOf(child.resourceType) >= 0\n            },\n\n            viewUrl: function(child) {\n                var path = child.path\n                var segments = path.split('/')\n                var last = segments.pop()\n                if(last.indexOf('.') >= 0) {\n                    return path\n                }\n                if(child.resourceType === 'per:Page') {\n                    return path + '.html'\n                }\n                return path + '.json'\n            },\n\n            nodeTypeToIcon: function(nodeType) {\n                if(nodeType === 'per:Page')             return 'description'\n                if(nodeType === 'per:Object')           return 'layers'\n                if(nodeType === 'nt:file')              return 'insert_drive_file'\n                if(nodeType === 'per:Asset')            return 'image'\n                if(nodeType === 'sling:Folder')         return 'folder'\n                if(nodeType === 'sling:OrderedFolder')  return 'folder'\n                return 'unknown'\n            },\n\n            checkIfAllowed: function(resourceType) {\n                return ['per:Asset', 'nt:file', 'sling:Folder', 'sling:OrderedFolder', 'per:Page', 'sling:OrderedFolder', 'per:Object'].indexOf(resourceType) >= 0\n            },\n\n            showInfo: function(me, target) {\n                const tenant = $perAdminApp.getView().state.tenant\n                if(target.startsWith(`/content/${tenant.name}/objects`)) {\n                    const node = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, target)\n                    $perAdminApp.stateAction('selectObject', { selected: node.path, path: me.model.dataFrom })\n                } else if (target.startsWith(`/content/${tenant.name}/templates`)) {\n                    $perAdminApp.stateAction('showTemplateInfo', { selected: target })\n                } else {\n                    $perAdminApp.stateAction('showPageInfo', { selected: target })\n                }\n            },\n\n            showRow: function(item, ev) {\n                if (this.editable(item)) {\n                    this.showInfo(this, item.path);\n                }\n            },\n\n            selectPath: function(me, target) {\n                let resourceType = target.resourceType\n                if(resourceType) {\n                    if(resourceType === 'per:Object') {\n                        $perAdminApp.stateAction('selectObject', { selected: target.path, path: me.model.dataFrom })\n                        return\n                    }\n                    if(resourceType === 'per:Asset') {\n                        $perAdminApp.stateAction('selectAsset', { selected: target.path })\n                        return\n                    } else if(resourceType === 'nt:file') {\n                        return\n                    }\n                }\n                if($perAdminApp.getNodeFromView('/state/tools/object/show')) {\n                    $perAdminApp.stateAction('unselectObject', { })\n                }\n                if($perAdminApp.getNodeFromView('/state/tools/asset/show')) {\n                    $perAdminApp.stateAction('unselectAsset', { })\n                }\n                const payload = { selected: target.path, path: me.model.dataFrom }\n                $perAdminApp.stateAction('selectToolsNodesPath', payload).then( () => {\n                    $('div.brand-logo span').last().click() //TODO: quick and dirty solution!!!!\n                })\n            },\n\n            selectPathInNav: function(me, target) {\n                this.selectPath(me, target)\n            },\n\n            addSite: function(me, target) {\n                $perAdminApp.stateAction('createTenantWizard', '/content')\n            },\n\n            addPage: function(me, target) {\n                const tenant = $perAdminApp.getView().state.tenant\n                const path = me.pt.path\n                if(path.startsWith(`/content/${tenant.name}/pages`)) {\n                    $perAdminApp.stateAction('createPageWizard', path)\n                }\n            },\n\n            addTemplate: function(me, target) {\n                const tenant = $perAdminApp.getView().state.tenant\n                const path = me.pt.path\n                if(path.startsWith(`/content/${tenant.name}/templates`)) {\n                    $perAdminApp.stateAction('createTemplateWizard', path)\n                }\n            },\n\n            addObject: function(me, target) {\n                const tenant = $perAdminApp.getView().state.tenant\n                const path = me.pt.path\n                if(path.startsWith(`/content/${tenant.name}/objects`)) {\n                    $perAdminApp.stateAction('createObjectWizard', { path: path, target: target })\n                }\n            },\n\n            addFolder: function(me, target) {\n                const tenant = $perAdminApp.getView().state.tenant\n                const path = me.pt.path\n                if(path.startsWith(`/content/${tenant.name}/assets`)) {\n                    $perAdminApp.stateAction('createAssetFolderWizard', path)\n                } else if(path.startsWith(`/content/${tenant.name}/objects`)) {\n                    $perAdminApp.stateAction('createObjectFolderWizard', path)\n                }\n            },\n\n            sourceImage: function(me, target) {\n                $perAdminApp.stateAction('sourceImageWizard', me.pt.path)\n            },\n\n            deleteTenantOrPage: function(me, target) {\n                if(me.path === '/content') {\n                    me.deleteTenant(me, target)\n                } else {\n                    me.deletePage(me, target)\n                }\n            },\n\n            deletePage: function(me, target) {\n                $perAdminApp.askUser('Delete Page', me.$i18n('Are you sure you want to delete this node and all its children?'), {\n                    yes() {\n                        const resourceType = target.resourceType\n                        if(resourceType === 'per:Object') {\n                            $perAdminApp.stateAction('deleteObject', target.path)\n                        } else if(resourceType === 'per:Asset') {\n                            $perAdminApp.stateAction('deleteAsset', target.path)\n                        } else if(resourceType === 'sling:OrderedFolder') {\n                            $perAdminApp.stateAction('deleteFolder', target.path)\n                        } else if(resourceType === 'per:Page') {\n                            $perAdminApp.stateAction('deletePage', target.path)\n                        } else if(resourceType === 'nt:file') {\n                            $perAdminApp.stateAction('deleteFile', target.path)\n                        }else {\n                            $perAdminApp.stateAction('deleteFolder', target.path)\n                        }\n                    }\n                })\n            },\n\n            deleteTenant: function(me, target) {\n                $perAdminApp.askUser('Delete Site', me.$i18n('Are you sure you want to delete this site, its children, and generated content and components?'), {\n                    yes() {\n                        $perAdminApp.stateAction('deleteTenant', target)\n                    }\n                })\n            },\n\n            editReference: function(me, target) {\n                if(target.load) {\n                    $perAdminApp.loadContent(target.load)\n                } else {\n                    me.editPage(me, target.target)\n                }\n            },\n\n            editPage: function(me, target) {\n\n                const view = $perAdminApp.getView()\n                const tenant = view.state.tenant\n                const path = me.pt.path\n\n                if(target.startsWith(`/content/${tenant.name}/pages`)) {\n                    set(view, '/state/tools/page', target)\n                } else if(target.startsWith(`/content/${tenant.name}/templates`)) {\n                    set(view, '/state/tools/template', target)\n                }\n\n                if(target.startsWith(`/content/${tenant.name}/objects`)) {\n                    const node = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, target)\n                    me.selectedObject = path\n                    $perAdminApp.stateAction('editObject', { selected: node.path, path: me.model.dataFrom })\n                } else if (target.startsWith(`/content/${tenant.name}/templates`)) {\n                    $perAdminApp.stateAction('editTemplate', target )\n                } else {\n                    $perAdminApp.stateAction('editPage', target )\n                }\n            },\n\n            editFile: function(me, target) {\n                window.open(`/bin/cpm/edit/code.html${target}`, 'composum')\n            }\n        }\n    }\n</script>\n\n<style>\n    .item-activated {\n        color: green;\n    }\n\n    .item-replication-unknown {\n    }\n\n    .item-deactivated {\n        color: red;\n    }\n\n    .item-activated-modified {\n        color: purple;\n    }\n\n    .explorer-empty {\n        display: flex;\n        justify-content: center;\n        align-items: center;\n    }\n</style>\n"]}, media: undefined });

    };
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      browser,
      undefined
    );

  return template;

}());
