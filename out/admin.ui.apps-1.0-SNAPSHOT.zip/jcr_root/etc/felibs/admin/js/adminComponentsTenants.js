var cmpAdminComponentsTenants = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        data: function data(){
            return {
                isDraggingFile: false,
                isDraggingUiEl: false,
                isFileUploadVisible: false,
                uploadProgress: 0,
                tab: {
                    active: 0,
                    items: ['Websites', 'Website Themes', 'Internal Websites']
                }
            }
        },
        computed: {
            children: function() {
                var tenants = $perAdminApp.getNodeFrom($perAdminApp.getView(), '/admin/tenants');
                if(tenants) {
                    if (this.tab.active === 1) {
                        return tenants.filter( function (t) { return t.template; })
                    } else if (this.tab.active === 2) {
                        return tenants.filter( function (t) { return t.internal; } );
                    } else {
                        return tenants.filter( function (t) { return !t.template && !t.internal; })
                    }
                }
                return [];
            }
        },
        created: function created() {
        },
        methods: {
            selectTenant: function selectTenant(vm, target) {
                $perAdminApp.stateAction('setTenant', { name: target.name }).then( function () {
                    $perAdminApp.loadContent(("/content/admin/pages/welcome.html/path:/content/" + (target.name)));
                });
            },

            deleteTenant: function(me, target) {
                $perAdminApp.askUser('Delete Site', me.$i18n('Are you sure you want to delete this site, its children, and generated content and components?'), {
                    yes: function yes() {
                        $perAdminApp.stateAction('deleteTenant', target);
                    }
                });
            },

            onCardContentClick: function onCardContentClick(name) {
                this.selectTenant(this, { name: name });
            },

            onCreateNewSiteClick: function onCreateNewSiteClick() {
                $perAdminApp.action(this, 'selectPath', '/content/admin/pages/pages/createtenant');
            },

            onTabClick: function onTabClick(index) {
                this.tab.active = index;
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        {
          staticClass: "row",
          staticStyle: {
            border: "solid silver 2px",
            "box-shadow": "3px 3px 4px lightgray",
            "margin-right": "10px"
          }
        },
        [
          _c(
            "div",
            { staticClass: "tenant-tabs" },
            _vm._l(_vm.tab.items, function(item, index) {
              return _c(
                "div",
                {
                  key: item,
                  staticClass: "tab",
                  class: { active: _vm.tab.active === index },
                  on: {
                    click: function($event) {
                      return _vm.onTabClick(index)
                    }
                  }
                },
                [_vm._v("\n            " + _vm._s(item) + "\n        ")]
              )
            }),
            0
          ),
          _vm._v(" "),
          _c(
            "div",
            { staticClass: "tenant-collection" },
            [
              _vm.children && _vm.children.length > 0
                ? _vm._l(_vm.children, function(child) {
                    return _c(
                      "div",
                      {
                        key: child.name,
                        staticClass: "col s12 m6 l6 icon-action m-left-inherit"
                      },
                      [
                        _c("div", { staticClass: "card blue-grey darken-3" }, [
                          _c(
                            "div",
                            {
                              staticClass: "card-content white-text tenant-link",
                              on: {
                                click: function($event) {
                                  return _vm.onCardContentClick(child.name)
                                }
                              }
                            },
                            [
                              _c("span", { staticClass: "card-title" }, [
                                _vm._v(
                                  _vm._s(child.title ? child.title : child.name)
                                )
                              ]),
                              _vm._v(" "),
                              _c("p", [_vm._v(_vm._s(child.description))])
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            { staticClass: "card-action" },
                            [
                              _c(
                                "admin-components-action",
                                {
                                  attrs: {
                                    model: {
                                      target: {
                                        path:
                                          "/content/admin/pages/welcome.html/pages:/content/" +
                                          child.name,
                                        name: child.name
                                      },
                                      command: "selectTenant",
                                      tooltipTitle:
                                        _vm.$i18n("edit") +
                                        " '" +
                                        (child.title || child.name) +
                                        "'"
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v("edit")
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "admin-components-action",
                                {
                                  attrs: {
                                    model: {
                                      target: {
                                        path:
                                          "/content/admin/pages/tenants/configure.html/path:/content/" +
                                          child.name,
                                        name: child.name
                                      },
                                      command: "configureTenant",
                                      tooltipTitle:
                                        _vm.$i18n("configure") +
                                        " '" +
                                        (child.title || child.name) +
                                        "'"
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v("settings")
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "admin-components-action",
                                {
                                  attrs: {
                                    model: {
                                      target: {
                                        path: "/content/admin/pages/index.html",
                                        name: child.name
                                      },
                                      command: "deleteTenant",
                                      tooltipTitle:
                                        _vm.$i18n("delete") +
                                        " '" +
                                        (child.title || child.name) +
                                        "'"
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v("delete")
                                  ])
                                ]
                              )
                            ],
                            1
                          )
                        ])
                      ]
                    )
                  })
                : [_vm._m(0)]
            ],
            2
          ),
          _vm._v(" "),
          _vm.tab.active === 0
            ? _c("div", { staticClass: "tenant-actions" }, [
                _c(
                  "div",
                  {
                    staticClass: "create-tenant action",
                    on: { click: _vm.onCreateNewSiteClick }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("note_add")
                    ]),
                    _vm._v("\n            Create new website\n        ")
                  ]
                )
              ])
            : _vm._e()
        ]
      )
    };
    var __vue_staticRenderFns__ = [
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("div", { staticClass: "no-websites-found" }, [
          _c("p", [_vm._v("No websites found")]),
          _vm._v("\n                Start by creating a new one!\n            ")
        ])
      }
    ];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-40ba9262_0", { source: "\nfieldset[data-v-40ba9262] {\n    border: none;\n}\n.tenant-link[data-v-40ba9262]:hover {\n    background-color: rgba(255, 255, 255, .05);\n    cursor: pointer;\n}\n.card-action[data-v-40ba9262] {\n    display: flex;\n    justify-content: space-between;\n}\n.tenant-tabs[data-v-40ba9262],\n.tenant-actions[data-v-40ba9262]{\n    width: 100%;\n    display: flex;\n    justify-content: flex-start;\n    align-items: center;\n    height: 50px;\n    background-color: #eeeeee;\n}\n.tenant-tabs[data-v-40ba9262] {\n    border-bottom: 2px solid silver;\n}\n.tenant-tabs .tab[data-v-40ba9262] {\n    height: 100%;\n    width: 33.333333333%;\n    justify-content: center;\n    align-items: center;\n    display: flex;\n    cursor: pointer;\n    transition: background-color .35s ease-out;\n}\n.tenant-tabs .tab[data-v-40ba9262]:hover,\n.tenant-tabs .tab.active[data-v-40ba9262] {\n    background-color: rgba(0, 0, 0, .1);\n}\n.tenant-actions[data-v-40ba9262] {\n    border-top: 2px solid silver;\n    display: flex;\n    justify-content: center;\n}\n.tenant-actions .action[data-v-40ba9262] {\n    width: 250px;\n    height: 90%;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    color: #ffff;\n    background-color: rgba(55, 71, 79, 1);\n    cursor: pointer;\n    border-radius: 3px;\n}\n.tenant-actions .action[data-v-40ba9262]:hover {\n    background-color: rgba(55, 71, 79, .92);\n}\n.tenant-actions .action i.material-icons[data-v-40ba9262] {\n    color: #ffab40;\n    margin-right: 10px;\n}\n.tenant-collection[data-v-40ba9262] {\n    min-height: 272px;\n    display: flex;\n    flex-wrap: wrap;\n}\n.tenant-collection .card[data-v-40ba9262] {\n    min-height: 250px;\n}\n.tenant-collection .card .card-content[data-v-40ba9262] {\n    min-height: 187px;\n}\n.tenant-collection .no-websites-found[data-v-40ba9262] {\n    width: 100%;\n    display: flex;\n    justify-content: center;\n    align-items: center;\n    flex-direction: column;\n    color: #b4b4b4;\n    font-size: 12px;\n    font-weight: 400;\n}\n.no-websites-found p[data-v-40ba9262] {\n    font-size: 20px;\n}\n.m-left-inherit[data-v-40ba9262] {\n    margin-left: inherit !important;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/tenants/template.vue"],"names":[],"mappings":";AAmKA;IACA,YAAA;AACA;AAEA;IACA,0CAAA;IACA,eAAA;AACA;AAEA;IACA,aAAA;IACA,8BAAA;AACA;AAEA;;IAEA,WAAA;IACA,aAAA;IACA,2BAAA;IACA,mBAAA;IACA,YAAA;IACA,yBAAA;AACA;AAEA;IACA,+BAAA;AACA;AAEA;IACA,YAAA;IACA,oBAAA;IACA,uBAAA;IACA,mBAAA;IACA,aAAA;IACA,eAAA;IACA,0CAAA;AACA;AAEA;;IAEA,mCAAA;AACA;AAEA;IACA,4BAAA;IACA,aAAA;IACA,uBAAA;AACA;AAEA;IACA,YAAA;IACA,WAAA;IACA,aAAA;IACA,uBAAA;IACA,mBAAA;IACA,YAAA;IACA,qCAAA;IACA,eAAA;IACA,kBAAA;AACA;AAEA;IACA,uCAAA;AACA;AAEA;IACA,cAAA;IACA,kBAAA;AACA;AAEA;IACA,iBAAA;IACA,aAAA;IACA,eAAA;AACA;AAEA;IACA,iBAAA;AACA;AAEA;IACA,iBAAA;AACA;AAEA;IACA,WAAA;IACA,aAAA;IACA,uBAAA;IACA,mBAAA;IACA,sBAAA;IACA,cAAA;IACA,eAAA;IACA,gBAAA;AACA;AAEA;IACA,eAAA;AACA;AAEA;IACA,+BAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  http://www.apache.org/licenses/LICENSE-2.0\n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n\n    <div class=\"row\" style=\"border: solid silver 2px; box-shadow: 3px 3px 4px lightgray; margin-right: 10px;\">\n        <div class=\"tenant-tabs\">\n            <div v-for=\"(item, index) in tab.items\"\n                 class=\"tab\"\n                 :key=\"item\"\n                 :class=\"{active: tab.active === index}\"\n                 @click=\"onTabClick(index)\">\n                {{ item }}\n            </div>\n        </div>\n        <div class=\"tenant-collection\">\n            <template v-if=\"children && children.length > 0\">\n                <div class=\"col s12 m6 l6 icon-action m-left-inherit\" v-for=\"child in children\" v-bind:key=\"child.name\">\n                    <div class=\"card blue-grey darken-3\">\n                        <div class=\"card-content white-text tenant-link\" @click=\"onCardContentClick(child.name)\">\n                            <span class=\"card-title\">{{child.title ? child.title : child.name}}</span>\n                            <p>{{child.description}}</p>\n                        </div>\n                        <div class=\"card-action\">\n                            <admin-components-action\n                                v-bind:model=\"{\n                                    target: { \n                                        path: '/content/admin/pages/welcome.html/pages:/content/' + child.name, \n                                        name: child.name \n                                    },\n                                    command: 'selectTenant',\n                                    tooltipTitle: `${$i18n('edit')} '${child.title || child.name}'`\n                                }\">\n                                <i class=\"material-icons\">edit</i>\n                            </admin-components-action>\n\n                            <admin-components-action\n                                v-bind:model=\"{\n                                    target: { \n                                        path: '/content/admin/pages/tenants/configure.html/path:/content/' + child.name,\n                                        name: child.name \n                                    },\n                                    command: 'configureTenant',\n                                    tooltipTitle: `${$i18n('configure')} '${child.title || child.name}'`\n                                }\">\n                                <i class=\"material-icons\">settings</i>\n                            </admin-components-action>\n\n\n                            <admin-components-action\n                                v-bind:model=\"{\n                                    target: { \n                                        path: '/content/admin/pages/index.html',\n                                        name: child.name \n                                    },\n                                    command: 'deleteTenant',\n                                    tooltipTitle: `${$i18n('delete')} '${child.title || child.name}'`\n                                }\">\n                                <i class=\"material-icons\">delete</i>\n                            </admin-components-action>\n                        </div>\n                    </div>\n                </div>\n            </template>\n            <template v-else>\n                <div class=\"no-websites-found\">\n                    <p>No websites found</p>\n                    Start by creating a new one!\n                </div>\n            </template>\n        </div>\n        <div v-if=\"tab.active === 0\" class=\"tenant-actions\">\n            <div class=\"create-tenant action\" @click=\"onCreateNewSiteClick\">\n                <i class=\"material-icons\">note_add</i>\n                Create new website\n            </div>\n        </div>\n    </div>\n\n</template>\n\n<script>\n    export default {\n        props: ['model'],\n        data(){\n            return {\n                isDraggingFile: false,\n                isDraggingUiEl: false,\n                isFileUploadVisible: false,\n                uploadProgress: 0,\n                tab: {\n                    active: 0,\n                    items: ['Websites', 'Website Themes', 'Internal Websites']\n                }\n            }\n        },\n        computed: {\n            children: function() {\n                const tenants = $perAdminApp.getNodeFrom($perAdminApp.getView(), '/admin/tenants')\n                if(tenants) {\n                    if (this.tab.active === 1) {\n                        return tenants.filter( (t) => t.template)\n                    } else if (this.tab.active === 2) {\n                        return tenants.filter( (t) => t.internal );\n                    } else {\n                        return tenants.filter( (t) => !t.template && !t.internal)\n                    }\n                }\n                return [];\n            }\n        },\n        created() {\n        },\n        methods: {\n            selectTenant(vm, target) {\n                $perAdminApp.stateAction('setTenant', { name: target.name }).then( () => {\n                    $perAdminApp.loadContent(`/content/admin/pages/welcome.html/path:/content/${target.name}`)\n                });\n            },\n\n            deleteTenant: function(me, target) {\n                $perAdminApp.askUser('Delete Site', me.$i18n('Are you sure you want to delete this site, its children, and generated content and components?'), {\n                    yes() {\n                        $perAdminApp.stateAction('deleteTenant', target)\n                    }\n                })\n            },\n\n            onCardContentClick(name) {\n                this.selectTenant(this, { name })\n            },\n\n            onCreateNewSiteClick() {\n                $perAdminApp.action(this, 'selectPath', '/content/admin/pages/pages/createtenant')\n            },\n\n            onTabClick(index) {\n                this.tab.active = index\n            }\n        }\n    }\n</script>\n\n<style scoped>\n    fieldset {\n        border: none;\n    }\n\n    .tenant-link:hover {\n        background-color: rgba(255, 255, 255, .05);\n        cursor: pointer;\n    }\n\n    .card-action {\n        display: flex;\n        justify-content: space-between;\n    }\n\n    .tenant-tabs,\n    .tenant-actions{\n        width: 100%;\n        display: flex;\n        justify-content: flex-start;\n        align-items: center;\n        height: 50px;\n        background-color: #eeeeee;\n    }\n\n    .tenant-tabs {\n        border-bottom: 2px solid silver;\n    }\n\n    .tenant-tabs .tab {\n        height: 100%;\n        width: 33.333333333%;\n        justify-content: center;\n        align-items: center;\n        display: flex;\n        cursor: pointer;\n        transition: background-color .35s ease-out;\n    }\n\n    .tenant-tabs .tab:hover,\n    .tenant-tabs .tab.active {\n        background-color: rgba(0, 0, 0, .1);\n    }\n\n    .tenant-actions {\n        border-top: 2px solid silver;\n        display: flex;\n        justify-content: center;\n    }\n\n    .tenant-actions .action {\n        width: 250px;\n        height: 90%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        color: #ffff;\n        background-color: rgba(55, 71, 79, 1);\n        cursor: pointer;\n        border-radius: 3px;\n    }\n\n    .tenant-actions .action:hover {\n        background-color: rgba(55, 71, 79, .92);\n    }\n\n    .tenant-actions .action i.material-icons {\n        color: #ffab40;\n        margin-right: 10px;\n    }\n\n    .tenant-collection {\n        min-height: 272px;\n        display: flex;\n        flex-wrap: wrap;\n    }\n\n    .tenant-collection .card {\n        min-height: 250px;\n    }\n\n    .tenant-collection .card .card-content {\n        min-height: 187px;\n    }\n\n    .tenant-collection .no-websites-found {\n        width: 100%;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n        flex-direction: column;\n        color: #b4b4b4;\n        font-size: 12px;\n        font-weight: 400;\n    }\n\n    .no-websites-found p {\n        font-size: 20px;\n    }\n\n    .m-left-inherit {\n        margin-left: inherit !important;\n    }\n</style>"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = "data-v-40ba9262";
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
