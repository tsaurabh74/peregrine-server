var cmpAdminComponentsExplorerpreviewcontent = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var SUFFIX_PARAM_SEPARATOR = ':';
  var Icon = {
    LABEL: 'label',
    SETTINGS: 'settings',
    TEXT_FORMAT: 'text_format',
    COMPARE_ARROWS: 'compare_arrows',
    DELETE: 'delete',
    INFO: 'info',
    EDIT: 'edit',
    LIST: 'list',
    CHECK: 'check',
    CHECKED: 'check_box',
    UNCHECKED: 'check_box_outline_blank',
    CANCEL: 'close',
    CREATE: 'create',
    MORE_VERT: 'more_vert',
    VERSIONS: 'restore_page'
  };
  var NodeType = {
    PAGE: 'page',
    TEMPLATE: 'template',
    ASSET: 'asset',
    OBJECT: 'object'
  };
  var MimeType = {
    Image: {
      PNG: 'image/png',
      JPG: 'image/jpg',
      JPEG: 'image/jpeg',
      GIF: 'image/gif',
      TIFF: 'image/tiff',
      SVG: 'image/svg+xml'
    }
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  var deepClone = function (obj) {
      return JSON.parse(JSON.stringify(obj))
  };

  var NodeNameValidation = {
      data: function data() {
          var this$1 = this;

          return {
              formmodel: {
                  path: $perAdminApp.getNodeFromView('/state/tools/pages'),
                  name: '',
                  title: '',
                  templatePath: '',
                  skeletonPagePath: ''
              },
              formOptions: {
                  validationErrorClass: "has-error",
                  validationSuccessClass: "has-success",
                  validateAfterChanged: true,
                  focusFirstField: true
              },
              nameChanged: false,
              nameSchema: {
                  fields: [
                      {
                          type: "input",
                          inputType: "text",
                          label: "Title",
                          model: "title",
                          required: true,
                          onChanged: function (model, newVal, oldVal, field) {
                            if(!this$1.nameChanged && this$1.uNodeType !== "Asset") {
                                this$1.formmodel.name = $perAdminApp.normalizeString(newVal);
                            }
                          }
                      },
                      {
                          type: "input",
                          inputType: "text",
                          label: "Name",
                          model: "name",
                          required: true,
                          onChanged: function (model, newVal, oldVal, field) {
                              this$1.nameChanged = true;
                          },
                          validator: [this.nameAvailable, this.validPageName]
                      }
                  ]
              }
          }
      },
      methods: {
          validPageName: function(event) {
              var value = event;
              if (event && event instanceof Object && event.data) {
                  value = event.data;
              }
              if(!value || value.length === 0) {
                  return [this.$i18n('Name is required.')]
              }
              var regExMatch = /[^0-9a-zA-Z_-]/;
              var errorMsg = 'Page names may only contain letters, numbers, underscores, and dashes';
              if (this.uNodeType === "Asset") {
                  regExMatch = /[^0-9a-z.A-Z_-]/;
                  errorMsg = 'Assets names may only contain letters, numbers, underscores, and dashes';
              }

              if (value.match(regExMatch)) {
                  return [this.$i18n(errorMsg)]
              }
              return [];
          },
          nameAvailable: function(value) {
              if(!value || value.length === 0) {
                  return [this.$i18n('Name is required')]
              }
              if (this.node) {
                  var parent = this.node.path.replace("/"+this.node.name, "");
                  if ($perAdminApp.getApi().nameAvailable(value, parent)) {
                      return []
                  } else {
                      return [this.$i18n('Name is already in use')]
                  }
              } else {
                  var folder = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, this.formmodel.path);
                  for(var i = 0; i < folder.children.length; i++) {
                      if(folder.children[i].name === value) {
                          return [this.$i18n('Name is already in use.')]
                      }
                  }
                  return []
              }
          }
      }
  };

  //

  var Tab = {
    INFO: 'info',
    OG_TAGS: 'og-tags',
    REFERENCES: 'references',
    VERSIONS: 'versions',
    COMPONENTS: 'components',
    ACTIONS: 'actions'
  };

  var SchemaKey = {
    MODEL: 'model',
    OG_TAGS: 'ogTags'
  };

  var script = {
    props: {
      model: {
        type: Object,
        required: true
      },
      nodeType: {
        type: String,
        required: true
      },
      browserRoot: {
        type: String,
        required: true
      },
      currentPath: {
        type: String,
        required: true
      },
      tab: {
        type: String,
        default: Tab.INFO
      },
      isEdit: {
        type: Boolean,
        default: false
      }
    },
    data: function data() {
      return {
        Icon: Icon,
        Tab: Tab,
        SchemaKey: SchemaKey,
        NodeType: NodeType,
        activeTab: null,
        edit: false,
        valid: {
          state: true,
          errors: null
        },
        isOpen: false,
        selectedPath: null,
        options: {
          validateAfterLoad: true,
          validateAfterChanged: true,
          focusFirstField: true
        },
        nodeTypeGroups: {
          ogTags: [NodeType.PAGE, NodeType.TEMPLATE],
          references: [NodeType.ASSET, NodeType.PAGE, NodeType.TEMPLATE, NodeType.OBJECT],
          selectStateAction: [NodeType.ASSET, NodeType.OBJECT],
          showProp: [NodeType.ASSET, NodeType.OBJECT],
          allowMove: [NodeType.PAGE, NodeType.TEMPLATE, NodeType.ASSET]
        },
        path: {
          current: null,
          selected: null
        },
        formGenerator: {
          changes: []
        }
      }
    },
    mixins: [NodeNameValidation],
    computed: {
      uNodeType: function uNodeType() {
        return this.capFirstLetter(this.nodeType);
      },
      modalTitle: function modalTitle() {
        return ("Rename " + (this.uNodeType))
      },
      rawCurrentObject: function rawCurrentObject() {
        return $perAdminApp.getNodeFromViewOrNull(("/state/tools/" + (this.nodeType)));
      },
      currentObject: function currentObject() {
        var obj = this.rawCurrentObject;
        if (this.nodeTypeGroups.showProp.indexOf(this.nodeType) > -1) {
          if (obj && obj.hasOwnProperty('show')) {
            return obj.show;
          } else {
            return null;
          }
        }
        return obj;
      },
      node: function node() {
        if (this.nodeType === NodeType.OBJECT) {
          return this.rawCurrentObject.data
        }
        return $perAdminApp.findNodeFromPath(this.$root.$data.admin.nodes, this.currentObject);
      },
      allowOperations: function allowOperations() {
        return this.currentObject.split('/').length > 4;
      },
      allowMove: function allowMove() {
        return this.nodeTypeGroups.allowMove.indexOf(this.nodeType) > -1;
      },
      hasOgTags: function hasOgTags() {
        return this.nodeTypeGroups.ogTags.indexOf(this.nodeType) > -1;
      },
      hasReferences: function hasReferences() {
        return this.nodeTypeGroups.references.indexOf(this.nodeType) > -1;
      },
      hasMultipleTabs: function hasMultipleTabs() {
        return this.hasOgTags || this.hasReferences;
      },
      referencedBy: function referencedBy() {
        return this.trimReferences($perAdminApp.getView().state.referencedBy.referencedBy);
      },
      versions: function versions() {
        return this.hasVersions ? $perAdminApp.getView().state.versions.versions : []
      },
      isImage: function isImage() {
        var node = $perAdminApp.findNodeFromPath(
            $perAdminApp.getView().admin.nodes, this.currentObject);
        if (!node) {
          return false;
        }
        var mime = node.mimeType;
        return Object.values(MimeType.Image).indexOf(mime) >= 0
      },
      hasInfoView: function hasInfoView() {
        return [NodeType.ASSET].indexOf(this.nodeType) > -1;
      },
      hasVersions: function hasVersions() {
        return $perAdminApp.getView().state.versions ? $perAdminApp.getView().state.versions.has_versions : false
      },
      nodeName: function nodeName() {
        var nodeName = this.node.name;
        if (this.nodeType === NodeType.OBJECT) {
          nodeName = this.node.path.split('/').slice(-1).pop();
        }
        return nodeName
      }
    },
    watch: {
      edit: function edit(newVal) {
        $perAdminApp.getNodeFromView('/state/tools').edit = newVal;
      },
      activeTab : function(tab) {
        if (tab === 'versions'){
            this.showVersions();
        }
      },
      currentObject : function(path) {
        if (this.activeTab === 'versions'){
            this.showVersions();
        }
      }
    },
    created: function created() {
      this.activeTab = this.tab;
    },
    mounted: function mounted() {
      this.path.selected = this.selectedPath;
      this.path.current = this.currentPath;
    },
    methods: {
      itemToTarget: function itemToTarget(path) {
        var ret = { path: path, target: path }; 
        var tenant = $perAdminApp.getNodeFromViewOrNull('/state/tenant');
        if(path.startsWith(("/content/" + (tenant.name) + "/pages"))) {
          ret.path = "/content/admin/pages/pages/edit.html/path:" + path;
        } else if (path.startsWith(("/content/" + (tenant.name) + "/templates"))) {
          ret.path = "/content/admin/pages/templates/edit.html/path:" + path;
        } else {
          var segments = path.split('/');
          if(segments.length > 0) {
            segments.pop();
          }
          path = segments.join('/');
          ret.target = path;
          if (path.startsWith(("/content/" + (tenant.name) + "/assets"))) {
            ret.load = ret.path = "/content/admin/pages/assets.html/path:" + path;
            ret.type = 'ASSET';
          } else if (path.startsWith(("/content/" + (tenant.name) + "/objects"))) {
            ret.load = ret.path = "/content/admin/pages/objects.html/path:" + path;
            ret.type = 'OBJECT';
          }
        }
        return ret
      },
      getSchema: function getSchema(schemaKey) {
        if (!this.node) {
          return null;
        }
        var view = $perAdminApp.getView();
        var component = this.node.component;
        if (this.nodeType === NodeType.ASSET) {
          component = 'admin-components-assetview';
        }
        if (this.nodeType === NodeType.OBJECT) {
          component = this.getObjectComponent();
        }
        var componentDefinitions = view.admin.componentDefinitions;
        if (!componentDefinitions) {
          return {}
        }
        var cmpDefinition = view.admin.componentDefinitions[component];
        if (!cmpDefinition) {
          return {}
        }
        var schema = cmpDefinition[schemaKey];
        if (this.edit) {
          return schema;
        }
        if (!schema) {
          return {};
        }
        schema = deepClone(schema);
        schema.fields.forEach(function (field) {
          field.preview = true;
          field.readonly = true;
          if (field.fields) {
            field.fields.forEach(function (field) {
              field.readonly = true;
            });
          }
        });
        return schema;
      },
      getSchemaByActiveTab: function getSchemaByActiveTab() {
        if (this.activeTab === Tab.INFO) {
          return this.getSchema(SchemaKey.MODEL);
        } else if (this.activeTab === Tab.OG_TAGS) {
          return this.getSchema(SchemaKey.OG_TAGS);
        } else {
          return {};
        }
      },
      trimReferences: function trimReferences(referenceList) {
        return referenceList.reduce(
          (function (map) { return function (r, a) { return (!map.has(a.path) && map.set(a.path, 
          r[r.push({
            name: a.name,
            path: a.path,
            propertyName: a.propertyName,
            propertyPath: a.propertyPath,
            count: 0
          }) - 1]), 
          map.get(a.path).count++, r); }; })(new Map),
          []
        );
      },
      getObjectComponent: function getObjectComponent() {
        var resourceType = this.rawCurrentObject.data['component'];
        if (!resourceType) {
          resourceType = this.rawCurrentObject.data['sling:resourceType'];
        }
        return resourceType.split('/').join('-');
      },
      capFirstLetter: function capFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
      },
      onEdit: function onEdit() {
        this.edit = true;
        this.formGenerator.original = deepClone(this.node);
      },
      onCancel: function onCancel() {
        var payload = {selected: this.currentObject};
        this.edit = false;
        var node = this.node;
        this.formGenerator.changes.forEach(function (ch) {
          node[ch.key] = ch.oldVal;
        });
        this.formGenerator.changes = [];
      },
      onModelUpdate: function onModelUpdate(newVal, schemaKey) {
        if (this.edit) {
          this.formGenerator.changes.push({
            key: schemaKey,
            oldVal: this.formGenerator.original[schemaKey],
            newVal: newVal
          });
        }
      },
      onValidated: function onValidated(isValid, errors) {
        if (this.edit) {
          return;
        }
        this.valid.state = isValid;
        this.valid.errors = errors;
      },
      onConfirmDialog: function onConfirmDialog (event) {
        if (event === 'confirm') {
            var isValid = this.$refs.renameForm.validate();
            if (isValid) {
                this.renameNode(this.formmodel.name, this.formmodel.title);
            } else {
                return
            }
        }
        this.nameChanged = false;
        this.formmodel.name = '';
        this.formmodel.title = '';
        this.$refs.renameForm.clearValidationErrors();
        this.$refs.renameModal.close();
      },
      onReady: function onReady (event) {
        this.formmodel.name = this.node.name;
        this.formmodel.title = this.node.title;
      },
      renameNode: function renameNode(newName, newTitle) {
          var this$1 = this;

          var that = this;
          $perAdminApp.stateAction(("rename" + (this.uNodeType)), {
            path: this.currentObject,
            name: newName,
            title: newTitle,
            edit: this.isEdit
          }).then(function () {
            if (that.nodeType === 'asset' || that.nodeType === 'object') {
              var currNode = $perAdminApp.getNodeFromView(("/state/tools/" + (that.nodeType) + "/show"));
              var currNodeArr = currNode.split('/');
              currNodeArr[currNodeArr.length - 1] = newName;
              $perAdminApp.getNodeFromView(("/state/tools/" + (that.nodeType))).show = currNodeArr.join(
                  '/');
            } else { // page and template handling
              var currNode$1 = $perAdminApp.getNodeFromView('/state/tools')[that.nodeType];
              var currNodeArr$1 = currNode$1.split('/');
              currNodeArr$1[currNodeArr$1.length - 1] = newName;
              $perAdminApp.getNodeFromView('/state/tools')[that.nodeType] = currNodeArr$1.join('/');
            }
            this$1.setActiveTab(Tab.INFO);
          });
      },
      moveNode: function moveNode() {
        var this$1 = this;

        $perAdminApp.getApi().populateNodesForBrowser(this.path.current, 'pathBrowser')
            .then(function () {
              this$1.isOpen = true;
            }).catch(function () {
          $perAdminApp.getApi().populateNodesForBrowser(("/content/" + (site.tenant)), 'pathBrowser');
        });
      },
      deleteNode: function deleteNode() {
        var this$1 = this;

        var really = confirm(("Are you sure you want to delete this " + (this.nodeType) + "?"));
        if (really) {
          $perAdminApp.stateAction(("delete" + (this.uNodeType)), this.node.path).then(function () {
            $perAdminApp.stateAction(("unselect" + (this$1.uNodeType)), {});
          }).then(function () {
            var path = $perAdminApp.getNodeFromView('/state/tools/pages');
            $perAdminApp.loadContent(
                '/content/admin/pages/pages.html/path' + SUFFIX_PARAM_SEPARATOR + path);
          });
          this.isOpen = false;
        }
      },
      setCurrentPath: function setCurrentPath(path) {
        this.path.current = path;
      },
      setSelectedPath: function setSelectedPath(path) {
        this.path.selected = path;
      },
      showVersions: function showVersions() {
        $perAdminApp.getApi().populateVersions(this.currentObject);
      },
      deleteVersion: function deleteVersion(me, target) {
        $perAdminApp.stateAction('deleteVersion', { path: target.path, version: target.version.name });
      },
      createVersion: function createVersion(){
        $perAdminApp.stateAction('createVersion', this.currentObject);
      },
      checkoutVersion: function checkoutVersion(version){
        if(version.base === true){
          $perAdminApp.notifyUser('Info', 'You cannot checkout the current version');
          return
        }
        var self = this;
        $perAdminApp.askUser('Restore Version',
          ("Would you like to restore " + (version.name) + "? You may lose work unless you create a new version saving the current state."), {
              yesText: 'Yes',
              noText: 'No',
              yes: function yes() {
                $perAdminApp.stateAction('restoreVersion', {path: self.currentObject, versionName: version.name});
              },
              no: function no() {
                console.log('no');
              }
          });
      },
      onMoveCancel: function onMoveCancel() {
        this.isOpen = false;
      },
      onMoveSelect: function onMoveSelect() {
        $perAdminApp.stateAction(("move" + (this.uNodeType)), {
          path: this.node.path,
          to: this.path.selected,
          type: 'child'
        });
        $perAdminApp.stateAction(("unselect" + (this.uNodeType)), {});
        this.isOpen = false;
      },
      save: function save() {
        if (this.nodeType === NodeType.OBJECT) {
          this.saveObject();
        } else {
          $perAdminApp.stateAction(("save" + (this.uNodeType) + "Properties"), this.node);
          this.edit = false;
        }
      },
      saveObject: function saveObject() {
        var data = this.node;
        var ref = this.rawCurrentObject;
        var show = ref.show;
        var _deleted = $perAdminApp.getNodeFromViewWithDefault('/state/tools/_deleted', {});

        //Find child nodes with subchildren for our edited object
        for (var key in data) {
          if (!data.hasOwnProperty(key)) {
            continue;
          }
          //If node (or deleted node) is an array of objects then we have a child node
          if ((Array.isArray(data[key]) && data[key].length && typeof data[key][0] === 'object') ||
              (Array.isArray(_deleted[key]) && _deleted[key].length && typeof _deleted[key][0]
                  === 'object')) {

            var node = data[key];

            //loop through children
            var targetNode = {};
            //Insert deleted children
            for (var j in _deleted[key]) {
              if (!_deleted[key].hasOwnProperty(j)) {
                continue;
              }
              var deleted = _deleted[key][j];
              targetNode[deleted.name] = deleted;
            }
            //Insert children
            for (var i in node) {
              if (!node.hasOwnProperty(i)) {
                continue;
              }
              var child = node[i];
              targetNode[child.name] = child;
            }
            data[key] = targetNode;
          }
        }
        $perAdminApp.stateAction('saveObjectEdit', {data: data, path: show}).then(function () {
          $perAdminApp.getNodeFromView('/state/tools')._deleted = {};
        });
        $perAdminApp.stateAction('selectObject', {selected: show});
        this.edit = false;
      },
      setActiveTab: function setActiveTab(clickedTab) {
        this.activeTab = clickedTab;
      },
      isTab: function isTab(arg) {
        if (Array.isArray(arg)) {
          return arg.indexOf(this.activeTab) > -1;
        }
        return this.activeTab === arg;
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
  function createInjector(context) {
    return function (id, style) {
      return addStyle(id, style);
    };
  }
  var HEAD = document.head || document.getElementsByTagName('head')[0];
  var styles = {};

  function addStyle(id, css) {
    var group = isOldIE ? css.media || 'default' : id;
    var style = styles[group] || (styles[group] = {
      ids: new Set(),
      styles: []
    });

    if (!style.ids.has(id)) {
      style.ids.add(id);
      var code = css.source;

      if (css.map) {
        // https://developer.chrome.com/devtools/docs/javascript-debugging
        // this makes source maps inside style tags work properly in Chrome
        code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

        code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
      }

      if (!style.element) {
        style.element = document.createElement('style');
        style.element.type = 'text/css';
        if (css.media) { style.element.setAttribute('media', css.media); }
        HEAD.appendChild(style.element);
      }

      if ('styleSheet' in style.element) {
        style.styles.push(code);
        style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
      } else {
        var index = style.ids.size - 1;
        var textNode = document.createTextNode(code);
        var nodes = style.element.childNodes;
        if (nodes[index]) { style.element.removeChild(nodes[index]); }
        if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
      }
    }
  }

  var browser = createInjector;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      { class: ["explorer-preview-content", "preview-" + _vm.nodeType] },
      [
        _vm.currentObject
          ? [
              _c("div", { staticClass: "explorer-preview-nav" }, [
                _vm.hasMultipleTabs
                  ? _c(
                      "ul",
                      { staticClass: "nav-left" },
                      [
                        !!_vm.$slots.default
                          ? _c("admin-components-explorerpreviewnavitem", {
                              class: { active: _vm.isTab(_vm.Tab.COMPONENTS) },
                              attrs: {
                                icon: "view_list",
                                title: "component explorer"
                              },
                              on: {
                                click: function($event) {
                                  return _vm.setActiveTab(_vm.Tab.COMPONENTS)
                                }
                              }
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _c("admin-components-explorerpreviewnavitem", {
                          class: { active: _vm.isTab(_vm.Tab.INFO) },
                          attrs: {
                            icon: _vm.Icon.SETTINGS,
                            title: _vm.nodeType + "-info"
                          },
                          on: {
                            click: function($event) {
                              return _vm.setActiveTab(_vm.Tab.INFO)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _vm.hasOgTags
                          ? _c("admin-components-explorerpreviewnavitem", {
                              class: { active: _vm.isTab(_vm.Tab.OG_TAGS) },
                              attrs: { icon: _vm.Icon.LABEL, title: "og-tags" },
                              on: {
                                click: function($event) {
                                  return _vm.setActiveTab(_vm.Tab.OG_TAGS)
                                }
                              }
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _vm.hasReferences
                          ? _c("admin-components-explorerpreviewnavitem", {
                              class: { active: _vm.isTab(_vm.Tab.REFERENCES) },
                              attrs: { icon: _vm.Icon.LIST, title: "references" },
                              on: {
                                click: function($event) {
                                  return _vm.setActiveTab(_vm.Tab.REFERENCES)
                                }
                              }
                            })
                          : _vm._e(),
                        _vm._v(" "),
                        _c("admin-components-explorerpreviewnavitem", {
                          class: { active: _vm.isTab(_vm.Tab.VERSIONS) },
                          attrs: {
                            icon: _vm.Icon.VERSIONS,
                            title: _vm.nodeType + "-versions"
                          },
                          on: {
                            click: function($event) {
                              return _vm.setActiveTab(_vm.Tab.VERSIONS)
                            }
                          }
                        }),
                        _vm._v(" "),
                        _c("admin-components-explorerpreviewnavitem", {
                          class: { active: _vm.isTab(_vm.Tab.ACTIONS) },
                          attrs: { icon: _vm.Icon.MORE_VERT, title: "actions" },
                          on: {
                            click: function($event) {
                              return _vm.setActiveTab(_vm.Tab.ACTIONS)
                            }
                          }
                        })
                      ],
                      1
                    )
                  : _vm._e(),
                _vm._v(" "),
                _c("ul", { staticClass: "nav-right" })
              ]),
              _vm._v(" "),
              _vm.isTab([_vm.Tab.COMPONENTS])
                ? [_vm._t("default")]
                : _vm.isTab([_vm.Tab.INFO, _vm.Tab.OG_TAGS])
                ? [
                    _vm.hasInfoView && !_vm.edit
                      ? _c("div", { class: _vm.nodeType + "-info-view" }, [
                          _vm.isImage
                            ? _c("img", {
                                staticClass: "info-view-image",
                                attrs: { src: _vm.currentObject }
                              })
                            : _c("iframe", {
                                staticClass: "info-view-iframe",
                                attrs: { src: _vm.currentObject }
                              })
                        ])
                      : _vm._e(),
                    _vm._v(" "),
                    _vm.node && _vm.getSchemaByActiveTab()
                      ? _c("vue-form-generator", {
                          class: { "vfg-preview": !_vm.edit },
                          attrs: {
                            schema: _vm.getSchemaByActiveTab(),
                            model: _vm.node,
                            options: _vm.options
                          },
                          on: {
                            validated: function($event) {
                              return _vm.onValidated()
                            },
                            "model-updated": _vm.onModelUpdate
                          }
                        })
                      : _vm._e(),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "explorer-confirm-dialog" },
                      [
                        _vm.edit
                          ? [
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-raised waves-effect waves-light right",
                                  attrs: {
                                    type: "button",
                                    title:
                                      "cancel editing " +
                                      _vm.nodeType +
                                      " properties"
                                  },
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation();
                                      $event.preventDefault();
                                      return _vm.onCancel()
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v(_vm._s(_vm.Icon.CANCEL))
                                  ])
                                ]
                              ),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-raised waves-effect waves-light right",
                                  attrs: {
                                    type: "button",
                                    title: "save " + _vm.nodeType + " properties",
                                    disabled: !_vm.valid
                                  },
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation();
                                      $event.preventDefault();
                                      return _vm.save()
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v(_vm._s(_vm.Icon.CHECK))
                                  ])
                                ]
                              )
                            ]
                          : [
                              _c("span"),
                              _vm._v(" "),
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn btn-raised waves-effect waves-light right",
                                  attrs: {
                                    type: "button",
                                    title: "edit " + _vm.nodeType + " properties"
                                  },
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation();
                                      $event.preventDefault();
                                      return _vm.onEdit()
                                    }
                                  }
                                },
                                [
                                  _c("i", { staticClass: "material-icons" }, [
                                    _vm._v(_vm._s(_vm.Icon.EDIT))
                                  ])
                                ]
                              )
                            ]
                      ],
                      2
                    )
                  ]
                : _vm.isTab(_vm.Tab.REFERENCES)
                ? [
                    _c(
                      "ul",
                      {
                        class: [
                          "collection",
                          "with-header",
                          "explorer-" + _vm.nodeType + "-referenced-by"
                        ]
                      },
                      [
                        _c("li", { staticClass: "collection-header" }, [
                          _vm._v(
                            "\n          referenced in " +
                              _vm._s(_vm.referencedBy.length) +
                              " location"
                          ),
                          _vm.referencedBy.length !== 1
                            ? _c("span", [_vm._v("s")])
                            : _vm._e()
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.referencedBy, function(item) {
                          return _c(
                            "li",
                            { key: item.path, staticClass: "collection-item" },
                            [
                              _c("span", [
                                item.count
                                  ? _c("span", { staticClass: "count" }, [
                                      _vm._v(
                                        _vm._s(
                                          item.count > 99 ? "99+" : item.count
                                        )
                                      )
                                    ])
                                  : _vm._e(),
                                _vm._v(" "),
                                _c(
                                  "span",
                                  { staticClass: "right" },
                                  [
                                    _c(
                                      "admin-components-action",
                                      {
                                        attrs: {
                                          model: {
                                            target: _vm.itemToTarget(item.path),
                                            command: "editReference",
                                            tooltipTitle:
                                              "edit '" + item.name + "'"
                                          }
                                        }
                                      },
                                      [_c("bdo", [_vm._v(_vm._s(item.path))])]
                                    )
                                  ],
                                  1
                                ),
                                _vm._v(" "),
                                _c(
                                  "span",
                                  { staticClass: "edit-icon" },
                                  [
                                    _c(
                                      "admin-components-action",
                                      {
                                        attrs: {
                                          model: {
                                            target: _vm.itemToTarget(item.path),
                                            command: "editReference",
                                            tooltipTitle:
                                              "edit '" + item.name + "'"
                                          }
                                        }
                                      },
                                      [_c("admin-components-iconeditpage")],
                                      1
                                    )
                                  ],
                                  1
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ]
                : _vm.isTab(_vm.Tab.VERSIONS)
                ? [
                    _vm.allowOperations
                      ? _c(
                          "div",
                          { staticClass: "action-list" },
                          [
                            _c(
                              "div",
                              {
                                staticClass: "action",
                                attrs: {
                                  title: "create new " + _vm.nodeType + " version"
                                },
                                on: {
                                  click: function($event) {
                                    $event.stopPropagation();
                                    $event.preventDefault();
                                    return _vm.createVersion($event)
                                  }
                                }
                              },
                              [
                                _c("i", { staticClass: "material-icons" }, [
                                  _vm._v(_vm._s(_vm.Icon.CREATE))
                                ]),
                                _vm._v(
                                  " Create new " +
                                    _vm._s(_vm.nodeType) +
                                    " version\n            "
                                )
                              ]
                            ),
                            _vm._v(" "),
                            !_vm.hasVersions
                              ? _c(
                                  "p",
                                  { attrs: { title: "no versions created yet" } },
                                  [
                                    _vm._v(
                                      "\n                This " +
                                        _vm._s(_vm.nodeType) +
                                        " has no versions\n            "
                                    )
                                  ]
                                )
                              : _vm._l(_vm.versions, function(version) {
                                  return _c(
                                    "div",
                                    {
                                      key: version.name,
                                      staticClass: "action",
                                      attrs: { title: "Version " + version.name },
                                      on: {
                                        click: function($event) {
                                          return _vm.checkoutVersion(version)
                                        }
                                      }
                                    },
                                    [
                                      version.base
                                        ? _c(
                                            "i",
                                            { staticClass: "material-icons" },
                                            [_vm._v(_vm._s(_vm.Icon.CHECKED))]
                                          )
                                        : !version.base
                                        ? _c(
                                            "i",
                                            { staticClass: "material-icons" },
                                            [_vm._v(_vm._s(_vm.Icon.UNCHECKED))]
                                          )
                                        : _vm._e(),
                                      _vm._v(
                                        "\n                    " +
                                          _vm._s(version.name) +
                                          " -" +
                                          _vm._s(version.created) +
                                          " " +
                                          _vm._s(
                                            version.base ? "(current)" : ""
                                          ) +
                                          "\n                    "
                                      ),
                                      !version.base
                                        ? _c(
                                            "span",
                                            {
                                              staticClass: "deleteVersionWrapper"
                                            },
                                            [
                                              _c(
                                                "admin-components-action",
                                                {
                                                  attrs: {
                                                    model: {
                                                      command: "deleteVersion",
                                                      target: {
                                                        version: version,
                                                        path: _vm.currentObject
                                                      },
                                                      tooltipTitle:
                                                        "delete version"
                                                    }
                                                  }
                                                },
                                                [
                                                  _c(
                                                    "i",
                                                    {
                                                      staticClass:
                                                        "material-icons"
                                                    },
                                                    [
                                                      _vm._v(
                                                        _vm._s(_vm.Icon.DELETE)
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            ],
                                            1
                                          )
                                        : _vm._e()
                                    ]
                                  )
                                })
                          ],
                          2
                        )
                      : _vm._e()
                  ]
                : _vm.isTab(_vm.Tab.ACTIONS)
                ? [
                    _vm.allowOperations
                      ? _c("div", { staticClass: "action-list" }, [
                          _c(
                            "div",
                            {
                              staticClass: "action",
                              attrs: { title: "rename " + _vm.nodeType },
                              on: {
                                click: function($event) {
                                  return _vm.$refs.renameModal.open()
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "material-icons" }, [
                                _vm._v(_vm._s(_vm.Icon.TEXT_FORMAT))
                              ]),
                              _vm._v(
                                "\n          Rename " +
                                  _vm._s(_vm.nodeType) +
                                  "\n        "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "action",
                              attrs: { title: "move " + _vm.nodeType },
                              on: {
                                click: function($event) {
                                  return _vm.moveNode()
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "material-icons" }, [
                                _vm._v(_vm._s(_vm.Icon.COMPARE_ARROWS))
                              ]),
                              _vm._v(
                                "\n          Move " +
                                  _vm._s(_vm.nodeType) +
                                  "\n        "
                              )
                            ]
                          ),
                          _vm._v(" "),
                          _c(
                            "div",
                            {
                              staticClass: "action",
                              attrs: { title: "delete " + _vm.nodeType },
                              on: {
                                click: function($event) {
                                  return _vm.deleteNode()
                                }
                              }
                            },
                            [
                              _c("i", { staticClass: "material-icons" }, [
                                _vm._v(_vm._s(_vm.Icon.DELETE))
                              ]),
                              _vm._v(
                                "\n          Delete " +
                                  _vm._s(_vm.nodeType) +
                                  "\n        "
                              )
                            ]
                          )
                        ])
                      : _vm._e()
                  ]
                : _vm._e()
            ]
          : [
              !_vm.currentObject
                ? _c("div", { staticClass: "explorer-preview-empty" }, [
                    _c("span", [
                      _vm._v(_vm._s(_vm.$i18n("no" + _vm.uNodeType + "Selected")))
                    ]),
                    _vm._v(" "),
                    _c("i", { staticClass: "material-icons" }, [_vm._v("info")])
                  ])
                : _vm._e()
            ],
        _vm._v(" "),
        _c(
          "admin-components-materializemodal",
          {
            ref: "renameModal",
            attrs: { modalTitle: _vm.modalTitle },
            on: { ready: _vm.onReady }
          },
          [
            _c("vue-form-generator", {
              ref: "renameForm",
              attrs: {
                model: _vm.formmodel,
                schema: _vm.nameSchema,
                options: _vm.formOptions
              }
            }),
            _vm._v(" "),
            _c(
              "template",
              { slot: "footer" },
              [
                _c("admin-components-confirmdialog", {
                  attrs: { submitText: "submit" },
                  on: { "confirm-dialog": _vm.onConfirmDialog }
                })
              ],
              1
            )
          ],
          2
        ),
        _vm._v(" "),
        _vm.isOpen
          ? _c("admin-components-pathbrowser", {
              attrs: {
                isOpen: _vm.isOpen,
                header: "Move " + _vm.nodeName,
                browserRoot: _vm.browserRoot,
                browserType: _vm.nodeType,
                currentPath: _vm.path.current,
                selectedPath: _vm.path.selected,
                setCurrentPath: _vm.setCurrentPath,
                setSelectedPath: _vm.setSelectedPath,
                onCancel: _vm.onMoveCancel,
                onSelect: _vm.onMoveSelect
              }
            })
          : _vm._e()
      ],
      2
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = function (inject) {
      if (!inject) { return }
      inject("data-v-dfa3be54_0", { source: "\n.deleteVersionWrapper{\n    margin-left: auto;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/explorerpreviewcontent/template.vue"],"names":[],"mappings":";AAqsBA;IACA,iBAAA;AACA","file":"template.vue","sourcesContent":["<template>\n  <div :class=\"['explorer-preview-content', `preview-${nodeType}`]\">\n\n    <template v-if=\"currentObject\">\n      <div class=\"explorer-preview-nav\">\n        <ul class=\"nav-left\" v-if=\"hasMultipleTabs\">\n          <admin-components-explorerpreviewnavitem\n              v-if=\"!!($slots.default)\"\n              icon=\"view_list\"\n              title=\"component explorer\"\n              :class=\"{'active': isTab(Tab.COMPONENTS)}\"\n              @click=\"setActiveTab(Tab.COMPONENTS)\"/>\n\n          <admin-components-explorerpreviewnavitem\n              :icon=\"Icon.SETTINGS\"\n              :title=\"`${nodeType}-info`\"\n              :class=\"{'active': isTab(Tab.INFO)}\"\n              @click=\"setActiveTab(Tab.INFO)\" />\n\n          <admin-components-explorerpreviewnavitem\n              v-if=\"hasOgTags\"\n              :icon=\"Icon.LABEL\"\n              :title=\"'og-tags'\"\n              :class=\"{'active': isTab(Tab.OG_TAGS)}\"\n              @click=\"setActiveTab(Tab.OG_TAGS)\" />\n\n          <admin-components-explorerpreviewnavitem\n              v-if=\"hasReferences\"\n              :icon=\"Icon.LIST\"\n              :title=\"'references'\"\n              :class=\"{'active': isTab(Tab.REFERENCES)}\"\n              @click=\"setActiveTab(Tab.REFERENCES)\" />\n\n            <admin-components-explorerpreviewnavitem\n                :icon=\"Icon.VERSIONS\"\n                :title=\"`${nodeType}-versions`\"\n                :class=\"{'active': isTab(Tab.VERSIONS)}\"\n                @click=\"setActiveTab(Tab.VERSIONS)\" />\n\n          <admin-components-explorerpreviewnavitem\n              :icon=\"Icon.MORE_VERT\"\n              :title=\"'actions'\"\n              :class=\"{'active': isTab(Tab.ACTIONS)}\"\n              @click=\"setActiveTab(Tab.ACTIONS)\" />\n        </ul>\n\n        <ul class=\"nav-right\"></ul>\n      </div>\n\n      <template v-if=\"isTab([Tab.COMPONENTS])\">\n        <slot></slot>\n      </template>\n\n      <template v-else-if=\"isTab([Tab.INFO, Tab.OG_TAGS])\">\n        <div v-if=\"hasInfoView && !edit\"\n             :class=\"`${nodeType}-info-view`\">\n          <img v-if=\"isImage\"\n               :src=\"currentObject\"\n               class=\"info-view-image\"/>\n          <iframe\n              v-else\n              :src=\"currentObject\"\n              class=\"info-view-iframe\">\n          </iframe>\n        </div>\n        <vue-form-generator\n            v-if=\"node && getSchemaByActiveTab()\"\n            :class=\"{'vfg-preview': !edit}\"\n            :schema=\"getSchemaByActiveTab()\"\n            :model=\"node\"\n            :options=\"options\"\n            @validated=\"onValidated()\"\n            @model-updated=\"onModelUpdate\">\n        </vue-form-generator>\n        <div class=\"explorer-confirm-dialog\">\n          <template v-if=\"edit\">\n            <button\n                class=\"btn btn-raised waves-effect waves-light right\"\n                type=\"button\"\n                :title=\"`cancel editing ${nodeType} properties`\"\n                @click.stop.prevent=\"onCancel()\">\n              <i class=\"material-icons\">{{Icon.CANCEL}}</i>\n            </button>\n            <button\n                class=\"btn btn-raised waves-effect waves-light right\"\n                type=\"button\"\n                :title=\"`save ${nodeType} properties`\"\n                :disabled=\"!valid\"\n                @click.stop.prevent=\"save()\">\n              <i class=\"material-icons\">{{Icon.CHECK}}</i>\n            </button>\n          </template>\n          <template v-else>\n            <span></span>\n            <button\n                class=\"btn btn-raised waves-effect waves-light right\"\n                type=\"button\"\n                :title=\"`edit ${nodeType} properties`\"\n                @click.stop.prevent=\"onEdit()\">\n              <i class=\"material-icons\">{{Icon.EDIT}}</i>\n            </button>\n          </template>\n        </div>\n      </template>\n\n      <template v-else-if=\"isTab(Tab.REFERENCES)\">\n        <ul :class=\"['collection', 'with-header', `explorer-${nodeType}-referenced-by`]\">\n          <li class=\"collection-header\">\n            referenced in {{referencedBy.length}} location<span v-if=\"referencedBy.length !== 1 \">s</span>\n          </li>\n          <li v-for=\"item in referencedBy\" :key=\"item.path\" class=\"collection-item\">\n            <span>\n              <span v-if=\"item.count\" class=\"count\">{{item.count > 99 ? '99+' : item.count}}</span>\n              <span class=\"right\">\n                <admin-components-action\n                    v-bind:model=\"{\n                      target: itemToTarget(item.path),\n                      command: 'editReference',\n                      tooltipTitle: `edit '${item.name}'`\n                    }\">\n                    <bdo>{{item.path}}</bdo>\n                </admin-components-action>\n              </span>\n              <span class=\"edit-icon\">\n                <admin-components-action\n                    v-bind:model=\"{\n                      target: itemToTarget(item.path),\n                      command: 'editReference',\n                      tooltipTitle: `edit '${item.name}'`\n                    }\">\n                    <admin-components-iconeditpage></admin-components-iconeditpage>\n                </admin-components-action>\n              </span>\n            </span>\n          </li>\n        </ul>\n      </template>\n\n      <template v-else-if=\"isTab(Tab.VERSIONS)\" >\n          <div v-if=\"allowOperations\" class=\"action-list\">\n              <div class=\"action\"\n                   v-on:click.stop.prevent=\"createVersion\"\n                   v-bind:title=\"`create new ${nodeType} version`\">\n                <i class=\"material-icons\">{{Icon.CREATE}}</i> Create new {{nodeType}} version\n              </div>\n\n              <p v-if=\"!hasVersions\"\n                   v-bind:title=\"`no versions created yet`\">\n                  This {{nodeType}} has no versions\n              </p>\n              <template v-else>\n                  <div v-for=\"version in versions\"\n                       class=\"action\"\n                       v-bind:key=\"version.name\"\n                       v-on:click=\"checkoutVersion(version)\"\n                       v-bind:title=\"`Version ${version.name}`\">\n                      <i v-if=\"version.base\" class=\"material-icons\">{{Icon.CHECKED}}</i>\n                      <i v-else-if=\"!version.base\" class=\"material-icons\">{{Icon.UNCHECKED}}</i>\n                      {{version.name}} -{{version.created}} {{version.base ? '(current)':''}}\n                      <span v-if=\"!version.base\" class=\"deleteVersionWrapper\">\n                          <admin-components-action\n                            v-bind:model=\"{\n                                command: 'deleteVersion',\n                                target: {version: version, path: currentObject},\n                                tooltipTitle: 'delete version'}\">\n                              <i class=\"material-icons\">{{Icon.DELETE}}</i>\n                          </admin-components-action>\n                      </span>\n                  </div>\n              </template>\n\n          </div>\n      </template>\n\n      <template v-else-if=\"isTab(Tab.ACTIONS)\">\n        <div v-if=\"allowOperations\" class=\"action-list\">\n          <div class=\"action\" :title=\"`rename ${nodeType}`\" @click=\"$refs.renameModal.open()\">\n            <i class=\"material-icons\">{{Icon.TEXT_FORMAT}}</i>\n            Rename {{nodeType}}\n          </div>\n          <div class=\"action\" :title=\"`move ${nodeType}`\" @click=\"moveNode()\">\n            <i class=\"material-icons\">{{Icon.COMPARE_ARROWS}}</i>\n            Move {{nodeType}}\n          </div>\n          <div class=\"action\" :title=\"`delete ${nodeType}`\" @click=\"deleteNode()\">\n            <i class=\"material-icons\">{{Icon.DELETE}}</i>\n            Delete {{nodeType}}\n          </div>\n        </div>\n      </template>\n\n    </template>\n\n    <template v-else>\n      <div v-if=\"!currentObject\" class=\"explorer-preview-empty\">\n        <span>{{ $i18n(`no${uNodeType}Selected`) }}</span>\n        <i class=\"material-icons\">info</i>\n      </div>\n    </template>\n\n    <admin-components-materializemodal\n        ref=\"renameModal\"\n        v-bind:modalTitle=\"modalTitle\"\n        v-on:ready=\"onReady\">\n        <vue-form-generator\n                :model   =\"formmodel\"\n                :schema  =\"nameSchema\"\n                :options =\"formOptions\"\n                ref      =\"renameForm\">\n        </vue-form-generator>\n        <template slot=\"footer\">\n            <admin-components-confirmdialog\n                submitText=\"submit\"\n                v-on:confirm-dialog=\"onConfirmDialog\" />\n        </template>\n    </admin-components-materializemodal>\n\n    <admin-components-pathbrowser\n        v-if=\"isOpen\"\n        :isOpen=\"isOpen\"\n        :header=\"`Move ${nodeName}`\"\n        :browserRoot=\"browserRoot\"\n        :browserType=\"nodeType\"\n        :currentPath=\"path.current\"\n        :selectedPath=\"path.selected\"\n        :setCurrentPath=\"setCurrentPath\"\n        :setSelectedPath=\"setSelectedPath\"\n        :onCancel=\"onMoveCancel\"\n        :onSelect=\"onMoveSelect\">\n    </admin-components-pathbrowser>\n\n  </div>\n</template>\n\n<script>\n  import {Icon, MimeType, NodeType, SUFFIX_PARAM_SEPARATOR} from '../../../../../../js/constants'\n  import {deepClone} from '../../../../../../js/utils'\n  import NodeNameValidation from '../../../../../../js/mixins/NodeNameValidation'\n\n  const Tab = {\n    INFO: 'info',\n    OG_TAGS: 'og-tags',\n    REFERENCES: 'references',\n    VERSIONS: 'versions',\n    COMPONENTS: 'components',\n    ACTIONS: 'actions'\n  };\n\n  const SchemaKey = {\n    MODEL: 'model',\n    OG_TAGS: 'ogTags'\n  };\n\n  export default {\n    props: {\n      model: {\n        type: Object,\n        required: true\n      },\n      nodeType: {\n        type: String,\n        required: true\n      },\n      browserRoot: {\n        type: String,\n        required: true\n      },\n      currentPath: {\n        type: String,\n        required: true\n      },\n      tab: {\n        type: String,\n        default: Tab.INFO\n      },\n      isEdit: {\n        type: Boolean,\n        default: false\n      }\n    },\n    data() {\n      return {\n        Icon: Icon,\n        Tab: Tab,\n        SchemaKey: SchemaKey,\n        NodeType: NodeType,\n        activeTab: null,\n        edit: false,\n        valid: {\n          state: true,\n          errors: null\n        },\n        isOpen: false,\n        selectedPath: null,\n        options: {\n          validateAfterLoad: true,\n          validateAfterChanged: true,\n          focusFirstField: true\n        },\n        nodeTypeGroups: {\n          ogTags: [NodeType.PAGE, NodeType.TEMPLATE],\n          references: [NodeType.ASSET, NodeType.PAGE, NodeType.TEMPLATE, NodeType.OBJECT],\n          selectStateAction: [NodeType.ASSET, NodeType.OBJECT],\n          showProp: [NodeType.ASSET, NodeType.OBJECT],\n          allowMove: [NodeType.PAGE, NodeType.TEMPLATE, NodeType.ASSET]\n        },\n        path: {\n          current: null,\n          selected: null\n        },\n        formGenerator: {\n          changes: []\n        }\n      }\n    },\n    mixins: [NodeNameValidation],\n    computed: {\n      uNodeType() {\n        return this.capFirstLetter(this.nodeType);\n      },\n      modalTitle() {\n        return `Rename ${this.uNodeType}`\n      },\n      rawCurrentObject() {\n        return $perAdminApp.getNodeFromViewOrNull(`/state/tools/${this.nodeType}`);\n      },\n      currentObject() {\n        const obj = this.rawCurrentObject;\n        if (this.nodeTypeGroups.showProp.indexOf(this.nodeType) > -1) {\n          if (obj && obj.hasOwnProperty('show')) {\n            return obj.show;\n          } else {\n            return null;\n          }\n        }\n        return obj;\n      },\n      node() {\n        if (this.nodeType === NodeType.OBJECT) {\n          return this.rawCurrentObject.data\n        }\n        return $perAdminApp.findNodeFromPath(this.$root.$data.admin.nodes, this.currentObject);\n      },\n      allowOperations() {\n        return this.currentObject.split('/').length > 4;\n      },\n      allowMove() {\n        return this.nodeTypeGroups.allowMove.indexOf(this.nodeType) > -1;\n      },\n      hasOgTags() {\n        return this.nodeTypeGroups.ogTags.indexOf(this.nodeType) > -1;\n      },\n      hasReferences() {\n        return this.nodeTypeGroups.references.indexOf(this.nodeType) > -1;\n      },\n      hasMultipleTabs() {\n        return this.hasOgTags || this.hasReferences;\n      },\n      referencedBy() {\n        return this.trimReferences($perAdminApp.getView().state.referencedBy.referencedBy);\n      },\n      versions() {\n        return this.hasVersions ? $perAdminApp.getView().state.versions.versions : []\n      },\n      isImage() {\n        const node = $perAdminApp.findNodeFromPath(\n            $perAdminApp.getView().admin.nodes, this.currentObject);\n        if (!node) {\n          return false;\n        }\n        const mime = node.mimeType;\n        return Object.values(MimeType.Image).indexOf(mime) >= 0\n      },\n      hasInfoView() {\n        return [NodeType.ASSET].indexOf(this.nodeType) > -1;\n      },\n      hasVersions() {\n        return $perAdminApp.getView().state.versions ? $perAdminApp.getView().state.versions.has_versions : false\n      },\n      nodeName() {\n        let nodeName = this.node.name;\n        if (this.nodeType === NodeType.OBJECT) {\n          nodeName = this.node.path.split('/').slice(-1).pop()\n        }\n        return nodeName\n      }\n    },\n    watch: {\n      edit(newVal) {\n        $perAdminApp.getNodeFromView('/state/tools').edit = newVal;\n      },\n      activeTab : function(tab) {\n        if (tab === 'versions'){\n            this.showVersions()\n        }\n      },\n      currentObject : function(path) {\n        if (this.activeTab === 'versions'){\n            this.showVersions()\n        }\n      }\n    },\n    created() {\n      this.activeTab = this.tab\n    },\n    mounted() {\n      this.path.selected = this.selectedPath\n      this.path.current = this.currentPath\n    },\n    methods: {\n      itemToTarget(path) {\n        const ret = { path, target: path } \n        const tenant = $perAdminApp.getNodeFromViewOrNull('/state/tenant')\n        if(path.startsWith(`/content/${tenant.name}/pages`)) {\n          ret.path = `/content/admin/pages/pages/edit.html/path:${path}`\n        } else if (path.startsWith(`/content/${tenant.name}/templates`)) {\n          ret.path = `/content/admin/pages/templates/edit.html/path:${path}`\n        } else {\n          const segments = path.split('/')\n          if(segments.length > 0) {\n            segments.pop()\n          }\n          path = segments.join('/')\n          ret.target = path\n          if (path.startsWith(`/content/${tenant.name}/assets`)) {\n            ret.load = ret.path = `/content/admin/pages/assets.html/path:${path}`\n            ret.type = 'ASSET'\n          } else if (path.startsWith(`/content/${tenant.name}/objects`)) {\n            ret.load = ret.path = `/content/admin/pages/objects.html/path:${path}`\n            ret.type = 'OBJECT'\n          }\n        }\n        return ret\n      },\n      getSchema(schemaKey) {\n        if (!this.node) {\n          return null;\n        }\n        const view = $perAdminApp.getView();\n        let component = this.node.component;\n        if (this.nodeType === NodeType.ASSET) {\n          component = 'admin-components-assetview';\n        }\n        if (this.nodeType === NodeType.OBJECT) {\n          component = this.getObjectComponent();\n        }\n        const componentDefinitions = view.admin.componentDefinitions\n        if (!componentDefinitions) {\n          return {}\n        }\n        const cmpDefinition = view.admin.componentDefinitions[component]\n        if (!cmpDefinition) {\n          return {}\n        }\n        let schema = cmpDefinition[schemaKey];\n        if (this.edit) {\n          return schema;\n        }\n        if (!schema) {\n          return {};\n        }\n        schema = deepClone(schema);\n        schema.fields.forEach((field) => {\n          field.preview = true;\n          field.readonly = true;\n          if (field.fields) {\n            field.fields.forEach((field) => {\n              field.readonly = true;\n            });\n          }\n        });\n        return schema;\n      },\n      getSchemaByActiveTab() {\n        if (this.activeTab === Tab.INFO) {\n          return this.getSchema(SchemaKey.MODEL);\n        } else if (this.activeTab === Tab.OG_TAGS) {\n          return this.getSchema(SchemaKey.OG_TAGS);\n        } else {\n          return {};\n        }\n      },\n      trimReferences(referenceList) {\n        return referenceList.reduce(\n          (map => (r, a) => (!map.has(a.path) && map.set(a.path, \n          r[r.push({\n            name: a.name,\n            path: a.path,\n            propertyName: a.propertyName,\n            propertyPath: a.propertyPath,\n            count: 0\n          }) - 1]), \n          map.get(a.path).count++, r))(new Map),\n          []\n        );\n      },\n      getObjectComponent() {\n        let resourceType = this.rawCurrentObject.data['component'];\n        if (!resourceType) {\n          resourceType = this.rawCurrentObject.data['sling:resourceType'];\n        }\n        return resourceType.split('/').join('-');\n      },\n      capFirstLetter(string) {\n        return string.charAt(0).toUpperCase() + string.slice(1);\n      },\n      onEdit() {\n        this.edit = true\n        this.formGenerator.original = deepClone(this.node)\n      },\n      onCancel() {\n        const payload = {selected: this.currentObject}\n        this.edit = false\n        let node = this.node\n        this.formGenerator.changes.forEach((ch) => {\n          node[ch.key] = ch.oldVal\n        })\n        this.formGenerator.changes = []\n      },\n      onModelUpdate(newVal, schemaKey) {\n        if (this.edit) {\n          this.formGenerator.changes.push({\n            key: schemaKey,\n            oldVal: this.formGenerator.original[schemaKey],\n            newVal: newVal\n          })\n        }\n      },\n      onValidated(isValid, errors) {\n        if (this.edit) {\n          return;\n        }\n        this.valid.state = isValid;\n        this.valid.errors = errors;\n      },\n      onConfirmDialog (event) {\n        if (event === 'confirm') {\n            const isValid = this.$refs.renameForm.validate()\n            if (isValid) {\n                this.renameNode(this.formmodel.name, this.formmodel.title)\n            } else {\n                return\n            }\n        }\n        this.nameChanged = false\n        this.formmodel.name = ''\n        this.formmodel.title = ''\n        this.$refs.renameForm.clearValidationErrors()\n        this.$refs.renameModal.close()\n      },\n      onReady (event) {\n        this.formmodel.name = this.node.name\n        this.formmodel.title = this.node.title\n      },\n      renameNode(newName, newTitle) {\n          const that = this;\n          $perAdminApp.stateAction(`rename${this.uNodeType}`, {\n            path: this.currentObject,\n            name: newName,\n            title: newTitle,\n            edit: this.isEdit\n          }).then(() => {\n            if (that.nodeType === 'asset' || that.nodeType === 'object') {\n              const currNode = $perAdminApp.getNodeFromView(`/state/tools/${that.nodeType}/show`)\n              const currNodeArr = currNode.split('/');\n              currNodeArr[currNodeArr.length - 1] = newName\n              $perAdminApp.getNodeFromView(`/state/tools/${that.nodeType}`).show = currNodeArr.join(\n                  '/')\n            } else { // page and template handling\n              const currNode = $perAdminApp.getNodeFromView('/state/tools')[that.nodeType]\n              const currNodeArr = currNode.split('/');\n              currNodeArr[currNodeArr.length - 1] = newName\n              $perAdminApp.getNodeFromView('/state/tools')[that.nodeType] = currNodeArr.join('/')\n            }\n            this.setActiveTab(Tab.INFO)\n          })\n      },\n      moveNode() {\n        $perAdminApp.getApi().populateNodesForBrowser(this.path.current, 'pathBrowser')\n            .then(() => {\n              this.isOpen = true;\n            }).catch(() => {\n          $perAdminApp.getApi().populateNodesForBrowser(`/content/${site.tenant}`, 'pathBrowser');\n        });\n      },\n      deleteNode() {\n        const really = confirm(`Are you sure you want to delete this ${this.nodeType}?`);\n        if (really) {\n          $perAdminApp.stateAction(`delete${this.uNodeType}`, this.node.path).then(() => {\n            $perAdminApp.stateAction(`unselect${this.uNodeType}`, {})\n          }).then(() => {\n            const path = $perAdminApp.getNodeFromView('/state/tools/pages')\n            $perAdminApp.loadContent(\n                '/content/admin/pages/pages.html/path' + SUFFIX_PARAM_SEPARATOR + path)\n          })\n          this.isOpen = false;\n        }\n      },\n      setCurrentPath(path) {\n        this.path.current = path;\n      },\n      setSelectedPath(path) {\n        this.path.selected = path;\n      },\n      showVersions() {\n        $perAdminApp.getApi().populateVersions(this.currentObject);\n      },\n      deleteVersion(me, target) {\n        $perAdminApp.stateAction('deleteVersion', { path: target.path, version: target.version.name });\n      },\n      createVersion(){\n        $perAdminApp.stateAction('createVersion', this.currentObject);\n      },\n      checkoutVersion(version){\n        if(version.base === true){\n          $perAdminApp.notifyUser('Info', 'You cannot checkout the current version')\n          return\n        }\n        let self = this;\n        $perAdminApp.askUser('Restore Version',\n          `Would you like to restore ${version.name}? You may lose work unless you create a new version saving the current state.`, {\n              yesText: 'Yes',\n              noText: 'No',\n              yes() {\n                $perAdminApp.stateAction('restoreVersion', {path: self.currentObject, versionName: version.name});\n              },\n              no() {\n                console.log('no')\n              }\n          })\n      },\n      onMoveCancel() {\n        this.isOpen = false;\n      },\n      onMoveSelect() {\n        $perAdminApp.stateAction(`move${this.uNodeType}`, {\n          path: this.node.path,\n          to: this.path.selected,\n          type: 'child'\n        });\n        $perAdminApp.stateAction(`unselect${this.uNodeType}`, {});\n        this.isOpen = false;\n      },\n      save() {\n        if (this.nodeType === NodeType.OBJECT) {\n          this.saveObject();\n        } else {\n          $perAdminApp.stateAction(`save${this.uNodeType}Properties`, this.node);\n          this.edit = false;\n        }\n      },\n      saveObject() {\n        let data = this.node;\n        let {show} = this.rawCurrentObject;\n        let _deleted = $perAdminApp.getNodeFromViewWithDefault('/state/tools/_deleted', {});\n\n        //Find child nodes with subchildren for our edited object\n        for (const key in data) {\n          if (!data.hasOwnProperty(key)) {\n            continue;\n          }\n          //If node (or deleted node) is an array of objects then we have a child node\n          if ((Array.isArray(data[key]) && data[key].length && typeof data[key][0] === 'object') ||\n              (Array.isArray(_deleted[key]) && _deleted[key].length && typeof _deleted[key][0]\n                  === 'object')) {\n\n            let node = data[key];\n\n            //loop through children\n            let targetNode = {};\n            //Insert deleted children\n            for (const j in _deleted[key]) {\n              if (!_deleted[key].hasOwnProperty(j)) {\n                continue;\n              }\n              const deleted = _deleted[key][j];\n              targetNode[deleted.name] = deleted;\n            }\n            //Insert children\n            for (const i in node) {\n              if (!node.hasOwnProperty(i)) {\n                continue;\n              }\n              const child = node[i];\n              targetNode[child.name] = child;\n            }\n            data[key] = targetNode;\n          }\n        }\n        $perAdminApp.stateAction('saveObjectEdit', {data: data, path: show}).then(() => {\n          $perAdminApp.getNodeFromView('/state/tools')._deleted = {}\n        });\n        $perAdminApp.stateAction('selectObject', {selected: show})\n        this.edit = false;\n      },\n      setActiveTab(clickedTab) {\n        this.activeTab = clickedTab;\n      },\n      isTab(arg) {\n        if (Array.isArray(arg)) {\n          return arg.indexOf(this.activeTab) > -1;\n        }\n        return this.activeTab === arg;\n      }\n    }\n  }\n</script>\n\n<style>\n.deleteVersionWrapper{\n    margin-left: auto;\n}\n</style>\n"]}, media: undefined });

    };
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      browser,
      undefined
    );

  return template;

}());
