var cmpAdminComponentsPathbrowser = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var PathBrowser = {
    Type: {
      PAGE: 'page',
      ASSET: 'asset',
      IMAGE: 'image',
      OBJECT: 'object'
    }
  };

  //

  var script = {
      props: [
          'isOpen',
          'header',
          'browserRoot',
          'browserType',
          'currentPath',
          'selectedPath',
          'withLinkTab',
          'newWindow',
          'toggleNewWindow',
          'setCurrentPath',
          'setSelectedPath',
          'linkTitle',
          'setLinkTitle',
          'altText',
          'setAltText',
          'onCancel',
          'onSelect' ],
      watch: {
          cardSize: function (newCardSize) {
              this.updateIsotopeLayout('masonry');
          }
      },
      mounted: function mounted(){
          // set initial tab
          if(this.withLinkTab && this.selectedPath && this.selectedPath.match(/^(https?:)?\/\//)){
              this.tab = 'link';
          } else {
              this.tab = 'browse';
          }

          this.$on('setSelectedPath', function () {
              console.log('setSelectedPath');
          });
          this.$on('setCurrentPath', function () {
              console.log('setCurrentPath');
          });
      },
      data: function() {
          return {
              tab: null,
              cardSize: 120,
              search: '',
              previewType: this.selectedPath ? 'selected' : 'current',
              sortBy: '',
              filterBy: '*'
          }
      },
      computed: {
          isRoot: function isRoot(){
              return this.currentPath === this.browserRoot
          },
          preview: function preview(){
              if(this.previewType === 'selected'){
                  var view = $perAdminApp.getView();
                  return $perAdminApp.findNodeFromPath(view.admin.pathBrowser, this.selectedPath)
              } else {
                  return this.nodes
              }
          },
          nodes: function nodes() {
              var view = $perAdminApp.getView();
              var nodes = view.admin.pathBrowser;
              if(nodes && this.currentPath) {
                return $perAdminApp.findNodeFromPath(nodes, this.currentPath)
              }
              return {}
          },
          list: function list(){
              if(this.nodes.children){
                  return this.nodes.children
              }
              return []
          },
          tabIndicatorPosition: function tabIndicatorPosition(){
              var position;
              switch(this.tab) {
                  case ('browse'):
                      position = 0;
                      break
                  case ('cards'):
                      position = 72;
                      break
                  case ('link'):
                      position = 144;
                      break
                  default:
                      position = 0;
                      break
              }
              return position
          },
          searchTabOffset: function searchTabOffset(){
              if(this.withLinkTab){
                  return 216
              } else {
                  return 144
              }
          },
          isBrowserTypeImage: function isBrowserTypeImage() {
            return this.isType(PathBrowser.Type.IMAGE)
          }
      },
      methods: {
          onPrevent: function onPrevent(){
              return false
          },
          isImage: function isImage(item){
              return ['image/png','image/jpeg','image/jpg','image/gif','timage/tiff', 'image/svg+xml'].indexOf(item.mimeType) >= 0
          },
          isImageExtension: function isImageExtension(item) {
              return item.path.match(/.(jpg|jpeg|png|gif|svg)$/i)
          },
          getFileIcon: function getFileIcon(){
              return 'insert_drive_file'
          },
          getFolderIcon: function getFolderIcon(){
              return this.isType(PathBrowser.Type.ASSET) ? 'folder_open' : 'description'
          },
          getEmptyText: function getEmptyText(){
              return this.isType(PathBrowser.Type.ASSET) ? 'Folder is empty' : 'No child pages'
          },
          cardIconSize: function(cardSize){
              return Math.floor(cardSize/3)
          },
          getImagesLoadedCbs: function() {
            var this$1 = this;

            return {
              progress: function (instance, img ) {
                this$1.updateIsotopeLayout('masonry');
              },
              done: function (instance) {
                this$1.updateIsotopeLayout('masonry');
              }
            }
          },
          updateIsotopeLayout: function(layout){
              this.$nextTick(function () {
                  this.$refs.isotope.layout(layout);
              });
          },
          getIsotopeOptions: function() {
              var this$1 = this;

              return {
                  layoutMode: 'masonry',
                  itemSelector: '.card',
                  stamp: '.stamp',
                  masonry: {
                      gutter: 15
                  },
                  getSortData: {
                      name: function(itemElem){
                          return itemElem.name.toLowerCase()
                      },
                      created: function(itemElem){
                          return Date.parse(itemElem.created)
                      },
                      resourceType: function(itemElem){
                          return itemElem.resourceType.toLowerCase()
                      }
                  },
                  getFilterData:{
                      folders: function (itemElem) { return this$1.isFolder(itemElem); },
                      files: function (itemElem) { return this$1.isFile(itemElem); }
                  }
              }
          },
          onSort: function onSort(sortType){
              this.sortBy = sortType;
              this.$refs.isotope.sort(sortType);
          },
          onFilter: function onFilter(filterType){
              this.filterBy = filterType;
              this.$refs.isotope.filter(filterType);
          },
          select: function select(name) {
              this.tab = name;
          },
          searchFilter: function searchFilter(item) {
              if(this.search.length === 0) { return true }
              return (item.name.indexOf(this.search) >= 0)
          },
          selectParent: function selectParent() {
              var parentFolder = this.currentPath.split('/');
              parentFolder.pop();
              var newPath = parentFolder.join('/');
              /* TODO: pass in obj with name and type, not just path */
              this.navigateFolder({ path: newPath});
          },
          display: function display(item) {
              return item.name !== 'jcr:content'
          },
          isFile: function isFile(item) {
              return ['per:Asset','nt:file'].indexOf(item.resourceType) >= 0
          },
          isFileAllowed: function isFileAllowed(){
              return this.browserType !== PathBrowser.Type.PAGE
          },
          isFolder: function isFolder(item) {
              return ['per:Page','nt:folder', 'sling:Folder', 'sling:OrderedFolder'].indexOf(item.resourceType) >= 0
          },
          isSelected: function isSelected(path) {
              return this.selectedPath === path
          },
          navigateFolder: function navigateFolder(item) {
              var this$1 = this;

              $perAdminApp.getApi().populateNodesForBrowser(item.path, 'pathBrowser')
                  .then( function () {
                      this$1.previewType = 'current';
                      this$1.setCurrentPath(item.path);
                      if(this$1.tab === 'cards' && this$1.list.length > 0) { this$1.updateIsotopeLayout('masonry'); }
                      this$1.selectItem(item);
                  });
          },
          selectItem: function selectItem(item) {
              if (this.isSelectable(item)) {
                  this.previewType = 'selected';
                  this.setSelectedPath(item.path);
              }
          },
          selectLink: function selectLink(ev){
              // TODO: add link preview
              this.previewType = 'link';
              // TODO: allow target="_blank" or target="_self"
              this.setSelectedPath(ev.target.value);
          },
          isType: function isType(browserType) {
              return this.browserType === browserType
          },
          isSelectable: function isSelectable(item) {
              if (!this.isBrowserTypeImage) {
                return true
              } else if (this.isImage(item) || this.isImageExtension(item)) {
                return true
              }
              return false
          }
      }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("transition", { attrs: { name: "modal" } }, [
      _c(
        "div",
        {
          staticClass: "modal-mask",
          on: {
            click: function($event) {
              $event.stopPropagation();
              $event.preventDefault();
              return _vm.onCancel($event)
            }
          }
        },
        [
          _c("div", { staticClass: "modal-wrapper" }, [
            _c(
              "div",
              {
                staticClass: "pathbrowser modal-container",
                on: {
                  click: function($event) {
                    $event.stopPropagation();
                    $event.preventDefault();
                    return _vm.onPrevent($event)
                  }
                }
              },
              [
                _c("div", { staticClass: "modal-header" }, [
                  _vm._v(
                    "\n                " + _vm._s(_vm.header) + "\n            "
                  )
                ]),
                _vm._v(" "),
                _c("ul", { staticClass: "pathbrowser-tabs" }, [
                  _c("li", { staticClass: "tab" }, [
                    _c(
                      "a",
                      {
                        class: _vm.tab === "browse" ? "active" : "",
                        attrs: { href: "#" },
                        on: {
                          click: function($event) {
                            return _vm.select("browse")
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "material-icons" }, [
                          _vm._v("list")
                        ])
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _c("li", { staticClass: "tab" }, [
                    _c(
                      "a",
                      {
                        class: _vm.tab === "cards" ? "active" : "",
                        attrs: { href: "#" },
                        on: {
                          click: function($event) {
                            return _vm.select("cards")
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "material-icons" }, [
                          _vm._v("view_module")
                        ])
                      ]
                    )
                  ]),
                  _vm._v(" "),
                  _vm.withLinkTab
                    ? _c("li", { staticClass: "tab" }, [
                        _c(
                          "a",
                          {
                            class: _vm.tab === "link" ? "active" : "",
                            attrs: { href: "#" },
                            on: {
                              click: function($event) {
                                return _vm.select("link")
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("link")
                            ])
                          ]
                        )
                      ])
                    : _vm._e(),
                  _vm._v(" "),
                  _c("li", {
                    staticClass: "indicator",
                    style:
                      "transform: translateX(" + _vm.tabIndicatorPosition + "px)"
                  })
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    staticClass: "pathbrowser-filter",
                    style: "width: calc(100% - " + _vm.searchTabOffset + "px)"
                  },
                  [
                    _c("input", {
                      directives: [
                        {
                          name: "model",
                          rawName: "v-model",
                          value: _vm.search,
                          expression: "search"
                        }
                      ],
                      attrs: { placeholder: "search", type: "text" },
                      domProps: { value: _vm.search },
                      on: {
                        input: function($event) {
                          if ($event.target.composing) {
                            return
                          }
                          _vm.search = $event.target.value;
                        }
                      }
                    })
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "modal-content" }, [
                  _c(
                    "div",
                    { staticClass: "col-browse" },
                    [
                      _vm.search
                        ? _c(
                            "table",
                            {
                              staticClass: "highlight pathbrowser-search-results"
                            },
                            [
                              _c("thead", [
                                _c("tr", [
                                  _c("th"),
                                  _vm._v(" "),
                                  _c("th", [_vm._v("Type")]),
                                  _vm._v(" "),
                                  _c("th", [_vm._v("Name")]),
                                  _vm._v(" "),
                                  _c("th", [_vm._v("Path")])
                                ])
                              ]),
                              _vm._v(" "),
                              _c(
                                "tbody",
                                _vm._l(_vm.nodes.children, function(item) {
                                  return _vm.searchFilter(item)
                                    ? _c(
                                        "tr",
                                        {
                                          class: _vm.isSelected(item.path)
                                            ? "selected"
                                            : ""
                                        },
                                        [
                                          _vm.isSelectable(item)
                                            ? _c(
                                                "td",
                                                { staticClass: "search-radio" },
                                                [
                                                  _c("input", {
                                                    staticClass: "with-gap",
                                                    attrs: { type: "radio" },
                                                    domProps: {
                                                      checked: _vm.isSelected(
                                                        item.path
                                                      )
                                                    }
                                                  }),
                                                  _vm._v(" "),
                                                  _c("label", {
                                                    on: {
                                                      click: function($event) {
                                                        $event.stopPropagation();
                                                        $event.preventDefault();
                                                        return _vm.selectItem(
                                                          item
                                                        )
                                                      }
                                                    }
                                                  })
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _c("td", [
                                            _vm._v(
                                              _vm._s(item.mimeType || "folder")
                                            )
                                          ]),
                                          _vm._v(" "),
                                          _c("td", [_vm._v(_vm._s(item.name))]),
                                          _vm._v(" "),
                                          _c("td", [_vm._v(_vm._s(item.path))])
                                        ]
                                      )
                                    : _vm._e()
                                }),
                                0
                              )
                            ]
                          )
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.tab === "browse" && !_vm.search
                        ? [
                            _c(
                              "nav",
                              { staticClass: "modal-content-nav clearfix" },
                              [
                                _c(
                                  "div",
                                  { staticClass: "modal-content-section" },
                                  [
                                    _c(
                                      "div",
                                      { staticClass: "current-folder" },
                                      [
                                        !_vm.isRoot
                                          ? [
                                              _c(
                                                "a",
                                                {
                                                  attrs: { href: "#!" },
                                                  on: {
                                                    click: function($event) {
                                                      $event.stopPropagation();
                                                      $event.preventDefault();
                                                      return _vm.selectParent(
                                                        $event
                                                      )
                                                    }
                                                  }
                                                },
                                                [
                                                  _c(
                                                    "i",
                                                    {
                                                      staticClass:
                                                        "material-icons"
                                                    },
                                                    [
                                                      _vm._v(
                                                        "keyboard_arrow_left"
                                                      )
                                                    ]
                                                  )
                                                ]
                                              ),
                                              _vm._v(
                                                "\n                                        " +
                                                  _vm._s(_vm.currentPath) +
                                                  " (" +
                                                  _vm._s(_vm.list.length) +
                                                  ")\n                                    "
                                              )
                                            ]
                                          : [
                                              !_vm.isBrowserTypeImage
                                                ? _c("input", {
                                                    staticClass: "with-gap",
                                                    attrs: { type: "radio" },
                                                    domProps: {
                                                      checked: _vm.isSelected(
                                                        _vm.currentPath
                                                      )
                                                    }
                                                  })
                                                : _vm._e(),
                                              _vm._v(" "),
                                              _c(
                                                "label",
                                                {
                                                  on: {
                                                    click: function($event) {
                                                      $event.stopPropagation();
                                                      $event.preventDefault();
                                                      return _vm.selectItem(
                                                        _vm.nodes
                                                      )
                                                    }
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(_vm.currentPath) +
                                                      " (" +
                                                      _vm._s(_vm.list.length) +
                                                      ")"
                                                  )
                                                ]
                                              )
                                            ]
                                      ],
                                      2
                                    )
                                  ]
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _vm.list.length > 0
                              ? _c(
                                  "ul",
                                  { staticClass: "browse-list" },
                                  [
                                    _vm._l(_vm.list, function(item) {
                                      return [
                                        _vm.isFolder(item)
                                          ? _c(
                                              "li",
                                              {
                                                class: _vm.isSelected(item.path)
                                                  ? "selected"
                                                  : "",
                                                on: {
                                                  click: function($event) {
                                                    $event.stopPropagation();
                                                    $event.preventDefault();
                                                    return _vm.navigateFolder(
                                                      item
                                                    )
                                                  }
                                                }
                                              },
                                              [
                                                !_vm.isBrowserTypeImage
                                                  ? [
                                                      _c("input", {
                                                        staticClass: "with-gap",
                                                        attrs: {
                                                          name: "selectedItem",
                                                          type: "radio"
                                                        },
                                                        domProps: {
                                                          checked: _vm.isSelected(
                                                            item.path
                                                          )
                                                        }
                                                      }),
                                                      _vm._v(" "),
                                                      _c("label", {
                                                        on: {
                                                          click: function(
                                                            $event
                                                          ) {
                                                            $event.stopPropagation();
                                                            $event.preventDefault();
                                                            return _vm.selectItem(
                                                              item
                                                            )
                                                          }
                                                        }
                                                      })
                                                    ]
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _c(
                                                  "i",
                                                  {
                                                    staticClass: "material-icons"
                                                  },
                                                  [
                                                    _vm._v(
                                                      _vm._s(_vm.getFolderIcon())
                                                    )
                                                  ]
                                                ),
                                                _vm._v(" "),
                                                _c("span", [
                                                  _vm._v(_vm._s(item.name))
                                                ])
                                              ],
                                              2
                                            )
                                          : _vm._e(),
                                        _vm._v(" "),
                                        _vm.isFile(item) && _vm.isFileAllowed()
                                          ? _c(
                                              "li",
                                              {
                                                class: _vm.isSelected(item.path)
                                                  ? "selected"
                                                  : "",
                                                on: {
                                                  click: function($event) {
                                                    $event.stopPropagation();
                                                    $event.preventDefault();
                                                    return _vm.selectItem(item)
                                                  }
                                                }
                                              },
                                              [
                                                _vm.isSelectable(item)
                                                  ? [
                                                      _c("input", {
                                                        staticClass: "with-gap",
                                                        attrs: {
                                                          name: "selectedItem",
                                                          type: "radio"
                                                        },
                                                        domProps: {
                                                          checked: _vm.isSelected(
                                                            item.path
                                                          )
                                                        }
                                                      }),
                                                      _vm._v(" "),
                                                      _c("label")
                                                    ]
                                                  : _vm._e(),
                                                _vm._v(" "),
                                                _c(
                                                  "i",
                                                  {
                                                    staticClass: "material-icons"
                                                  },
                                                  [_vm._v("image")]
                                                ),
                                                _vm._v(" "),
                                                _c("span", [
                                                  _vm._v(_vm._s(item.name))
                                                ])
                                              ],
                                              2
                                            )
                                          : _vm._e()
                                      ]
                                    })
                                  ],
                                  2
                                )
                              : _c("p", { staticClass: "flow-text" }, [
                                  _vm._v(_vm._s(_vm.getEmptyText()))
                                ])
                          ]
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.tab === "cards" && !_vm.search
                        ? [
                            _c(
                              "nav",
                              { staticClass: "modal-content-nav clearfix" },
                              [
                                _c(
                                  "div",
                                  { staticClass: "modal-content-section" },
                                  [
                                    _c(
                                      "div",
                                      { staticClass: "current-folder" },
                                      [
                                        !_vm.isRoot
                                          ? [
                                              _c(
                                                "a",
                                                {
                                                  attrs: { href: "#!" },
                                                  on: {
                                                    click: function($event) {
                                                      $event.stopPropagation();
                                                      $event.preventDefault();
                                                      return _vm.selectParent(
                                                        $event
                                                      )
                                                    }
                                                  }
                                                },
                                                [
                                                  _c(
                                                    "i",
                                                    {
                                                      staticClass:
                                                        "material-icons"
                                                    },
                                                    [
                                                      _vm._v(
                                                        "keyboard_arrow_left"
                                                      )
                                                    ]
                                                  )
                                                ]
                                              ),
                                              _vm._v(
                                                "\n                                        " +
                                                  _vm._s(_vm.currentPath) +
                                                  " (" +
                                                  _vm._s(_vm.list.length) +
                                                  ")\n                                    "
                                              )
                                            ]
                                          : [
                                              !_vm.isBrowserTypeImage
                                                ? _c("input", {
                                                    staticClass: "with-gap",
                                                    attrs: { type: "radio" },
                                                    domProps: {
                                                      checked: _vm.isSelected(
                                                        _vm.currentPath
                                                      )
                                                    }
                                                  })
                                                : _vm._e(),
                                              _vm._v(" "),
                                              _c(
                                                "label",
                                                {
                                                  on: {
                                                    click: function($event) {
                                                      $event.stopPropagation();
                                                      $event.preventDefault();
                                                      return _vm.selectItem(
                                                        _vm.nodes
                                                      )
                                                    }
                                                  }
                                                },
                                                [
                                                  _vm._v(
                                                    _vm._s(_vm.currentPath) +
                                                      " (" +
                                                      _vm._s(_vm.list.length) +
                                                      ")"
                                                  )
                                                ]
                                              )
                                            ]
                                      ],
                                      2
                                    )
                                  ]
                                ),
                                _vm._v(" "),
                                _c(
                                  "div",
                                  { staticClass: "modal-content-section" },
                                  [
                                    _c(
                                      "ul",
                                      { staticClass: "cards-toolbar sort-nav" },
                                      [
                                        _c("li", [
                                          _c(
                                            "span",
                                            {
                                              staticClass: "cards-toolbar-title"
                                            },
                                            [_vm._v("Sort")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_sort_cards",
                                              type: "radio",
                                              id: "assetbrowser_sort_cards_name"
                                            },
                                            domProps: {
                                              checked: _vm.sortBy === "name"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_sort_cards_name"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onSort("name")
                                                }
                                              }
                                            },
                                            [_vm._v("name")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_sort_cards",
                                              type: "radio",
                                              id: "assetbrowser_sort_cards_type"
                                            },
                                            domProps: {
                                              checked:
                                                _vm.sortBy === "resourceType"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_sort_cards_type"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onSort(
                                                    "resourceType"
                                                  )
                                                }
                                              }
                                            },
                                            [_vm._v("type")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_sort_cards",
                                              type: "radio",
                                              id: "assetbrowser_sort_cards_date"
                                            },
                                            domProps: {
                                              checked: _vm.sortBy === "created"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_sort_cards_date"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onSort("created")
                                                }
                                              }
                                            },
                                            [_vm._v("date")]
                                          )
                                        ])
                                      ]
                                    ),
                                    _vm._v(" "),
                                    _c(
                                      "ul",
                                      { staticClass: "cards-toolbar filter-nav" },
                                      [
                                        _c("li", [
                                          _c(
                                            "span",
                                            {
                                              staticClass: "cards-toolbar-title"
                                            },
                                            [_vm._v("filter")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_filter_cards",
                                              type: "radio",
                                              id: "assetbrowser_filter_cards_all"
                                            },
                                            domProps: {
                                              checked: _vm.filterBy === "*"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_filter_cards_all"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onFilter("*")
                                                }
                                              }
                                            },
                                            [_vm._v("all")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_filter_cards",
                                              type: "radio",
                                              id:
                                                "assetbrowser_filter_cards_files"
                                            },
                                            domProps: {
                                              checked: _vm.filterBy === "files"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_filter_cards_files"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onFilter("files")
                                                }
                                              }
                                            },
                                            [_vm._v("files")]
                                          )
                                        ]),
                                        _vm._v(" "),
                                        _c("li", [
                                          _c("input", {
                                            staticClass: "with-gap",
                                            attrs: {
                                              name: "assetbrowser_filter_cards",
                                              type: "radio",
                                              id:
                                                "assetbrowser_filter_cards_folders"
                                            },
                                            domProps: {
                                              checked: _vm.filterBy === "folders"
                                            }
                                          }),
                                          _vm._v(" "),
                                          _c(
                                            "label",
                                            {
                                              attrs: {
                                                for:
                                                  "assetbrowser_filter_cards_folders"
                                              },
                                              on: {
                                                click: function($event) {
                                                  return _vm.onFilter("folders")
                                                }
                                              }
                                            },
                                            [_vm._v("folders")]
                                          )
                                        ])
                                      ]
                                    )
                                  ]
                                )
                              ]
                            ),
                            _vm._v(" "),
                            _vm.list.length > 0
                              ? [
                                  _c("p", { staticClass: "range-field" }, [
                                    _c("input", {
                                      directives: [
                                        {
                                          name: "model",
                                          rawName: "v-model",
                                          value: _vm.cardSize,
                                          expression: "cardSize"
                                        }
                                      ],
                                      attrs: {
                                        type: "range",
                                        min: "120",
                                        max: "400"
                                      },
                                      domProps: { value: _vm.cardSize },
                                      on: {
                                        __r: function($event) {
                                          _vm.cardSize = $event.target.value;
                                        }
                                      }
                                    })
                                  ]),
                                  _vm._v(" "),
                                  _c(
                                    "isotope",
                                    {
                                      directives: [
                                        {
                                          name: "images-loaded",
                                          rawName: "v-images-loaded:on",
                                          value: _vm.getImagesLoadedCbs(),
                                          expression: "getImagesLoadedCbs()",
                                          arg: "on"
                                        }
                                      ],
                                      ref: "isotope",
                                      staticClass: "isotopes",
                                      attrs: {
                                        options: _vm.getIsotopeOptions(),
                                        list: _vm.list
                                      }
                                    },
                                    _vm._l(_vm.list, function(item, index) {
                                      return _c(
                                        "div",
                                        { key: item.path },
                                        [
                                          _vm.isFolder(item)
                                            ? _c(
                                                "div",
                                                {
                                                  staticClass: "item-folder",
                                                  style:
                                                    "width: " +
                                                    _vm.cardSize +
                                                    "px; height: " +
                                                    _vm.cardSize +
                                                    "px",
                                                  on: {
                                                    click: function($event) {
                                                      $event.stopPropagation();
                                                      $event.preventDefault();
                                                      return _vm.navigateFolder(
                                                        item
                                                      )
                                                    }
                                                  }
                                                },
                                                [
                                                  _vm.isSelectable(item)
                                                    ? _c(
                                                        "div",
                                                        {
                                                          staticClass:
                                                            "item-select"
                                                        },
                                                        [
                                                          _c("input", {
                                                            staticClass:
                                                              "with-gap",
                                                            attrs: {
                                                              name:
                                                                "selectedItem",
                                                              type: "radio"
                                                            },
                                                            domProps: {
                                                              checked: _vm.isSelected(
                                                                item.path
                                                              )
                                                            }
                                                          }),
                                                          _vm._v(" "),
                                                          _c("label", {
                                                            on: {
                                                              click: function(
                                                                $event
                                                              ) {
                                                                $event.stopPropagation();
                                                                $event.preventDefault();
                                                                return _vm.selectItem(
                                                                  item
                                                                )
                                                              }
                                                            }
                                                          })
                                                        ]
                                                      )
                                                    : _vm._e(),
                                                  _vm._v(" "),
                                                  _c(
                                                    "div",
                                                    {
                                                      staticClass: "item-content"
                                                    },
                                                    [
                                                      _c(
                                                        "i",
                                                        {
                                                          staticClass:
                                                            "material-icons",
                                                          style:
                                                            "font-size: " +
                                                            _vm.cardIconSize(
                                                              _vm.cardSize
                                                            ) +
                                                            "px"
                                                        },
                                                        [
                                                          _vm._v(
                                                            _vm._s(
                                                              _vm.getFolderIcon()
                                                            )
                                                          )
                                                        ]
                                                      ),
                                                      _vm._v(" "),
                                                      _c("br"),
                                                      _vm._v(" "),
                                                      _c(
                                                        "span",
                                                        {
                                                          staticClass: "truncate"
                                                        },
                                                        [
                                                          _vm._v(
                                                            _vm._s(item.name)
                                                          )
                                                        ]
                                                      )
                                                    ]
                                                  )
                                                ]
                                              )
                                            : _vm._e(),
                                          _vm._v(" "),
                                          _vm.isFile(item) && _vm.isFileAllowed()
                                            ? [
                                                _vm.isImage(item)
                                                  ? _c("img", {
                                                      class: _vm.isSelected(
                                                        item.path
                                                      )
                                                        ? "item-image selected"
                                                        : "item-image",
                                                      style:
                                                        "width: " +
                                                        _vm.cardSize +
                                                        "px",
                                                      attrs: { src: item.path },
                                                      on: {
                                                        click: function($event) {
                                                          $event.stopPropagation();
                                                          $event.preventDefault();
                                                          return _vm.selectItem(
                                                            item
                                                          )
                                                        }
                                                      }
                                                    })
                                                  : _c(
                                                      "div",
                                                      {
                                                        class: _vm.isSelected(
                                                          item.path
                                                        )
                                                          ? "item-file selected"
                                                          : "item-file",
                                                        style:
                                                          "width: " +
                                                          _vm.cardSize +
                                                          "px; height: " +
                                                          _vm.cardSize +
                                                          "px",
                                                        attrs: {
                                                          title: item.name
                                                        },
                                                        on: {
                                                          click: function(
                                                            $event
                                                          ) {
                                                            $event.stopPropagation();
                                                            $event.preventDefault();
                                                            return _vm.selectItem(
                                                              item
                                                            )
                                                          }
                                                        }
                                                      },
                                                      [
                                                        _c(
                                                          "div",
                                                          {
                                                            staticClass:
                                                              "item-content"
                                                          },
                                                          [
                                                            _c(
                                                              "i",
                                                              {
                                                                staticClass:
                                                                  "material-icons",
                                                                style:
                                                                  "font-size: " +
                                                                  _vm.cardIconSize(
                                                                    _vm.cardSize
                                                                  ) +
                                                                  "px"
                                                              },
                                                              [
                                                                _vm._v(
                                                                  _vm._s(
                                                                    _vm.getFileIcon()
                                                                  )
                                                                )
                                                              ]
                                                            ),
                                                            _vm._v(" "),
                                                            _c("br"),
                                                            _vm._v(" "),
                                                            _c(
                                                              "span",
                                                              {
                                                                staticClass:
                                                                  "truncate"
                                                              },
                                                              [
                                                                _vm._v(
                                                                  _vm._s(
                                                                    item.name
                                                                  )
                                                                )
                                                              ]
                                                            )
                                                          ]
                                                        )
                                                      ]
                                                    )
                                              ]
                                            : _vm._e()
                                        ],
                                        2
                                      )
                                    }),
                                    0
                                  )
                                ]
                              : _c("p", { staticClass: "flow-text" }, [
                                  _vm._v(_vm._s(_vm.getEmptyText()))
                                ])
                          ]
                        : _vm._e(),
                      _vm._v(" "),
                      _vm.withLinkTab && _vm.tab === "link" && !_vm.search
                        ? [
                            _c("div", { staticClass: "form-group" }, [
                              _c("label", { attrs: { for: "pathBrowserLink" } }, [
                                _vm._v("URL")
                              ]),
                              _vm._v(" "),
                              _c("input", {
                                ref: "pathBrowserLink",
                                attrs: {
                                  id: "pathBrowserLink",
                                  type: "url",
                                  placeholder: "https://"
                                },
                                domProps: { value: _vm.selectedPath },
                                on: {
                                  mousedown: function($event) {},
                                  input: _vm.selectLink
                                }
                              })
                            ]),
                            _vm._v(" "),
                            _vm.altText !== undefined
                              ? _c("div", { staticClass: "form-group" }, [
                                  _c("label", { attrs: { for: "altText" } }, [
                                    _vm._v("Image Alternate Text")
                                  ]),
                                  _vm._v(" "),
                                  _c("input", {
                                    attrs: {
                                      id: "altText",
                                      type: "text",
                                      placeholder: "Alt Text"
                                    },
                                    domProps: { value: _vm.altText },
                                    on: { input: _vm.setAltText }
                                  })
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.linkTitle !== undefined
                              ? _c("div", { staticClass: "form-group" }, [
                                  _c("label", { attrs: { for: "linkTitle" } }, [
                                    _vm._v("Link Title")
                                  ]),
                                  _vm._v(" "),
                                  _c("input", {
                                    attrs: {
                                      id: "linkTitle",
                                      type: "text",
                                      placeholder: "Link Title"
                                    },
                                    domProps: { value: _vm.linkTitle },
                                    on: { input: _vm.setLinkTitle }
                                  })
                                ])
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.newWindow !== undefined
                              ? _c(
                                  "div",
                                  {
                                    staticClass: "pathbrowser-newwindow",
                                    on: {
                                      click: _vm.toggleNewWindow,
                                      keyup: function($event) {
                                        if (
                                          !$event.type.indexOf("key") &&
                                          _vm._k(
                                            $event.keyCode,
                                            "space",
                                            32,
                                            $event.key,
                                            [" ", "Spacebar"]
                                          )
                                        ) {
                                          return null
                                        }
                                        return _vm.toggleNewWindow($event)
                                      }
                                    }
                                  },
                                  [
                                    _c("input", {
                                      attrs: {
                                        type: "checkbox",
                                        id: "newWindow"
                                      },
                                      domProps: { checked: _vm.newWindow }
                                    }),
                                    _vm._v(" "),
                                    _c("label", { attrs: { for: "newWindow" } }, [
                                      _vm._v("Open in new window?")
                                    ])
                                  ]
                                )
                              : _vm._e()
                          ]
                        : _vm._e()
                    ],
                    2
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "col-preview" },
                    [
                      _vm.preview
                        ? [
                            _vm.isFolder(_vm.preview)
                              ? _c(
                                  "div",
                                  { staticClass: "preview-folder" },
                                  [_c("admin-components-iconopenfolder")],
                                  1
                                )
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.isFile(_vm.preview)
                              ? [
                                   _c("img", {
                                        staticClass: "preview-image",
                                        attrs: { src: _vm.preview.path }
                                      })
                                    
                                ]
                              : _vm._e(),
                            _vm._v(" "),
                            _c("dl", { staticClass: "preview-data" }, [
                              _c("dt", [_vm._v("Name")]),
                              _vm._v(" "),
                              _c("dd", [_vm._v(_vm._s(_vm.preview.name))]),
                              _vm._v(" "),
                              _c("dt", [_vm._v("Type")]),
                              _vm._v(" "),
                              _c("dd", [
                                _vm._v(_vm._s(_vm.preview.resourceType))
                              ]),
                              _vm._v(" "),
                              _c("dt", [_vm._v("Path")]),
                              _vm._v(" "),
                              _c("dd", [_vm._v(_vm._s(_vm.preview.path))]),
                              _vm._v(" "),
                              _c("dt", [_vm._v("Created")]),
                              _vm._v(" "),
                              _c("dd", [_vm._v(_vm._s(_vm.preview.created))])
                            ])
                          ]
                        : _c("div", { staticClass: "no-asset-selected" }, [
                            _c("span", [
                              _vm._v(_vm._s(_vm.$i18n("noAssetSelected")))
                            ]),
                            _vm._v(" "),
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("info")
                            ])
                          ])
                    ],
                    2
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "modal-footer" }, [
                  _c("div", { staticClass: "pathbrowser-footer-details" }, [
                    _c("span", { staticClass: "pathbrowser-selected-path" }, [
                      _vm._v(_vm._s(_vm.selectedPath))
                    ])
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "pathbrowser-buttons" }, [
                    _c(
                      "button",
                      {
                        staticClass:
                          "modal-action waves-effect waves-light btn-flat",
                        on: { click: _vm.onCancel }
                      },
                      [
                        _vm._v(
                          "\n                                cancel\n                        "
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "button",
                      {
                        staticClass:
                          "modal-action waves-effect waves-light btn-flat",
                        on: { click: _vm.onSelect }
                      },
                      [
                        _vm._v(
                          "\n                                select\n                        "
                        )
                      ]
                    )
                  ])
                ])
              ]
            )
          ])
        ]
      )
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
