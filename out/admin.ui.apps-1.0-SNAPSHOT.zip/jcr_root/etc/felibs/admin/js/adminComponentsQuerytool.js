var cmpAdminComponentsQuerytool = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        data: function() {

                if(!this.results) { this.results = {
                                                     pages: 0,
                                                     more: false,
                                                     data: []
                                                 }; }

                return {
                    querystring: 'select * from nt:base',
                    page: 0,
                    results: this.results

            }
        },
        methods: {
            executeQuery: function() {
                this.page = 0;
                this.more = false;
                this.query();
            },
            query: function() {
                var resObj = this.results;
                axios.get('/bin/search?q='+this.querystring+'&page='+this.page).then(function(result) {
                    resObj.data = result.data.data;
                    resObj.pages = result.data.pages;
                    resObj.more = result.data.more;
                });
            },
            loadPage: function(increment) {
                this.page = this.page + increment;
                this.query();
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", [
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col s12" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.querystring,
                  expression: "querystring"
                }
              ],
              domProps: { value: _vm.querystring },
              on: {
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.querystring = $event.target.value;
                }
              }
            }),
            _vm._v(" "),
            _c("div", { staticClass: "right" }, [
              _c(
                "button",
                {
                  staticClass: "btn",
                  attrs: { title: "go" },
                  on: { click: _vm.executeQuery }
                },
                [_vm._v("go")]
              )
            ])
          ])
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "row" }, [
          _c("div", { staticClass: "col s12" }, [
            _c("table", [
              _vm._m(0),
              _vm._v(" "),
              _c(
                "tbody",
                _vm._l(_vm.results.data, function(result) {
                  return _c("tr", [
                    _c("td", [_vm._v(_vm._s(result.name))]),
                    _vm._v(" "),
                    _c("td", [_vm._v(_vm._s(result.path))]),
                    _vm._v(" "),
                    _c("td", [
                      _c(
                        "a",
                        {
                          attrs: {
                            href: "/bin/browser.html" + result.path,
                            target: "composum"
                          }
                        },
                        [_vm._v("view")]
                      )
                    ])
                  ])
                }),
                0
              )
            ]),
            _vm._v(" "),
            _c("ul", { staticClass: "pagination" }, [
              _c("li", { staticClass: "waves-effect" }, [
                _c(
                  "a",
                  {
                    attrs: { href: "" },
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.loadPage(-1)
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("chevron_left")
                    ])
                  ]
                )
              ]),
              _vm._v(" "),
              _c("li", [
                _vm._v("Page " + _vm._s(_vm.page + 1) + "\n              ")
              ]),
              _c("li", { staticClass: "waves-effect" }, [
                _c(
                  "a",
                  {
                    attrs: { href: "" },
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.loadPage(1)
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("chevron_right")
                    ])
                  ]
                )
              ])
            ])
          ])
        ])
      ])
    };
    var __vue_staticRenderFns__ = [
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("thead", [
          _c("tr", [
            _c("th", [_vm._v("Resource")]),
            _vm._v(" "),
            _c("th", [_vm._v("Path")]),
            _vm._v(" "),
            _c("th", [_vm._v("Actions")])
          ])
        ])
      }
    ];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
