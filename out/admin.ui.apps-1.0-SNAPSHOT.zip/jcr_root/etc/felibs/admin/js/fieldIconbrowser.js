var cmpFieldIconbrowser = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

        var script = {
            props: ['model'],
            mixins: [ VueFormGenerator.abstractField ],
            data: function data () {
                return {
                    isOpen: false,
                    families: null,
                    selectedIcon: {
                        family: null,
                        class: null,
                        text: null
                    }
                }
            },
            computed: {
    			sanitizedValue: {
    				get: function get () {
          		        return this.value ? this.value : ''
    				},
    				set: function set (newValue) {
    					this.value = newValue;
    				}
    			}
    		},
            created: function created () {
                var this$1 = this;

                // set initial state from value
                this.selectedIcon = this.getIconFromValue(this.sanitizedValue);
                // create families array from schema
                this.families = this.schema.families.map(function (family) {
                    return {
                        name: family,
                        value: this$1.camelize(family)
                    }
                });
            },
            watch: {
                sanitizedValue: function sanitizedValue (newSanitizedValue) {
                    // keep selectedIcon synced with value (if valid)
                    this.selectedIcon = this.getIconFromValue(newSanitizedValue);
                }
            },
            methods: {
                onCancel: function onCancel () {
                    this.isOpen = false;
                },
                onSelect: function onSelect (icon) {
                    this.value = (icon.family) + ":" + (icon.class) + ":" + (icon.text);
                    this.isOpen = false;
                },
                browse: function browse () {
                    this.isOpen = true;
                },
                getIconFromValue: function getIconFromValue (value) {
                    var iconParts = value.split(':'); //[iconFamily, iconClass, iconText]
                    if(iconParts && iconParts.length > 2){
                        return {
                            family: iconParts[0],
                            class: iconParts[1],
                            text: iconParts[2]
                        }
                    }
                    return this.selectedIcon
                },
                camelize: function camelize (str) {
                    return str.replace(/(?:^\w|[A-Z]|\b\w)/g, function(letter, index) {
                        return index == 0 ? letter.toLowerCase() : letter.toUpperCase();
                    }).replace(/\s+/g, '');
                }
            }
        };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        { staticClass: "wrap" },
        [
          !_vm.schema.preview
            ? [
                _c("input", {
                  attrs: {
                    id: _vm.getFieldID(_vm.schema),
                    type: "text",
                    disabled: _vm.disabled,
                    maxlength: _vm.schema.max,
                    placeholder: _vm.schema.placeholder,
                    readonly: _vm.schema.readonly
                  },
                  domProps: { value: _vm.sanitizedValue },
                  on: {
                    input: function($event) {
                      _vm.value = $event.target.value;
                    }
                  }
                }),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "btn-flat",
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.browse($event)
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [
                      _vm._v("insert_drive_file")
                    ])
                  ]
                ),
                _vm._v(" "),
                _c("div", { staticClass: "icon" }, [
                  _c("i", { class: _vm.selectedIcon.class }, [
                    _vm._v(_vm._s(_vm.selectedIcon.text))
                  ])
                ]),
                _vm._v(" "),
                _vm.isOpen
                  ? _c("admin-components-iconbrowser", {
                      attrs: {
                        families: _vm.families,
                        selectedIcon: _vm.selectedIcon,
                        onCancel: _vm.onCancel,
                        onSelect: _vm.onSelect
                      }
                    })
                  : _vm._e()
              ]
            : _c("p", [
                _c("i", { class: _vm.selectedIcon.class }, [
                  _vm._v(_vm._s(_vm.selectedIcon.text))
                ]),
                _vm._v(_vm._s(_vm.value))
              ])
        ],
        2
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
