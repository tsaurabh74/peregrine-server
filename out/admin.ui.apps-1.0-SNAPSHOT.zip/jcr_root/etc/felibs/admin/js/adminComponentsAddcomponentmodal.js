var cmpAdminComponentsAddcomponentmodal = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var Attribute = {
    INLINE: 'data-per-inline',
    PATH: 'data-per-path',
    DROPTARGET: 'data-per-droptarget',
    LOCATION: 'data-per-location'
  };

  var Key = {
    A: 65,
    BACKSPACE: 8,
    DELETE: 46,
    DOT: 190,
    COMMA: 188,
    ARROW_LEFT: 37,
    ARROW_UP: 38,
    ARROW_RIGHT: 39,
    ARROW_DOWN: 40,
    ESC: 27
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function get(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(value !== undefined && !node[path[0]]) {
          if(vue) {
              Vue.set(node, path[0], value);
          } else {
              node[path[0]] = value;
          }
      }
      return node[path[0]]
  }

  //

  var script = {
    name: 'AddComponentModal',
    props: {
      selectedComponent: null,
      isDropTarget: Boolean,
      windows: Array
    },
    data: function data() {
      return {
        visible: false,
        filter: '',
        component: null,
        windowEventListeners: [],
        drop: ''
      }
    },
    computed: {
      view: function view() {
        return $perAdminApp.getView()
      },
      node: function node() {
        var path = get(this.view, '/state/editor/path', null);
        if (path) {
          return $perAdminApp.findNodeFromPath(this.view.pageView.page, path)
        } else {
          return null
        }
      },
      filteredComponents: function filteredComponents() {
        var this$1 = this;

        return get(this.view, '/admin/components/data', []).filter(function (el) {
          var tenant = this$1.view.state.tenant;
          var lCmpName = this$1.componentDisplayName(el).toLowerCase();
          var filter = this$1.filter.toLowerCase();

          if (!tenant || !tenant.name || el.group === '.hidden' || !lCmpName.startsWith(filter)) {
            return false
          } else {
            return el.path.startsWith('/apps/' + tenant.name + '/')
          }
        })
      },
      componentKey: function componentKey() {
        var key = this.component.path;

        if (this.component.variation) {
          key += ':' + this.component.variation;
        }

        return key
      },
      componentCount: function componentCount() {
        return this.filteredComponents.length
      },
      computedDrop: function computedDrop() {
        return (this.isDropTarget ? 'into-' : '') + this.drop
      }
    },
    watch: {
      windows: function windows(val) {
        this.clearWindowEventListeners();
        this.bindWindowEventListeners();
      }
    },
    mounted: function mounted() {
      this.bindWindowEventListeners();
    },
    methods: {
      open: function open(drop) {
        var this$1 = this;

        this.visible = true;
        this.drop = drop;
        this.$nextTick(function () {
          this$1.$refs.header.scrollIntoView(true);
          this$1.$refs.filter.focus();
        });
      },
      close: function close() {
        this.visible = false;
        this.filter = '';
        this.dropBefore = false;
      },
      onComponentBtnClick: function onComponentBtnClick(component) {
        this.component = component;
        this.addComponentFromModal();
      },
      componentDisplayName: function componentDisplayName(component) {
        if (component.title) {
          return component.title
        } else {
          return component.path.split('/')[2] + ' ' + component.name
        }
      },
      addComponentFromModal: function addComponentFromModal() {
        var this$1 = this;

        var view = this.view;
        var payload = {
          pagePath: view.pageView.path,
          path: this.selectedComponent.getAttribute(Attribute.PATH),
          component: this.componentKey,
          drop: this.computedDrop
        };

        $perAdminApp.stateAction('savePageEdit', {
          data: this.node,
          path: this.view.state.editor.path
        }).then(function () {
          return $perAdminApp.stateAction('addComponentToPath', payload)
        }).then(function (data) {
          this$1.close();
          this$1.$emit('component-added', this$1.findNewNode(payload));
        });
      },
      findNewNode: function findNewNode(payload) {
        if (['after', 'before'].includes(payload.drop)) {
          var split = payload.path.split('/');
          split.pop();
          var parentPath = split.join('/');
          var parentNode = $perAdminApp.findNodeFromPath(this.view.pageView.page, parentPath);
          var index = null;
          parentNode.children.some(function (child, i) {
            if (child.path === payload.path) {
              index = i;
            }
          });

          if (payload.drop === 'after') {
            return parentNode.children[index + 1]
          } else if (payload.drop === 'before') {
            return parentNode.children[index - 1]
          }
        } else if (payload.drop.startsWith('into')) {
          var targetNode = $perAdminApp.findNodeFromPath(this.view.pageView.page, payload.path);

          if (payload.drop === 'into-before') {
            return targetNode.children[0]
          } else if (payload.drop === 'into-after') {
            return targetNode.children[targetNode.children.length - 1]
          }
        }

        throw ("unexpected drop: " + (payload.drop))
      },
      onKeyDown: function onKeyDown(event) {
        if (!this.selectedComponent) { return }

        var key = event.which;
        var shift = event.shiftKey;
        var ctrlOrCmd = event.ctrlKey || event.metaKey;

        if (!this.visible) {
          if (ctrlOrCmd) {
            if (key === Key.DOT) {
              this.open('after');
            } else if (key === Key.COMMA) {
              this.open('before');
            }
          }
        } else if (this.visible) {
          if (key === Key.ESC) {
            this.close();
          }
        }
      },
      onFilterKeyDown: function onFilterKeyDown(event) {
        if (this.componentCount <= 0) { return }

        var key = event.which;

        if (key === Key.ARROW_DOWN || key === Key.ARROW_RIGHT) {
          event.preventDefault();
          this.$refs.componentBtn[0].focus();
        }
      },
      omComponentBtnKeyDown: function omComponentBtnKeyDown(event, index) {
        if (this.componentCount <= 0) { return }

        var key = event.which;

        if (key === Key.ARROW_DOWN || key === Key.ARROW_RIGHT) {
          if (index + 1 < this.componentCount) {
            event.preventDefault();
            this.$refs.componentBtn[index + 1].focus();
          }
        } else if (key === Key.ARROW_UP || key === Key.ARROW_LEFT) {
          if (index - 1 >= 0) {
            event.preventDefault();
            this.$refs.componentBtn[index - 1].focus();
          } else {
            this.$refs.header.scrollIntoView(true);
            this.$refs.filter.focus();
          }
        }
      },
      bindWindowEventListeners: function bindWindowEventListeners() {
        var this$1 = this;

        this.windows.forEach(function (win) {
          this$1.windowEventListeners.push({
            window: win,
            type: 'keydown',
            id: win.addEventListener('keydown', this$1.onKeyDown)
          });
        });
      },
      clearWindowEventListeners: function clearWindowEventListeners() {
        this.windowEventListeners.forEach(function (listener) {
          listener.window.removeEventListener(listener.type, listener.id);
        });
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      {
        directives: [
          {
            name: "show",
            rawName: "v-show",
            value: _vm.visible,
            expression: "visible"
          }
        ],
        staticClass: "add-component-modal-wrapper"
      },
      [
        _c("div", { staticClass: "add-component-modal" }, [
          _c("div", { ref: "header", staticClass: "header" }, [
            _vm._v("Add Component: "),
            _c("b", [_vm._v(_vm._s(_vm.computedDrop))])
          ]),
          _vm._v(" "),
          _c("div", { staticClass: "content" }, [
            _c("input", {
              directives: [
                {
                  name: "model",
                  rawName: "v-model",
                  value: _vm.filter,
                  expression: "filter"
                }
              ],
              ref: "filter",
              staticClass: "filter",
              attrs: { type: "text", placeholder: "filter components" },
              domProps: { value: _vm.filter },
              on: {
                keydown: _vm.onFilterKeyDown,
                input: function($event) {
                  if ($event.target.composing) {
                    return
                  }
                  _vm.filter = $event.target.value;
                }
              }
            }),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "component-list" },
              _vm._l(_vm.filteredComponents, function(component, index) {
                return _c(
                  "button",
                  {
                    key: component.path + "-" + component.variation + "-" + index,
                    ref: "componentBtn",
                    refInFor: true,
                    staticClass: "component-btn",
                    on: {
                      click: function($event) {
                        return _vm.onComponentBtnClick(component)
                      },
                      keydown: function($event) {
                        return _vm.omComponentBtnKeyDown($event, index)
                      }
                    }
                  },
                  [
                    _vm._v(
                      "\n          " +
                        _vm._s(_vm.componentDisplayName(component)) +
                        "\n        "
                    )
                  ]
                )
              }),
              0
            )
          ])
        ])
      ]
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
