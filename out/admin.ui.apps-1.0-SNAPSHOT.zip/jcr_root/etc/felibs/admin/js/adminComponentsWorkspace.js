var cmpAdminComponentsWorkspace = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        computed: {
            state: function() {
                return $perAdminApp.getView().state
            },
            editorVisible: function() {
                return $perAdminApp.getNodeFromView('/state/editorVisible')
            },
            getRightPanelClasses: function() {
                // rightPanelVisible: true/false
                return ("right-panel " + ($perAdminApp.getView().state.rightPanelVisible ? 'visible' : ''))
            },
            isFullscreen: function isFullscreen(){
              return $perAdminApp.getView().state.rightPanelFullscreen || false
            }
        },
        methods: {
            getChildByPath: function getChildByPath(childName) {
                var path = this.model.path+'/'+childName;
                for(var i = 0; i < this.model.children.length; i++) {
                    if(this.model.children[i].path === path) {
                        var ret = this.model.children[i];
                        ret.classes = 'col fullheight s4';
                        return ret
                    }
                }
                return null
            },

            showHide: function showHide(me, name) {
                $perAdminApp.getView().state.rightPanelVisible = $perAdminApp.getView().state.rightPanelVisible ? false: true;
            },

            showComponentEdit: function showComponentEdit(me, target) {
              // only trigger state action if another component is selected
              if($perAdminApp.getNodeFromView('/state/editor/path') !== target) {
                return $perAdminApp.stateAction('editComponent', target)
              } else {
                  return new Promise(function (resolve) {
                      resolve();
                  })
              }
            },

            onEditorExitFullscreen: function onEditorExitFullscreen(){
              $perAdminApp.getView().state.rightPanelFullscreen = false;
            },

            onEditorFullscreen: function onEditorFullscreen(){
              $perAdminApp.getView().state.rightPanelFullscreen = true;
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        {
          class:
            "peregrine-workspace " +
            (_vm.state.rightPanelVisible ? "right-panel-visible" : "")
        },
        [
          _c(_vm.getChildByPath("contentview").component, {
            tag: "component",
            attrs: { model: _vm.getChildByPath("contentview") }
          }),
          _vm._v(" "),
          !_vm.state.rightPanelVisible
            ? _c(
                "admin-components-action",
                {
                  attrs: {
                    model: {
                      classes: "show-right-panel",
                      target: "rightPanelVisible",
                      command: "showHide",
                      tooltipTitle: _vm.$i18n("showComponentsPanel")
                    }
                  }
                },
                [
                  _c("i", { staticClass: "material-icons" }, [
                    _vm._v("keyboard_arrow_left")
                  ])
                ]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "aside",
            {
              class:
                "explorer-preview right-panel " +
                (_vm.isFullscreen ? "fullscreen" : "narrow")
            },
            [
              !_vm.state.editorVisible
                ? _c(
                    "admin-components-action",
                    {
                      attrs: {
                        model: {
                          classes: "hide-right-panel",
                          target: "rightPanelVisible",
                          command: "showHide",
                          tooltipTitle: _vm.$i18n("hideComponentsPanel")
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("highlight_off")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.state.editorVisible && _vm.isFullscreen
                ? _c(
                    "button",
                    {
                      staticClass: "toggle-fullscreen",
                      attrs: { type: "button", title: "exit fullscreen" },
                      on: {
                        click: function($event) {
                          $event.preventDefault();
                          return _vm.onEditorExitFullscreen($event)
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("fullscreen_exit")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.state.editorVisible && !_vm.isFullscreen
                ? _c(
                    "button",
                    {
                      staticClass: "toggle-fullscreen",
                      attrs: {
                        type: "button",
                        title: _vm.$i18n("enterFullscreen")
                      },
                      on: {
                        click: function($event) {
                          $event.preventDefault();
                          return _vm.onEditorFullscreen($event)
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("fullscreen")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.state.editorVisible
                ? _c(_vm.getChildByPath("editor").component, {
                    tag: "component",
                    attrs: { model: _vm.getChildByPath("editor") }
                  })
                : _vm.getChildByPath("right-panel")
                ? _c(_vm.getChildByPath("right-panel").component, {
                    tag: "component",
                    attrs: { model: _vm.getChildByPath("right-panel") }
                  })
                : _c(_vm.getChildByPath("components").component, {
                    tag: "component",
                    attrs: { model: _vm.getChildByPath("components") }
                  })
            ],
            1
          )
        ],
        1
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
