var cmpFieldPathbrowser = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var PathBrowser = {
    Type: {
      PAGE: 'page',
      ASSET: 'asset',
      IMAGE: 'image',
      OBJECT: 'object'
    }
  };

  //

    var script = {
          props: ['model'],
          mixins: [ VueFormGenerator.abstractField ],
          data: function data () {
              return {
                  isOpen: false,
                  browserRoot: '/assets',
                  browserType: PathBrowser.Type.ASSET,
                  currentPath: '/assets',
                  selectedPath: null,
                  withLinkTab: true
              }
          },
          computed: {
  			sanitizedValue: {
  				get: function get () {
        		        return this.value ? this.value : ''
  				},
  				set: function set (newValue) {
  					this.value = newValue;
  				}
  			}
  		},
        created: function created() {
            this.browserRoot = this.getBasePath() + this.browserRoot;
            this.currentPath = this.getBasePath() + this.currentPath;
        },
        methods: {
              getBasePath: function getBasePath() {
                var view = $perAdminApp.getView();
                var tenant = { name: 'example' };
                if (view.state.tenant) {
                  tenant = view.state.tenant;
                }
                return ("/content/" + (tenant.name))
              },
              onCancel: function onCancel(){
                  this.isOpen = false;
              },
              onSelect: function onSelect() {
                  this.value = this.selectedPath;
                  this.isOpen = false;
              },
              setCurrentPath: function setCurrentPath(path){
                  this.currentPath = path;
              },
              setSelectedPath: function setSelectedPath(path){
                  this.selectedPath = path;
              },
              isImage: function isImage(path) {
                  return /\.(jpg|png|gif)$/.test(path);
              },
              isValidPath: function isValidPath(path, root){
                  return path && path !== root && path.includes(root)
              },
              browse: function browse() {
                  var this$1 = this;

                  // root path is used to limit top lever directory of path browser
                  var root = this.schema.browserRoot;
                  if(!root) {
                      console.warn('browserRoot not defined in schema. All paths are available.');
                      root = '/';
                  }
                  // browser type is used to limit browsing and show correct file/icon types
                  var type = this.schema.browserType;
                  if(!type) {
                      root === ((this.getBasePath()) + "/pages") ? type = PathBrowser.Type.PAGE : type = PathBrowser.Type.ASSET;
                  }
                  var selectedPath = this.value;
                  // current path is the active directory in the path browser
                  var currentPath;
                  // if a selected path is valid, currentPath becomes the selected path's parent
                  if(this.isValidPath(selectedPath, root)){
                      currentPath = selectedPath.substr(0, selectedPath.lastIndexOf('/'));
                  } else { // if path is invalid
                      currentPath = root;
                  }
                  this.browserRoot = root;
                  this.browserType = type;
                  this.currentPath = currentPath;
                  this.selectedPath = selectedPath;

                  var options = this.schema.browserOptions;
                  if(options && options.withLink){
                      this.withLinkTab = options.withLink;
                  } else {
                      this.withLinkTab = !(type === PathBrowser.Type.IMAGE);
                  }
                  $perAdminApp.getApi().populateNodesForBrowser(currentPath, 'pathBrowser')
                      .then( function () {
                          this$1.isOpen = true;
                      }).catch( function (err) {
                          $perAdminApp.getApi().populateNodesForBrowser('/content', 'pathBrowser');
                      });
              }
          }
      };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      { staticClass: "wrap" },
      [
        !_vm.schema.preview
          ? [
              _c("input", {
                attrs: {
                  id: _vm.getFieldID(_vm.schema),
                  type: "text",
                  disabled: _vm.disabled,
                  maxlength: _vm.schema.max,
                  placeholder: _vm.schema.placeholder,
                  readonly: _vm.schema.readonly
                },
                domProps: { value: _vm.sanitizedValue },
                on: {
                  input: function($event) {
                    _vm.value = $event.target.value;
                  }
                }
              }),
              _vm._v(" "),
              !_vm.schema.readonly
                ? _c(
                    "button",
                    {
                      staticClass: "btn-flat",
                      attrs: { disabled: _vm.disabled },
                      on: {
                        click: function($event) {
                          $event.stopPropagation();
                          $event.preventDefault();
                          return _vm.browse($event)
                        }
                      }
                    },
                    [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v("insert_drive_file")
                      ])
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _vm.isImage(_vm.value)
                ? _c("img", { attrs: { src: _vm.sanitizedValue } })
                : _vm._e(),
              _vm._v(" "),
              _vm.isOpen
                ? _c("admin-components-pathbrowser", {
                    attrs: {
                      isOpen: _vm.isOpen,
                      browserRoot: _vm.browserRoot,
                      browserType: _vm.browserType,
                      currentPath: _vm.currentPath,
                      selectedPath: _vm.selectedPath,
                      withLinkTab: _vm.withLinkTab,
                      setCurrentPath: _vm.setCurrentPath,
                      setSelectedPath: _vm.setSelectedPath,
                      onCancel: _vm.onCancel,
                      onSelect: _vm.onSelect
                    }
                  })
                : _vm._e()
            ]
          : _c("p", [_vm._v(_vm._s(_vm.value))])
      ],
      2
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
