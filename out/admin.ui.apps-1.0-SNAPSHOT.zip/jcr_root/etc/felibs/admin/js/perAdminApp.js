var $perAdminApp = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  var log$1 = LoggerFactory.logger('i18n').setLevelDebug();
  var lang = 'en';

  function keyToLang(original) {
      try {
          var lowOriginal = original.toLowerCase();
          var resources = $perAdminApp.getView().admin.i18n[lang];
          if(resources[original]) {
              return resources[original].text
          } else if (resources[lowOriginal]){
              return resources[lowOriginal].text
          }
          if(lang === 'en') { return original }
          if (log$1.level === LogLevel.FINE) {
              return ("T{" + original + "]")
          } else {
              log$1.warn(("missing translation for: " + original));
              return original
          }
      } catch(error) {
          return original
      }
  }

  function setLang(language) {
      $perAdminApp.getView().admin.i18n[lang] = {};
      lang = language;
      $perAdminApp.getView().state.language = language;
      $perAdminApp.loadi18n();
  }

  function getLang() {
      return lang
  }

  function getLangs() {
      return [ {name: 'en'}, {name: 'de'} ]
  }

  var i18n = {
      install: function install(vue) {
          $perAdminApp.loadi18n();
          vue.prototype.$i18n = keyToLang;
          vue.prototype.$i18nSetLanguage = setLang;
          vue.prototype.$i18nGetLanguage = getLang;
          vue.prototype.$i18nGetLanguages = getLangs;
      }
  };

  var log$2 = LoggerFactory.logger('experiences').setLevelDebug();

  function experience(model, name, defaultValue) {
      var experience = 'lang:'+$perAdminApp.getView().state.language;
      if(model.experiences) {
          for (var i = 0; i < model.experiences.length; i++) {
              var exp = model.experiences[i];
              if(exp.experiences.indexOf(experience) >= 0) {
                  var ret = exp[name];
                  return ret ? ret : ( model[name] ? model[name] : defaultValue)
              }
          }
      }
      if(experience !== 'lang:en' && experience.indexOf('lang:') === 0) {
          if (log$2.level === LogLevel.FINE) {
              return ("T[" + ((model[name] ? model[name] : defaultValue)) + "]")
          } else {
              log$2.warn(("missing translation for: " + ((model[name] ? model[name] : defaultValue))));
              return (model[name] ? model[name] : defaultValue)
          }
      }
      return model[name] ? model[name] : defaultValue

  }

  var experiences = {
      install: function install(vue) {
          vue.prototype.$exp = experience;
      }
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$3 = LoggerFactory.logger('api').setLevelDebug();

  var impl = null;

  var PerApi = function PerApi(implementation) {
      log$3.fine('contructor');
      impl = implementation;
  };

  PerApi.prototype.populateUser = function populateUser () {
      return impl.populateUser()
  };

  PerApi.prototype.populateTools = function populateTools () {
      return impl.populateTools()
  };

  PerApi.prototype.populateToolsConfig = function populateToolsConfig () {
      return impl.populateToolsConfig()
  };

  PerApi.prototype.populateContent = function populateContent (path) {
      return impl.populateContent(path)
  };

  PerApi.prototype.populateComponents = function populateComponents () {
      return impl.populateComponents()
  };

  PerApi.prototype.populateTemplates = function populateTemplates () {
      return impl.populateTemplates()
  };

  PerApi.prototype.populateObjects = function populateObjects () {
      return impl.populateObjects()
  };

  PerApi.prototype.populateSkeletonPages = function populateSkeletonPages (path, target, includeParents) {
          if ( includeParents === void 0 ) includeParents = false;

      return impl.populateSkeletonPages(path, target, includeParents)
  };

  PerApi.prototype.populateNodesForBrowser = function populateNodesForBrowser (path, target, includeParents) {
          if ( includeParents === void 0 ) includeParents = false;

      return impl.populateNodesForBrowser(path, target, includeParents)
  };

  PerApi.prototype.populateComponentDefinitionFor = function populateComponentDefinitionFor (component) {
      return impl.populateComponentDefinitionFor(component)
  };

  PerApi.prototype.populateComponentDefinitionFromNode = function populateComponentDefinitionFromNode (path) {
      return impl.populateComponentDefinitionFromNode(path)
  };

  PerApi.prototype.populateExplorerDialog = function populateExplorerDialog (path) {
      return impl.populateExplorerDialog(path)
  };


  PerApi.prototype.populateObject = function populateObject (path, target, name) {
      return impl.populateObject(path, target, name)
  };

  PerApi.prototype.populatePageView = function populatePageView (path) {
      return impl.populatePageView(path)
  };

  PerApi.prototype.populateReferencedBy = function populateReferencedBy (path) {
      return impl.populateReferencedBy(path)
  };

  PerApi.prototype.populateTenants = function populateTenants () {
      return impl.populateTenants()
  };

  PerApi.prototype.populateBackupInfo = function populateBackupInfo (backup) {
      return impl.populateBackupInfo(backup)
  };

  PerApi.prototype.populateRecyclebin = function populateRecyclebin (page) {
      return impl.populateRecyclebin(page)
  };

  PerApi.prototype.populateVersions = function populateVersions (page) {
      return impl.populateVersions(page)
  };

  PerApi.prototype.setInitialPageEditorState = function setInitialPageEditorState (path) {
      return impl.setInitialPageEditorState(path)
  };

  PerApi.prototype.populateByName = function populateByName (name) {
      if (name === '/admin/tools') { return this.populateTools() }
      if (name === '/admin/toolsConfig') { return this.populateToolsConfig() }
      if (name === '/admin/components') { return this.populateComponents() }
      return Promise.reject('populateByName for ' + name + ' is not defined')
  };

  PerApi.prototype.populateI18N = function populateI18N (language) {
      return impl.populateI18N(language)
  };

  PerApi.prototype.createTenant = function createTenant (fromName, toName, title, tenantUserPwd, colorPalette) {
      return impl.createTenant(fromName, toName, title, tenantUserPwd, colorPalette)
  };

  PerApi.prototype.createPage = function createPage (parentPath, name, templatePath, title) {
      return impl.createPage(parentPath, name, templatePath, title)
  };

  PerApi.prototype.createPageFromSkeletonPage = function createPageFromSkeletonPage (parentPath, name, skeletonPagePath) {
      return impl.createPageFromSkeletonPage(parentPath, name, skeletonPagePath)
  };

  PerApi.prototype.deletePage = function deletePage (path) {
      return impl.deletePage(path)
  };

  PerApi.prototype.deleteTenant = function deleteTenant (name, path) {
      return impl.deleteTenant(name, path)
  };

  PerApi.prototype.renamePage = function renamePage (path, newName, newTitle) {
      return impl.renamePage(path, newName, newTitle)
  };

  PerApi.prototype.movePage = function movePage (path, to, type) {
      return impl.movePage(path, to, type)
  };

  PerApi.prototype.deletePageNode = function deletePageNode (path, nodePath) {
      return impl.deletePageNode(path, nodePath)
  };

  PerApi.prototype.createTemplate = function createTemplate (parentPath, name, component, title) {
      return impl.createTemplate(parentPath, name, component, title)
  };

  PerApi.prototype.moveTemplate = function moveTemplate (path, to, type) {
      return impl.moveTemplate(path, to, type)
  };

  PerApi.prototype.deleteTemplate = function deleteTemplate (path) {
      return impl.deleteTemplate(path)
  };

  PerApi.prototype.createObject = function createObject (parentPath, name, templatePath) {
      return impl.createObject(parentPath, name, templatePath)
  };

  PerApi.prototype.deleteObject = function deleteObject (path) {
      return impl.deleteObject(path)
  };

  PerApi.prototype.renameObject = function renameObject (path, newName) {
      return impl.renameObject(path, newName)
  };

  PerApi.prototype.deleteAsset = function deleteAsset (path) {
      return impl.deleteAsset(path)
  };

  PerApi.prototype.renameAsset = function renameAsset (path, newName, newTitle) {
      return impl.renameAsset(path, newName, newTitle)
  };

  PerApi.prototype.moveAsset = function moveAsset (path, to, type) {
      return impl.moveAsset(path, to, type)
  };

  PerApi.prototype.createFolder = function createFolder (parentPath, name) {
      return impl.createFolder(parentPath, name)
  };

  PerApi.prototype.deleteFolder = function deleteFolder (parentPath, name) {
      return impl.deleteFolder(parentPath, name)
  };

  PerApi.prototype.deleteFile = function deleteFile (path, name) {
      return impl.deleteFile(path, name)
  };

  PerApi.prototype.uploadFiles = function uploadFiles (path, files, cb) {
      return impl.uploadFiles(path, files, cb)
  };

  PerApi.prototype.recycleItem = function recycleItem (recyclebinItemPath) {
      return impl.recycleItem(recyclebinItemPath)
  };

  PerApi.prototype.deleteRecyclable = function deleteRecyclable (path) {
      return impl.deleteRecyclable(path)
  };

  PerApi.prototype.createVersion = function createVersion (path) {
      return impl.createVersion(path)
  };

  PerApi.prototype.deleteVersion = function deleteVersion (version) {
      return impl.deleteVersion(version)
  };

  PerApi.prototype.restoreVersion = function restoreVersion (path, versionName) {
      return impl.restoreVersion(path, versionName)
  };

  PerApi.prototype.nameAvailable = function nameAvailable (value, path) {
      return impl.nameAvailable(value, path)
  };

  PerApi.prototype.fetchExternalImage = function fetchExternalImage (path, url, name, config) {
      return impl.fetchExternalImage(path, url, name, config)
  };

  PerApi.prototype.savePageEdit = function savePageEdit (path, node) {
      return impl.savePageEdit(path, node)
  };

  PerApi.prototype.saveObjectEdit = function saveObjectEdit (path, node) {
      return impl.saveObjectEdit(path, node)
  };

  PerApi.prototype.saveAssetProperties = function saveAssetProperties (node) {
      return impl.saveAssetProperties(node)
  };

  PerApi.prototype.insertNodeAt = function insertNodeAt (path, component, drop, variation) {
      return impl.insertNodeAt(path, component, drop, variation)
  };

  PerApi.prototype.insertNodeWithDataAt = function insertNodeWithDataAt (path, data, drop) {
      return impl.insertNodeWithDataAt(path, data, drop)
  };

  PerApi.prototype.moveNodeTo = function moveNodeTo (path, component, drop) {
      return impl.moveNodeTo(path, component, drop)
  };

  PerApi.prototype.replicate = function replicate (path) {
      return impl.replicate(path)
  };

  PerApi.prototype.getPalettes = function getPalettes (templateName) {
      return impl.getPalettes(templateName)
  };

  PerApi.prototype.tenantSetupReplication = function tenantSetupReplication (path, withSite) {
      return impl.tenantSetupReplication(path, withSite)
  };

  PerApi.prototype.backupTenant = function backupTenant (path) {
      return impl.backupTenant(path)
  };

  PerApi.prototype.downloadBackupTenant = function downloadBackupTenant (path) {
      return impl.downloadBackupTenant(path)
  };

  PerApi.prototype.uploadBackupTenant = function uploadBackupTenant (path, files, cb) {
      return impl.uploadBackupTenant(path, files, cb)
  };

  PerApi.prototype.restoreTenant = function restoreTenant (path) {
      return impl.restoreTenant(path)
  };

  PerApi.prototype.fetchRecyclables = function fetchRecyclables (siteName) {
      return impl.fetchRecyclables(siteName)
  };

  PerApi.prototype.acceptTermsAndConditions = function acceptTermsAndConditions () {
      return impl.acceptTermsAndConditions()
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var DATA_EXTENSION = '.data.json';

  var SUFFIX_PARAM_SEPARATOR = ':';

  var EditorTypes = {
    TEMPLATE: 'template-editor',
    PAGE: 'page-editor'
  };
  var IgnoreContainers = {
    ENABLED: 'ignore-containers',
    ON_HOLD: 'on-hold',
    DISABLED: ''
  };
  var Field = {
    SWITCH: 'materialswitch',
    SELECT: 'material-select',
    MULTI_SELECT: 'material-multiselect'
  };

  var Admin = {
    Page: {
      EDIT: '/content/admin/pages/pages/edit.html',
      PAGES: '/content/admin/pages/pages.html'
    }
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function makePathInfo(path) {

      logger.fine('makePathInfo for path', path);
      var htmlPos = path.indexOf('.html');
      var pathPart = path;
      var suffixPath = '';
      if(htmlPos >= 0) {
          suffixPath = path.slice(htmlPos);
          pathPart = path.slice(0, htmlPos+5);
      }

      var suffixParams = {};
      if(suffixPath.length > 0) {
          suffixPath = suffixPath.slice(6);
          var suffixParamList = suffixPath.split(SUFFIX_PARAM_SEPARATOR);
          for(var i = 0; i < suffixParamList.length; i+= 2) {
              suffixParams[suffixParamList[i]] = suffixParamList[i+1];
          }
      }

      var ret = { path: pathPart, suffix: suffixPath , suffixParams: suffixParams };
      logger.fine('makePathInfo res:',ret);
      return ret
  }

  function pagePathToDataPath(path) {

      logger.fine('converting',path,'to dataPath');
      var firstHtmlExt = path.indexOf('.html');
      var res = null;
      if(firstHtmlExt >= 0) {
          var pathNoExt = path.substring(0,firstHtmlExt);
          res = pathNoExt + DATA_EXTENSION;
      }
      else {
          res = path + DATA_EXTENSION;
      }
      logger.fine('result',res);
      return res

  }

  function set(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(vue) {
          Vue.set(node, path[0], value);
      }
      else {
          node[path[0]] = value;
      }
  }

  function get(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(value !== undefined && !node[path[0]]) {
          if(vue) {
              Vue.set(node, path[0], value);
          } else {
              node[path[0]] = value;
          }
      }
      return node[path[0]]
  }

  function parentPath(path) {
      logger.fine('parentPath()',path);
      var segments = path.split('/');
      var name = segments.pop();
      var parentPath = segments.join('/');
      var ret ={ parentPath: parentPath, name: name };
      logger.fine('parentPath() res:',ret);
      return ret
  }

  function stripNulls(data) {
      for(var key in data) {
          if(data[key] === null) { delete data[key]; }
          if(typeof data[key] === 'object') {
              stripNulls(data[key]);
          }
      }
  }

  function jsonEqualizer(name, value) {
      if(value === null || value === undefined || value.length === 0) {
          return undefined
      }
      return value
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger$1 = LoggerFactory.logger('apiImpl').setLevelDebug();

  var API_BASE = '/perapi';
  var postConfig = {
    withCredentials: true
  };

  var callbacks;

  function json(data) {
    var content = JSON.stringify(data);
    return new Blob([content], {type: 'application/json; charset=utf-8'})
  }

  function fetch(path) {
    logger$1.fine('Fetch ', path);
    return axios.get(API_BASE + path).then(function (response) {
      return new Promise(function (resolve, reject) {

        // Fix for IE11
        if ((typeof response.data === 'string' && response.data.startsWith(
            '<!DOCTYPE')) || (response.request && response.request.responseURL
            && response.request.responseURL.indexOf('/system/sling/form/login')
            >= 0)) {
          window.location = '/system/sling/form/login';
          reject('need to authenticate');
        }
        resolve(response.data);
      })
    }).catch(function (error) {
      logger$1.error('Fetch request to', path, 'failed');
      throw error
    })

  }

  function updateWithForm(path, data) {
    logger$1.fine('Update with Form, path: ' + path + ', data: ' + data);
    return axios.post(API_BASE + path, data, postConfig)
        .then(function (response) { return response.data; })
        .catch(function (error) {
          logger$1.error('Update with Form request to', path, 'failed');
          throw error
        })
  }

  function updateWithFormAndConfig(path, data, config) {
    //AS TODO: How to merge config into postConfig or the other way around?
    // config.withCredentials: true
    logger$1.fine('Update with Form and Config, path: ' + path + ', data: ' + data);
    return axios.post(API_BASE + path, data, config)
        .then(function (response) {
          logger$1.fine(
              'Update with Form and Config, response data: ' + response.data);
          return response.data
        })
        .catch(function (error) {
          logger$1.error('Update with Form and Config request to',
              error.response.request.path, 'failed');
          throw error
        })
  }

  function getOrCreate(obj, path) {

    if (path === '/') ; else {
      var segments = path.split('/').slice(1).reverse();

      while (segments.length > 0) {
        var segment = segments.pop();
        if (!obj[segment]) {
          Vue.set(obj, segment, {});
  //                obj[segment] = {}
        }
        obj = obj[segment];
      }
    }

    return obj
  }

  function populateView(path, name, data) {

    return new Promise(function (resolve) {
      var obj = getOrCreate(callbacks.getView(), path);
      var vue = callbacks.getApp();
      if (vue && path !== '/') {
        Vue.set(obj, name, data);
      } else {
        obj[name] = data;
      }
      resolve();
    })

  }

  // function updateExplorerDialog() {
  //   const view = callbacks.getView()
  //   const page = get(view, '/state/tools/page', '')
  //   const template = get(view, '/state/tools/template', '')
  //   if (page) {
  //     $perAdminApp.stateAction('showPageInfo', {selected: page})
  //   }
  //   if (template) {
  //     $perAdminApp.stateAction('showPageInfo', {selected: template})
  //   }
  // }

  function translateFields(fields) {
    var $i18n = Vue.prototype.$i18n;
    if(!$i18n) { return fields }
    if (!fields || fields.length <= 0) {
      return
    }
    for (var i = 0; i < fields.length; i++) {
      var field = fields[i];
      if (field) {
        if (field.label) {
          var label = field.label.split(':').join('..');
          fields[i].label = $i18n(label);
        }
        if (field.placeholder) {
          var placeholder = field.placeholder.split(':').join('..');
          fields[i].placeholder = $i18n(placeholder);
        }
        if (field.hint) {
          var split = field.hint.split('. ');
          if (split.length <= 1) {
            fields[i].hint = $i18n(field.hint);
          } else {
            for (var j = 0; j < split.length; j++) {
              var item = split[j];
              if (item.length > 0) {
                split[j] = $i18n(item);
              }
            }
            fields[i].hint = split.join('. ');
          }
        }
        if (field.type === Field.SWITCH) {
          fields[i].textOn = $i18n(field.textOn);
          fields[i].textOff = $i18n(field.textOff);
        } else if (field.type === Field.SELECT) {
          var values = fields[i].values;
          for (var j$1 = 0; j$1 < values.length; j$1++) {
            var name = values[j$1].name;
            var t = $i18n(name);
            fields[i].values[j$1].name = t.startsWith('T[') ? name : t;
          }
        } else if (field.type === Field.MULTI_SELECT) {
          if (field.selectOptions.placeholder) {
            var placeholder$1 = field.selectOptions.placeholder;
            field.selectOptions.placeholder = $i18n(placeholder$1);
          }
        }
      }
    }
  }

  var PerAdminImpl = function PerAdminImpl(cb) {
    callbacks = cb;
  };

  PerAdminImpl.prototype.populateTools = function populateTools () {
    return fetch('/admin/list.json/tools')
        .then(function (data) { return populateView('/admin', 'tools', data.children); })
        .catch(function (error) {
          logger$1.error('call populateTools() failed');
          return error
        })
  };

  PerAdminImpl.prototype.populateToolsConfig = function populateToolsConfig () {
    return fetch('/admin/list.json/tools/config')
        .then(function (data) { return populateView('/admin', 'toolsConfig', data.children); })
  };

  PerAdminImpl.prototype.populateUser = function populateUser () {
    return fetch('/admin/access.json?' + (new Date()).getTime())
        .then(function (data) {
          return populateView('/state', 'user', data.userID).then(function () {
            if (data.userID === 'anonymous') {
              // alert('please login to continue')
              window.location = '/';
            }
            return populateView('/state', 'userPreferences', data.preferences)
          })
        })
  };

  PerAdminImpl.prototype.populateContent = function populateContent (path) {
    return fetch('/admin/content.json' + path)
        .then(function (data) { return populateView('/', 'adminPageStaged', data); })
  };

  PerAdminImpl.prototype.populateComponents = function populateComponents () {
    return fetch('/admin/components.json')
        .then(function (data) { return populateView('/admin', 'components', data); })
  };

  PerAdminImpl.prototype.populateObjects = function populateObjects () {
    return fetch('/admin/objects.json')
        .then(function (data) { return populateView('/admin', 'objects', data); })
  };

  PerAdminImpl.prototype.populateTemplates = function populateTemplates () {
    return fetch('/admin/templates.json')
        .then(function (data) { return populateView('/admin', 'templates', data); })
  };

  PerAdminImpl.prototype.populateSkeletonPages = function populateSkeletonPages (path, target,
      includeParents) {
      if ( target === void 0 ) target = 'skeletonNodes';
      if ( includeParents === void 0 ) includeParents = false;

    var skeletonPagePath = path.split('/').slice(0, 4).join('/')
        + '/skeleton-pages';

    // try {
    // if (get(skeletonPagePath, null)) {
    //   this.populateContent(skeletonPagePath)
    // }
    // } catch(err) {}

    return this.populateNodesForBrowser(skeletonPagePath, target,
        includeParents)
  };

  PerAdminImpl.prototype.populateNodesForBrowser = function populateNodesForBrowser (path, target, includeParents) {
      if ( target === void 0 ) target = 'nodes';
      if ( includeParents === void 0 ) includeParents = false;

    return fetch(
        '/admin/nodes.json' + path + '?includeParents=' + includeParents)
        .then(function (data) { return populateView('/admin', target, data); })
  };

  PerAdminImpl.prototype.populateComponentDefinitionFor = function populateComponentDefinitionFor (component) {
    return fetch('/admin/components/' + component)
        .then(function (data) { return populateView('/admin/componentDefinitions', component,
            data); })
  };

  PerAdminImpl.prototype.populateComponentDefinitionFromNode = function populateComponentDefinitionFromNode (path) {
    return new Promise(function (resolve, reject) {
      var name;
      fetch('/admin/componentDefinition.json' + path)
          .then(function (data) {
            name = data.name;
            var component = callbacks.getComponentByName(name);
            if (component && component.methods
                && component.methods.augmentEditorSchema) {
              data.model = component.methods.augmentEditorSchema(data.model);
              data.ogTags = component.methods.augmentEditorSchema(data.ogTags);
            }

            var promises = [];
            if (data && data.model) {
              if (data.model.groups) {
                var loop = function ( j ) {
                  var loop$1 = function ( i ) {
                    var from = data.model.groups[j].fields[i].valuesFrom;
                    if (from) {
                      data.model.groups[j].fields[i].values = [];
                      var promise = axios.get(from).then(function (response) {
                        for (var key in response.data) {
                          if (response.data[key]['jcr:title']) {
                            var nodeName = key;
                            var val = from.replace('.infinity.json',
                                '/' + nodeName);
                            var name = response.data[key].name;
                            if (!name) {
                              name = response.data[key]['jcr:title'];
                            }
                            data.model.groups[j].fields[i].values.push(
                                {value: val, name: name});
                          }
                        }
                      }).catch(function (error) {
                        logger$1.error('missing node',
                            data.model.groups[j].fields[i].valuesFrom,
                            'for list population in dialog', error);
                      });
                      promises.push(promise);
                    }
                    var visible = data.model.groups[j].fields[i].visible;
                    if (visible) {
                      data.model.groups[j].fields[i].visible = function (model) {
                        return exprEval.Parser.evaluate(visible, this);
                      };
                    }
                  };

                    for (var i = 0; i < data.model.groups[j].fields.length; i++) loop$1( i );
                };

                  for (var j = 0; j < data.model.groups.length; j++) loop( j );
              } else {
                var loop$2 = function ( i ) {
                  var from$1 = data.model.fields[i].valuesFrom;
                  if (from$1) {
                    data.model.fields[i].values = [];
                    var promise$1 = axios.get(from$1).then(function (response) {
                      var toProcess = [];
                      for (var key in response.data) {
                        toProcess.push({key: key, data: response.data[key]});
                      }

                      var next = toProcess.shift();
                      while (next) {
                        if (next.data['jcr:title']) {
                          var nodeName = next.key;
                          var val = next.data.path ? next.data.path + '/'
                              + nodeName
                              : from$1.replace('.infinity.json', '/' + nodeName);
                          var name = next.data.name;
                          if (!name) {
                            name = next.data['jcr:title'];
                          }
                          if (next.parent) {
                            name = next.parent + '-' + name;
                          }
                          data.model.fields[i].values.push(
                              {value: val, name: name});
                          for (var k in next.data) {
                            if (next.data[k] instanceof Object
                                && next.data[k]['sling:resourceType']
                                === 'admin/objects/tag') {
                              toProcess.push(
                                  {key: k, parent: name, data: next.data[k]});
                            }
                          }
                        }
                        next = toProcess.shift();
                      }

                    }).catch(function (error) {
                      logger$1.error('missing node',
                          data.model.fields[i].valuesFrom,
                          'for list population in dialog', error);
                    });
                    promises.push(promise$1);
                  }
                  var visible$1 = data.model.fields[i].visible;
                  if (visible$1) {
                    data.model.fields[i].visible = function (model) {
                      return exprEval.Parser.evaluate(visible$1, this);
                    };
                  }
                };

                  for (var i$1 = 0; i$1 < data.model.fields.length; i$1++) loop$2( i$1 );
                if (data.ogTags) {
                  var loop$3 = function ( i ) {
                    var from$2 = data.ogTags.fields[i].valuesFrom;
                    if (from$2) {
                      data.ogTags.fields[i].values = [];
                      var promise$2 = axios.get(from$2).then(function (response) {
                        for (var key in response.data) {
                          if (response.data[key]['jcr:title']) {
                            var nodeName = key;
                            var val = from$2.replace('.infinity.json',
                                '/' + nodeName);
                            var name = response.data[key].name;
                            if (!name) {
                              name = response.data[key]['jcr:title'];
                            }
                            data.ogTags.fields[i].values.push(
                                {value: val, name: name});
                          }
                        }
                      }).catch(function (error) {
                        logger$1.error('missing node',
                            data.ogTags.fields[i].valuesFrom,
                            'for list population in dialog', error);
                      });
                      promises.push(promise$2);
                    }
                    var visible$2 = data.ogTags.fields[i].visible;
                    if (visible$2) {
                      data.ogTags.fields[i].visible = function (ogTags) {
                        return exprEval.Parser.evaluate(visible$2, this);
                      };
                    }
                  };

                    for (var i$2 = 0; i$2 < data.ogTags.fields.length; i$2++) loop$3( i$2 );
                  translateFields(data.ogTags.fields);
                }
                translateFields(data.model.fields);
              }
            } else {
              logger$1.warn(("no dialog.json file given for component \"" + name + "\""));
            }

            Promise.all(promises).then(function () {
              populateView('/admin/componentDefinitions', data.name, data);
              resolve(name);
            });
          });
    }).catch(function (error) {
      reject(error);
    })
  };

  PerAdminImpl.prototype.populateExplorerDialog = function populateExplorerDialog (path) {
    return this.populateComponentDefinitionFromNode(path)
  };

  PerAdminImpl.prototype.populateTenants = function populateTenants () {
    return new Promise(function (resolve, reject) {
      fetch('/admin/listTenants.json')
          .then(function (data) {
            // const state = callbacks.getView().state
            // if (!state.tenant && data.tenants.length > 0) {
            // $perAdminApp.stateAction('setTenant',
            //     data.tenants[data.tenants.length - 1])
            //     .then(() => populateView('/admin', 'tenants', data.tenants))
            //     .then(() => resolve())
            // } else {
              populateView('/admin', 'tenants', data.tenants)
                  .then(function () { return resolve(); });
            // }
          });
    })
  };

  PerAdminImpl.prototype.populateBackupInfo = function populateBackupInfo (backup) {
    var tenantName = backup ? backup.tenant : '';
    if(tenantName === '' || tenantName === 'undefined') {
      var tenant = $perAdminApp.getNodeFromViewWithDefault("/state/tenant", {});
      tenantName = tenant ? tenant.name : '';
    }
    fetch('/admin/backupTenant.json/content/' + tenantName)
        .then(function (data) { return populateView('/state/tools', 'backup', data); });
  };

  PerAdminImpl.prototype.populatePageView = function populatePageView (path) {
    return fetch('/admin/readNode.json' + path)
        .then(function (data) { return populateView('/pageView', 'page', data); })
  };


  PerAdminImpl.prototype.populateObject = function populateObject (path, target, name) {
    return this.populateComponentDefinitionFromNode(path)
        .then(function () {
          return fetch('/admin/getObject.json' + path)
              .then(function (data) { return populateView(target, name, data); })
        })
  };

  PerAdminImpl.prototype.populateReferencedBy = function populateReferencedBy (path) {
    return fetch('/admin/refBy.json' + path)
        .then(function (data) { return populateView('/state', 'referencedBy', data); })
  };

  PerAdminImpl.prototype.populateI18N = function populateI18N (language) {
    return new Promise(function (resolve, reject) {
      axios.get('/i18n/admin/' + language + '.infinity.json')
          .then(function (response) {
            populateView('/admin/i18n', language, response.data)
                .then(function () { return resolve(); });
          });
    })
  };


  PerAdminImpl.prototype.populateRecyclebin = function populateRecyclebin (page) {
      if ( page === void 0 ) page = 0;

    var tenant = getOrCreate(callbacks.getView(), '/state/tenant').name;
    if (tenant == undefined) {
        tenant = callbacks.getView().state.tenant.name;
    }
    if (page instanceof Object) {
        page = 0;
    }
    return new Promise(function (resolve, reject) {
        fetch(("/admin/listRecyclables.json/content/" + tenant + "?page=" + page))
            .then(function(result) {
                 populateView('/admin', 'recyclebin', result)
                    .then(function () { return resolve(); });
            })
            .catch(function (error) {
                $perAdminApp.notifyUser('error', (error + ". Unable to load Recycle Bin"));
            });
    })
  };

  PerAdminImpl.prototype.populateVersions = function populateVersions (page) {
    if (page) {
        return new Promise(function (resolve, reject) {
          fetch(("/admin/listVersions.json" + page))
            .then(function(result) {
                populateView('/state', 'versions', result)
                    .then(function () { return resolve(); });
            })
            .catch(function (error) {
                if (error.response && error.response.data && error.response.data.message) {
                    reject(error.response.data.message);
                }
            });
        })
    }
  };

  PerAdminImpl.prototype.recycleItem = function recycleItem (item) {
      return new Promise(function (resolve, reject) {
        var data = new FormData();
        updateWithForm('/admin/restoreRecyclable.json' + item.recyclebinItemPath, data)
            .then( function (data) { return callbacks.getApi().populateRecyclebin(0); } )
            .then(function () { return resolve(); })
            .catch(function (error) {
                if (error.response && error.response.data && error.response.data.message) {
                    reject(error.response.data.message);
                }
                reject(error);
            });
      })
  };

  PerAdminImpl.prototype.deleteRecyclable = function deleteRecyclable (path) {
        return new Promise(function (resolve, reject) {
            var data = new FormData();
            updateWithForm('/admin/deleteNode.json' + path, data)
                .then( function (data) { return callbacks.getApi().populateRecyclebin(0); })
                .then(function () { return resolve(); })
                .catch(function (error) {
                    if (error.response && error.response.data && error.response.data.message) {
                        reject(error.response.data.message);
                    }
                    reject(error);
                });
        })
  };

  PerAdminImpl.prototype.deleteVersion = function deleteVersion (info) {
        return new Promise(function (resolve, reject) {
            var data = new FormData();
            data.append('action', 'deleteVersion');
            data.append('version', info.version);
            updateWithForm('/admin/manageVersions.json' + info.path, data)
                .then( function (data) { return callbacks.getApi().populateVersions(info.path); })
                .then(function () { return resolve(); })
                .catch(function (error) {
                    if (error.response && error.response.data && error.response.data.message) {
                        reject(error.response.data.message);
                    }
                    reject(error);
                });
        })
  };

  PerAdminImpl.prototype.createVersion = function createVersion (path) {
      return new Promise(function (resolve, reject) {
          var data = new FormData();
          data.append('action', 'createVersion');
          updateWithForm('/admin/manageVersions.json' + path, data)
              .then( function (data) { return callbacks.getApi().populateVersions(path); })
              .then(function () { return resolve(); })
              .catch(function (error) {
                  if (error.response && error.response.data && error.response.data.message) {
                      reject(error.response.data.message);
                  }
                  reject(error);
              });
      })
  };

  PerAdminImpl.prototype.restoreVersion = function restoreVersion (path, versionName) {
        return new Promise(function (resolve, reject) {
            var data = new FormData();
            data.append('action', 'restoreVersion');
            data.append('version', versionName);
            updateWithForm('/admin/manageVersions.json' + path, data)
                .then( function (data) { return callbacks.getApi().populateVersions(path); })
                .then( function(){
                    if (path.includes("/assets/")) {
                        $perAdminApp.loadContent("/content/admin/pages/assets");
                    } else {
                         callbacks.getApi().populatePageView(path)
                            .then(function(){
                                var editView = document.getElementById('editview');
                                if (editView) {
                                    editView.contentWindow.$peregrineApp.loadContent(path+ '.html');
                                }
                            })
                            .then(function(){
                                var nodes = '';
                                var pagesRgx = new RegExp('^\/content\/[^\/]+\/pages\/');
                                var templatesRgx = new RegExp('^\/content\/[^\/]+\/templates\/');
                                if (pagesRgx.test(path)) {
                                    nodes = $perAdminApp.getView().state.tools.pages;
                                } else if (templatesRgx.test(path)){
                                    nodes = $perAdminApp.getView().state.tools.templates;
                                }
                                if (nodes != '') {
                                    $perAdminApp.getApi().populateNodesForBrowser(nodes);
                                }
                            });
                    }
                })
                .then( function () { return resolve(); })
                .catch(function (error) {
                    if (error.response && error.response.data && error.response.data.message) {
                        reject(error.response.data.message);
                    } else {
                        reject(error);
                    }
                });
        })
  };

  PerAdminImpl.prototype.createTenant = function createTenant (fromName, toName, tenantTitle, tenantUserPwd, colorPalette) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('fromTenant', fromName);
      data.append('toTenant', toName);
      data.append('tenantTitle', tenantTitle);
      data.append('tenantUserPwd', tenantUserPwd);
      if (colorPalette) {
        data.append('colorPalette', colorPalette);
      }
      updateWithForm('/admin/createTenant.json', data)
          .then(function (data) { return this$1.populateNodesForBrowser(
              callbacks.getView().state.tools.pages); })
          .then(function () { return resolve(); })
          .catch(function (error) {
              if (error.response && error.response.data && error.response.data.message) {
                  reject(error.response.data.message);
              }
              reject(error);
            });
    })
  };

  PerAdminImpl.prototype.createPage = function createPage (parentPath, name, templatePath, title) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('name', name);
      data.append('templatePath', templatePath);
      data.append('title', title);
      updateWithForm('/admin/createPage.json' + parentPath, data)
          .then(function (data) {
            if (parentPath.indexOf('skeleton-pages') > -1) {
              this$1.populateSkeletonPages(parentPath);
            }
            this$1.populateNodesForBrowser(parentPath);
          })
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.createPageFromSkeletonPage = function createPageFromSkeletonPage (parentPath, name, skeletonPagePath) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('path', skeletonPagePath);
      data.append('to', parentPath);
      data.append('deep', 'true');
      data.append('newName', name);
      data.append('newTitle', name);
      data.append('type', 'child');
      updateWithForm('/admin/createPageFromSkeletonPage.json', data)
          .then(function (data) { return this$1.populateNodesForBrowser(parentPath); })
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.createObject = function createObject (parentPath, name, templatePath) {
      var this$1 = this;

    var data = new FormData();
    data.append('name', name);
    data.append('templatePath', templatePath);
    return updateWithForm('/admin/createObject.json' + parentPath, data)
        .then(function () { return this$1.populateNodesForBrowser(parentPath); })
  };

  PerAdminImpl.prototype.deleteObject = function deleteObject (path) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deleteNode.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.deleteAsset = function deleteAsset (path) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deleteNode.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.renameAsset = function renameAsset (path, newName, newTitle) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('to', newName);
      data.append('title', newTitle);
      updateWithForm('/admin/asset/rename.json' + path, data)
          .then(function (data) { return this$1.populateNodesForBrowser(path); })
          .then(function () { return resolve(); })
          .catch(function (error) {
              logger$1.error('Failed to change name: ' + error);
              reject('Unable to change name. ' + error);
          });
    })
  };

  PerAdminImpl.prototype.moveAsset = function moveAsset (path, to, type) {
      var this$1 = this;

    var data = new FormData();
    data.append('to', to);
    data.append('type', type);
    return updateWithForm('/admin/move.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.moveObject = function moveObject (path, to, type) {
      var this$1 = this;

    var data = new FormData();
    data.append('to', to);
    data.append('type', type);
    return updateWithForm('/admin/move.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.renameObject = function renameObject (path, newName) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('to', newName);
      updateWithForm('/admin/object/rename.json' + path, data)
          .then(function (data) { return this$1.populateNodesForBrowser(path); })
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.deletePage = function deletePage (path) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deletePage.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.deleteTenant = function deleteTenant (target) {
      var this$1 = this;

    var name = target.name;
    var root = '/content';
    var data = new FormData();
    data.append('name', name);
    return updateWithForm('/admin/deleteTenant.json', data)
        .then(function () { return this$1.populateNodesForBrowser(root); })
  };

  PerAdminImpl.prototype.renamePage = function renamePage (path, newName, newTitle) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('to', newName);
      data.append('title', newTitle);
      updateWithForm('/admin/page/rename.json' + path, data)
          .then(function (data) { return this$1.populateNodesForBrowser(path); })
          .then(function () { return resolve(); })
          .catch(function (error) {
              logger$1.error('Failed to change name: ' + error);
              reject('Unable to change name. ' + error);
          });
    })
  };

  PerAdminImpl.prototype.movePage = function movePage (path, to, type) {
      var this$1 = this;

    var data = new FormData();
    data.append('to', to);
    data.append('type', type);
    return updateWithForm('/admin/move.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.deletePageNode = function deletePageNode (path, nodePath) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deleteNode.json' + nodePath, data)
        .then(function () { return this$1.populatePageView(path); })
  };

  PerAdminImpl.prototype.createTemplate = function createTemplate (parentPath, name, component, title) {
      var this$1 = this;

    var data = new FormData();
    data.append('name', name);
    data.append('component', component);
    data.append('title', title);
    return updateWithForm('/admin/createTemplate.json' + parentPath, data)
        .then(function () { return this$1.populateNodesForBrowser(parentPath); })
  };

  PerAdminImpl.prototype.moveTemplate = function moveTemplate (path, to, type) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      data.append('to', to);
      data.append('type', type);
      updateWithForm('/admin/move.json' + path, data)
          .then(function (data) { return this$1.populateNodesForBrowser(path); })
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.deleteTemplate = function deleteTemplate (path) {
      var this$1 = this;

    return new Promise(function (resolve, reject) {
      var data = new FormData();
      updateWithForm('/admin/deleteNode.json' + path, data)
          .then(function (data) { return this$1.populateNodesForBrowser(path); })
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.createFolder = function createFolder (parentPath, name) {
      var this$1 = this;

    var data = new FormData();
    data.append('name', name);
    return updateWithForm('/admin/createFolder.json' + parentPath, data)
        .then(function () { return this$1.populateNodesForBrowser(parentPath); })
  };

  PerAdminImpl.prototype.deleteFolder = function deleteFolder (path) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deleteNode.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.deleteFile = function deleteFile (path) {
      var this$1 = this;

    var data = new FormData();
    return updateWithForm('/admin/deleteNode.json' + path, data)
        .then(function () { return this$1.populateNodesForBrowser(path); })
  };

  PerAdminImpl.prototype.uploadFiles = function uploadFiles (path, files, cb) {
      var this$1 = this;

    var config = {
      onUploadProgress: function (progressEvent) {
        var percentCompleted = Math.floor(
            (progressEvent.loaded * 100) / progressEvent.total);
        cb(percentCompleted);
      }
    };
    var data = new FormData();
    var fileNamesNotUploaded = [];
    var loop = function ( i ) {
      var file = files[i];
      var available = this$1.nameAvailable(file.name, path);
      if (available) {
        data.append(file.name, file, file.name);
      } else {
        if (files.length == 1) {
          // if user is uploading 1 assets && name not available,
          // Then ask user whether to 'keep both' or 'replace'
          $perAdminApp.askUser('File exists',
              'Select to replace the existing one, or keep both', {
                yesText: 'Replace',
                noText: 'Keep both',
                yes: function yes() {
                  var $api = $perAdminApp.getApi();
                  logger$1.info(
                      'user selected \'replace\' upload file ' + file.name);
                  var replaceData = new FormData();
                  replaceData.append(file.name, file, file.name);
                  return updateWithFormAndConfig(
                      '/admin/uploadFiles.json' + path, replaceData, config)
                      .then(function () { return $api.populateNodesForBrowser(path); })
                      .catch(function (error) {
                        log.error('Failed to upload: ' + error);
                        reject('Unable to upload due to an error. ' + error);
                      })
                },
                no: function no() {
                  logger$1.info(
                      'user selected \'keep both\' make the uploaded file name unique and upload');
                  var $api = $perAdminApp.getApi();
                  var localNamePart = file.name;
                  var extensionPart = '';
                  var indexOfLasDot = file.name.lastIndexOf('.');
                  var newFileName;
                  if (indexOfLasDot > 0) {
                    // filename has a dot
                    localNamePart = file.name.substring(0, indexOfLasDot);
                    extensionPart = file.name.substring(indexOfLasDot,
                        file.name.length);
                  }
                  var i = 1;
                  do {
                    newFileName = localNamePart + i++ + extensionPart;
                  } while (!$api.nameAvailable(newFileName, path));
                  var keepbothData = new FormData();
                  keepbothData.append(newFileName, file, newFileName);
                  return updateWithFormAndConfig(
                      '/admin/uploadFiles.json' + path, keepbothData, config)
                      .then(function () { return $api.populateNodesForBrowser(path); })
                      .catch(function (error) {
                        log.error('Failed to upload: ' + error);
                        reject('Unable to upload due to an error. ' + error);
                      })
                }
              });
        } else {
          fileNamesNotUploaded.push(file.name);
        }
      }
    };

      for (var i = 0; i < files.length; i++) loop( i );
    if (fileNamesNotUploaded.length > 0) {
      $perAdminApp.notifyUser('Info',
          'Some assets were not uploaded. Asset exists in this location: ' +
          fileNamesNotUploaded.toString());
    }
  //  if there are eny entries
    if (!data.entries().next().done) {
      return updateWithFormAndConfig('/admin/uploadFiles.json' + path, data,
          config)
          .then(function () { return this$1.populateNodesForBrowser(path); })
          .catch(function (error) {
            log.error('Failed to upload: ' + error);
            reject('Unable to upload due to an error. ' + error);
          })
    }
    return
  };

  PerAdminImpl.prototype.nameAvailable = function nameAvailable (value, path) {
    if (!value || value.length === 0) {
      return false
    } else {
      var folder = $perAdminApp.findNodeFromPath(
          $perAdminApp.getView().admin.nodes, path);
      for (var i = 0; i < folder.children.length; i++) {
        if (folder.children[i].name === value) {
          return false
        }
      }
    }
    return true
  };

  PerAdminImpl.prototype.fetchExternalImage = function fetchExternalImage (path, url, name, config) {
      var this$1 = this;

    return axios.get(url, {responseType: 'blob'})
        .then(function (response) {
          var data = new FormData();
          data.append(name, response.data, name);

          return updateWithFormAndConfig('/admin/uploadFiles.json' + path, data,
              config)
              .then(function () { return this$1.populateNodesForBrowser(path); })
        })
  };

  PerAdminImpl.prototype.setInitialPageEditorState = function setInitialPageEditorState (path) {
    return new Promise(function (resolve, reject) {
      populateView('/state', 'editorVisible', false);
      populateView('/state', 'rightPanelVisible', true);
      populateView('/state', 'editor', {});

      try {
        var page = path;
        var pagePath = page.split('/');
        var type = pagePath[3];
        pagePath.pop();
        if(type === 'pages') {
          callbacks.getView().state.tools.pages = pagePath.join('/');
        } else if(type === 'templates') {
          callbacks.getView().state.tools.templates = pagePath.join('/');
        }
        return $perAdminApp.stateAction('showPageInfo', { selected: page }).then( function () {
          resolve();
        })
      } catch(error) {
        logger$1.error('setting of path in initial page editor state failed');
        logger$1.error(error);
        reject();
      }
    })
  };

  PerAdminImpl.prototype.savePageEdit = function savePageEdit (path, node) {
    return new Promise(function (resolve, reject) {
      var formData = new FormData();
      // convert to a new object
      var nodeData = JSON.parse(JSON.stringify(node));
      if (nodeData.component) {
        var component = callbacks.getComponentByName(nodeData.component);
        if (component && component.methods && component.methods.beforeSave) {
          nodeData = component.methods.beforeSave(nodeData);
        }
      }
      if (nodeData.path === '/jcr:content') {
        nodeData['jcr:primaryType'] = 'per:PageContent';
      } else {
        nodeData['jcr:primaryType'] = 'nt:unstructured';
      }

      delete nodeData['children'];
      delete nodeData['path'];
      delete nodeData['component'];
      if (node.component) {
        nodeData['sling:resourceType'] = node.component.split('-').join('/');
      }
      stripNulls(nodeData);

      formData.append('content', json(nodeData));

      updateWithForm('/admin/updateResource.json' + path + node.path, formData)
      // .then( (data) => this.populateNodesForBrowser(parentPath) )
      .then(function () { return resolve(); })
      .catch( function (error) {
         logger$1.error('Failed to save page: ' + error);
         reject('Unable to save change. '+ error);
       });
    })
  };

  PerAdminImpl.prototype.saveObjectEdit = function saveObjectEdit (path, node) {
    var formData = new FormData();
    // convert to a new object
    var nodeData = JSON.parse(JSON.stringify(node));
    stripNulls(nodeData);
    delete nodeData['jcr:created'];
    delete nodeData['jcr:createdBy'];
    delete nodeData['jcr:lastModified'];
    delete nodeData['jcr:lastModifiedBy'];
    formData.append('content', json(nodeData));
    return updateWithForm('/admin/updateResource.json' + path, formData)
  };

  PerAdminImpl.prototype.saveAssetProperties = function saveAssetProperties (node) {
    return new Promise(function (resolve, reject) {
      var formData = new FormData();
      // convert to a new object
      var nodeData = JSON.parse(JSON.stringify(node));
      stripNulls(nodeData);
      delete nodeData['name'];
      delete nodeData['path'];
      delete nodeData['created'];
      delete nodeData['createdBy'];
      delete nodeData['lastModified'];
      delete nodeData['lastModifiedBy'];
      formData.append('content', json(nodeData));
      updateWithForm('/admin/updateResource.json' + node.path + '/jcr:content',
          formData)
          .then(function () { return resolve(); });
    })
  };

  PerAdminImpl.prototype.insertNodeAt = function insertNodeAt (path, component, drop, variation) {
    logger$1.fine(arguments);
    var formData = new FormData();
    formData.append('component', component);
    formData.append('drop', drop);
    if (variation) {
      formData.append('variation', variation);
    }
    return new Promise(function (resolve) {
      updateWithForm('/admin/insertNodeAt.json' + path, formData)
          .then(function (data) {
            resolve(data);
          }).catch(function () {
            resolve({});
          }
      );
    })
  };

  PerAdminImpl.prototype.insertNodeWithDataAt = function insertNodeWithDataAt (path, data, drop) {
    logger$1.fine(arguments);
    var formData = new FormData();
    formData.append('content', json(data));
    formData.append('drop', drop);
    return new Promise(function (resolve) {
      updateWithForm('/admin/insertNodeAt.json' + path, formData)
          .then(function (data) { return resolve(data); })
          .catch(function () { return resolve({}); });
    })
  };

  PerAdminImpl.prototype.moveNodeTo = function moveNodeTo (path, component, drop) {
    logger$1.fine(
        'Move Node To: path: ' + path + ', component: ' + component + ', drop: '
        + drop);
    var formData = new FormData();
    formData.append('component', component);
    formData.append('drop', drop);
    return updateWithForm('/admin/moveNodeTo.json' + path, formData)
  };

  PerAdminImpl.prototype.replicate = function replicate (path) {
    var formData = new FormData();
    formData.append('deep', 'false');
    formData.append('name', 'defaultRepl');
    return updateWithForm('/admin/repl.json' + path, formData)
  };

  PerAdminImpl.prototype.getPalettes = function getPalettes (templateName) {
    return fetch(("/admin/nodes.json/content/" + templateName + "/pages/css/palettes"))
        .then(function (data) {
          return $perAdminApp.findNodeFromPath(data,
              ("/content/" + templateName + "/pages/css/palettes"))
        }).catch(function (err) {
          logger$1.warn(("template " + templateName + " does not support palettes"));
        })
  };

  PerAdminImpl.prototype.tenantSetupReplication = function tenantSetupReplication (path, withSite) {
    var formData = new FormData();
    formData.append('withSite', withSite);
    return updateWithForm('/admin/tenantSetupReplication.json' + path, formData)
  };

  PerAdminImpl.prototype.backupTenant = function backupTenant (path) {
    var formData = new FormData();
    return updateWithForm('/admin/backupTenant.json' + path, formData)
  };

  PerAdminImpl.prototype.downloadBackupTenant = function downloadBackupTenant (path) {
    return fetch('/admin/downloadBackupTenant.zip' + path + ".zip")
  };

  PerAdminImpl.prototype.uploadBackupTenant = function uploadBackupTenant (path, files, cb) {
      var this$1 = this;

    var config = {
      onUploadProgress: function (progressEvent) {
        var percentCompleted = Math.floor(
            (progressEvent.loaded * 100) / progressEvent.total);
        cb(percentCompleted);
      }
    };
    var data = new FormData();
    if(files.length > 0) {
      var file = files[0];
      data.append('file', file, file.name);
      data.append('force', 'true');
    }
    if (!data.entries().next().done) {
      return updateWithFormAndConfig('/admin/uploadBackupTenant.json' + path, data,
          config)
          .then(function () { return this$1.populateNodesForBrowser(path); })
          .catch(function (error) {
  //          log.error('Failed to upload: ' + error)
            reject('Unable to upload due to an error. ' + error);
          })
    }
    return
  };

  PerAdminImpl.prototype.restoreTenant = function restoreTenant (path) {
    var formData = new FormData();
    return updateWithForm('/admin/restoreTenant.json' + path, formData)
  };
    
  PerAdminImpl.prototype.acceptTermsAndConditions = function acceptTermsAndConditions () {
      var this$1 = this;

    var formData = new FormData();
    return updateWithForm('/admin/acceptTermsAndConditions.json', formData).then( function (){
      return this$1.populateUser()
    })
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$4 = LoggerFactory.logger('selectToolsNodesPath').setLevelDebug();

  function loadToolsNodesPath(me, target) {

      log$4.fine(target);

      var view = me.getView();
      var tenant = view.state.tenant;

      return new Promise( function (resolve, reject) {
          me.getApi().populateNodesForBrowser(target.selected).then( function () {
              var path = document.location.pathname;
              var html = path.indexOf('.html');
              var newPath = path.slice(0,html) + '.html/path:'+target.selected;
              history.pushState({peregrinevue:true, path: newPath}, newPath, newPath);
              resolve();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$5 = LoggerFactory.logger('selectToolsNodesPath').setLevelDebug();

  function selectToolsNodesPath(me, target) {

      log$5.fine(target);

      var view = me.getView();
      var tenant = view.state.tenant;

      return new Promise( function (resolve, reject) { 
          if(target.selected.startsWith(("/content/" + (tenant.name) + "/pages"))) {
              set(view, '/state/tools/page', null);
          } else {
              set(view, '/state/tools/template', null);
          }
      
          me.stateAction('loadToolsNodesPath', target).then(function () {
              set(me.getView(), target.path, target.selected);
              resolve();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$6 = LoggerFactory.logger('createPage').setLevelDebug();

  function createPage(me, target) {

      log$6.fine(target);

      var api = me.getApi();
      var fullPath = (target.parent) + "/" + (target.name);
      var destination = Admin.Page.PAGES;
      var destinationPath = target.parent;

      if (target.edit) {
          destination = Admin.Page.EDIT;
          destinationPath = fullPath;
      }

      api.createPage(target.parent, target.name, target.template, target.title).then( function () {
          target.data.path = '/jcr:content';
          api.savePageEdit(fullPath, target.data).then( function () {
              set(me.getView(), '/state/tools/page', fullPath);
              me.loadContent((destination + "/path" + (SUFFIX_PARAM_SEPARATOR + destinationPath)));
          });
      });

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$7 = LoggerFactory.logger('createPageFromSkeletonPage').setLevelDebug();

  function createPageFromSkeletonPage(me, target) {

      log$7.fine(target);

      var api = me.getApi();
      var destination = Admin.Page.PAGES;
      var destinationPath = target.parent;

      if (target.edit) {
          destination = Admin.Page.EDIT;
          destinationPath += '/' + target.name;
      }

      api.createPageFromSkeletonPage(target.parent, target.name, target.skeletonPagePath).then( function () {
          target.data.path = '/jcr:content';
          api.savePageEdit(target.parent + '/' + target.name, target.data).then( function () {
              me.loadContent((destination + "/path" + (SUFFIX_PARAM_SEPARATOR + destinationPath)));
          });
      });

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$8 = LoggerFactory.logger('createPageWizard').setLevelDebug();

  function createPageWizard(me, target) {

      log$8.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/pages/create.html/path' + SUFFIX_PARAM_SEPARATOR +target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$9 = LoggerFactory.logger('createTenantWizard').setLevelDebug();

  function createTenantWizard(me, target) {

      log$9.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/pages/createtenant.html/path' + SUFFIX_PARAM_SEPARATOR +target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$a = LoggerFactory.logger('setTenant').setLevelDebug();

  function setTenant(me, tenant) {

    log$a.fine(tenant);

    var view = me.getView();
    var eventBus = me.eventBus;
    var list = view.admin.tenants;

    return new Promise( function (resolve, reject) {
      if (!list) { resolve(); }

      var next = list.filter(function (item) { return (item.name === tenant.name); });
      if (next.length <= 0) {
        throw 'tenant not found'
      }

      // prepopulate tree viewers
      set(me.getView(), '/state/tools', {
        dashboard: ("/content/" + (tenant.name)),
        pages: ("/content/" + (tenant.name) + "/pages"),
        assets: ("/content/" + (tenant.name) + "/assets"),
        objects: ("/content/" + (tenant.name) + "/objects"),
        templates: ("/content/" + (tenant.name) + "/templates")
      });

      next = next[0];
      set(me.getView(), '/state/tenant', next);
      eventBus.$emit('tenants-update', {
        current: next
      });
      resolve();

    }).catch(function (err) {
      log$a.error(err);
    })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$b = LoggerFactory.logger('createTenant').setLevelDebug();

  function createTenant(me, target) {

      log$b.fine(target);
      var api = me.getApi();
      return api.createTenant(target.fromName, target.toName, target.title, target.tenantUserPwd, target.colorPalette).then( function () {
          return api.populateTenants().then( function () {
              return setTenant(me, { name : target.toName }).then( function () {
                  if(target.editHome) {
                      me.loadContent('/content/admin/pages/pages/edit.html/path' + SUFFIX_PARAM_SEPARATOR + '/content/'+target.toName + '/pages/index');
                  } else {
                      me.loadContent('/content/admin/pages/welcome.html/path' + SUFFIX_PARAM_SEPARATOR + '/content/'+target.toName);
                  }
              })
          })        
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$c = LoggerFactory.logger('deletePage').setLevelDebug();

  function deletePage(me, target) {

      log$c.fine('deletePage',target);
      var api = me.getApi();
      me.getNodeFromView('/state/tools').page = undefined;
      return api.deletePage(target)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$d = LoggerFactory.logger('deleteTenant').setLevelDebug();

  function deleteTenant(me, target) {
      log$d.fine('deleteTenant',target);
      var api = me.getApi();
      me.getNodeFromView('/state/tools').page = undefined;
      return api.deleteTenant(target).then( function () { return api.populateTenants(); } )

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$e = LoggerFactory.logger('configureTenant').setLevelDebug();

  /**
   * StateAction:configureTenant
   * 
   * @module stateActions
   * 
   * @param {*} me a reference to the peregrine admin object
   * @param {*} target root path of site to configure (path to the per:Site node)
   */
  function configureTenant(me, target) {
      log$e.fine('configureTenant',target);
      var api = me.getApi();
      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/tenants/configure.html/path' + SUFFIX_PARAM_SEPARATOR +'/content/'+target.name);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$f = LoggerFactory.logger('renamePage').setLevelDebug();

  function renamePage(me, target) {

      log$f.fine(target);

      var api = me.getApi();
      var destination = Admin.Page.PAGES;

      if (target.edit) {
          destination = Admin.Page.EDIT;
      }

      return api.renamePage(target.path, target.name, target.title).then( function () {
          var path = me.getNodeFromView('/state/tools/pages');
          me.loadContent((destination + "/path" + (SUFFIX_PARAM_SEPARATOR + path)));
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$g = LoggerFactory.logger('movePage').setLevelDebug();

  function movePage(me, target) {

      log$g.fine(target);
      var api = me.getApi();
      return new Promise( function (resolve, reject) {
          api.movePage(target.path, target.to, target.type).then( function () {
              var path = me.getNodeFromView('/state/tools/pages');
              me.loadContent('/content/admin/pages/pages.html/path'+SUFFIX_PARAM_SEPARATOR+ path);
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$h = LoggerFactory.logger('createPage').setLevelDebug();

  function createTemplate(me, target) {

      log$h.fine(target);
      var api = me.getApi();
      return api.createTemplate(target.parent, target.name, target.component, target.title).then( function () {
          me.loadContent('/content/admin/pages/templates.html/path' + SUFFIX_PARAM_SEPARATOR + target.parent);
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$i = LoggerFactory.logger('createTemplateWizard').setLevelDebug();

  function createTemplateWizard(me, target) {

      log$i.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/templates/create.html/path'+SUFFIX_PARAM_SEPARATOR+target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$j = LoggerFactory.logger('sourceImageWizard').setLevelDebug();

  function sourceImageWizard(me, target) {

      log$j.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/assets/source.html/path'+SUFFIX_PARAM_SEPARATOR+target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$k = LoggerFactory.logger('sourceImageWizard').setLevelDebug();

  function fetchExternalAsset(me, target) {

      log$k.fine(target);

      var api = me.getApi();

      return new Promise( function (resolve, reject) {
          api.fetchExternalImage(target.path, target.url, target.name, target.config).then( function () {
              me.loadContent('/content/admin/pages/assets.html/path'+SUFFIX_PARAM_SEPARATOR+target.path);
              resolve();
          }).catch( function () {
              me.notifyUser('Error', 'Could not upload asset', target.error); 
              reject();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$l = LoggerFactory.logger('createFolder').setLevelDebug();

  function createFolder(me, target) {

      log$l.fine(target);
      var api = me.getApi();
      return api.createFolder(target.parent, target.name)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$m = LoggerFactory.logger('deleteFolder').setLevelDebug();

  function deleteFolder(me, target) {

      log$m.fine('deleteFolder',target);
      var api = me.getApi();
      return api.deleteFolder(target)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$n = LoggerFactory.logger('deleteFile').setLevelDebug();

  function deleteFile(me, target) {

      log$n.fine('deleteFile',target);
      var api = me.getApi();
      return api.deleteFile(target)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$o = LoggerFactory.logger('uploadFiles').setLevelDebug();

  function uploadFiles(me, target) {
      log$o.fine(target);
      var api = me.getApi();
      return api.uploadFiles(target.path, target.files, target.cb)
  //    return Promise.resolve()
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$p = LoggerFactory.logger('editPage').setLevelDebug();

  function editPage(me, target) {

      log$p.fine(target);

      var view = me.getView();
      var tenant = view.state.tenant;

      if(target.startsWith(("/content/" + (tenant.name) + "/pages"))) {
          set(view, '/state/tools/page', target);
      } else if(target.startsWith(("/content/" + (tenant.name) + "/templates"))) {
          set(view, '/state/tools/template', target);
      }

      set(view, '/state/contentview/editor/type', EditorTypes.PAGE);

      return new Promise( function (resolve, reject) {
          return me.stateAction('showPageInfo', { selected: target}).then( function () {
              me.loadContent('/content/admin/pages/pages/edit.html/path'+SUFFIX_PARAM_SEPARATOR+target);
              resolve();
          })
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */


  var log$q = LoggerFactory.logger('editTemplate').setLevelDebug();

  function editTemplate(me, target) {

      log$q.fine(target);

      return new Promise( function (resolve, reject) {
          set(me.getView(), '/state/contentview/editor/type', EditorTypes.TEMPLATE);
          me.loadContent('/content/admin/pages/templates/edit.html/path'+SUFFIX_PARAM_SEPARATOR+target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$r = LoggerFactory.logger('editComponent').setLevelDebug();

  function bringUpEditor(me, view, target) {
      log$r.fine('Bring Up Editor, ');

      me.beforeStateAction( function(name) {
          return new Promise( function (resolve, reject) {
              var current = JSON.stringify(view.pageView.page, jsonEqualizer, 2);
              if(name !== 'savePageEdit' && name !== 'deletePageNode') {
                  if(current === view.state.editor.checksum) {
                      resolve(true);
                  } else {
                      $perAdminApp.askUser('Save Page Edit?', 'Would you like to save your page edits?', {
                          yesText: 'Save',
                          noText: 'Cancel',
                          yes: function yes() {
                              var page = view.pageView.page;
                              var path = view.state.editor.path;
                              var data = me.findNodeFromPath(page, path);
                              me.stateAction('savePageEdit', { pagePath: view.pageView.path, path: path, data: data}).then( function () {
                                  resolve(true);
                              });
                          },
                          no: function no() {
                              resolve(false);
                          }
                      });
                  }
              } else {
                  resolve(true);
              }
          });
      });

      return new Promise( function (resolve, reject) {
          me.getApi().populateComponentDefinitionFromNode(view.pageView.path+target).then( function (name) {
                  log$r.fine('component name is', name);
                  set(view, '/state/editor/component', name);
                  set(view, '/state/editor/path', target);
                  set(view, '/state/editorVisible', true);
                  set(view, '/state/rightPanelVisible', true);
                  set(view, '/state/editor/checksum', JSON.stringify(view.pageView.page, jsonEqualizer, 2));
                  resolve();
              }
          ).catch( function (error) {
              log$r.debug('Failed to show editor: ' + error);
              $perAdminApp.notifyUser('error', 'was not able to bring up editor for the selected component');
              reject();
          });
      })

  }

  function editComponent(me, target) {

      log$r.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          if(view.state.editorVisible) {
              me.getApi().populatePageView(view.pageView.path).then( function () {
                  bringUpEditor(me, view, target).then( function () { resolve(); }).catch( function () { return reject(); } );
              });
          } else {
              bringUpEditor(me, view, target).then( function () { resolve(); }).catch( function () { return reject(); } );
          }
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$s = LoggerFactory.logger('savePageEdit').setLevelDebug();

  function savePageEdit(me, target) {

      log$s.fine(target);

      var view = me.getView();

      return new Promise( function (resolve, reject) {
          me.getApi().savePageEdit(view.pageView.path, target.data).then( function () {
              delete view.state.editor;
              set(view, '/state/editorVisible', false);
              if(view.pageView.page.serverSide) {
                  me.action(me.getApp().$children[0], 'refreshEditor', view.pageView.page).then( function () { resolve(); });
              } else {
                  resolve();
              }
          }).catch( function (error) {
             reject(error);
           });

      })
      // me.getApi().populateComponentDefinitionFromNode(view.pageView.path+target).then( (name) => {
      //         log.fine('component name is', name)
      //         set(view, '/state/editor/component', name)
      //         set(view, '/state/editor/path', target)
      //         set(view, '/state/editorVisible', true)
      //         set(view, '/state/rightPanelVisible', true)
      //     }
      // )
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$t = LoggerFactory.logger('deletePageNode').setLevelDebug();

  function deletePageNode(me, target) {

      if(target.path !== '/jcr:content') {
          log$t.fine('deletePageNode',target);
          var api = me.getApi();
          return new Promise( function (resolve, reject) {
              api.deletePageNode(target.pagePath, target.pagePath+target.path).then( function () {
                  var view = me.getView();
                  delete view.state.editor;
                  set(view, '/state/editorVisible', false);
                  resolve();
              });
          })
      }

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$u = LoggerFactory.logger('cancelPageEdit').setLevelDebug();

  function cancelPageEdit(me, target) {

      log$u.fine(target);

      var api = me.getApi();
      return new Promise( function (resolve, reject) {
          api.populatePageView(target.pagePath).then( function () {
              var view = me.getView();
              delete view.state.editor;
              set(view, '/state/editorVisible', false);
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$v = LoggerFactory.logger('addComponentToPath').setLevelDebug();

  function addComponentToPath(me, target) {

      log$v.fine('addComponentToPath()',target);

      var view = me.getView();

      var variationSeparator = target.component ? target.component.indexOf(':') : -1;
      var componentPath = variationSeparator === -1 ? target.component : target.component.slice(0, variationSeparator);
      var variation = variationSeparator === -1 ? undefined : target.component.slice(variationSeparator + 1, target.component.length);

      // resolve path to component name
      var componentName = componentPath ? componentPath.split('/').slice(2).join('-') : target.data.component;
      log$v.fine('load',componentName, 'into edit view (make sure it is available)');
      document.getElementById('editview').contentWindow.$peregrineApp.loadComponent(componentName);

      var targetNode = null;
      var targetNodeUpdate = null;
      if(target.drop.startsWith('into')) {
          targetNode = me.findNodeFromPath(view.pageView.page, target.path);
          targetNodeUpdate = targetNode;
      } else if(target.drop === 'before' || target.drop === 'after') {
          var path = parentPath(target.path);
          targetNodeUpdate = me.findNodeFromPath(view.pageView.page, path.parentPath);
          targetNode = me.findNodeFromPath(view.pageView.page, target.path);
      } else {
          log$v.error('addComponentToPath() target.drop not in allowed values - value was', target.drop);
      }

      var processed = false;
      // insert new component
      if(targetNode && target.component) {
          processed = true;
          return me.getApi().insertNodeAt(target.pagePath+targetNode.path, componentPath, target.drop, variation)
              .then( function (data) {
                          if(targetNodeUpdate.fromTemplate === true) {
                              return me.getApi().populatePageView(me.getNodeFromView('/pageView/path'))
                          } else {
                              if(target.drop.startsWith('into')) {
                                  Vue.set(targetNodeUpdate, 'children', data.children);
                              }
                              else if(target.drop === 'before' || target.drop === 'after')
                              {
                                  Vue.set(targetNodeUpdate, 'children', data.children);
                              }
                              log$v.fine(data);
                          }
                      })
      }

      // copy/paste?
      if(targetNode && target.data) {
          processed = true;
          return me.getApi().insertNodeWithDataAt(target.pagePath+targetNode.path, target.data, target.drop)
                      .then( function (data) {
                          if(targetNodeUpdate.fromTemplate === true) {
                              return me.getApi().populatePageView(me.getNodeFromView('/pageView/path'))
                          } else {
                              if (target.drop.startsWith('into')) {
                                  Vue.set(targetNodeUpdate, 'children', data.children);
                              }
                              else if (target.drop === 'before' || target.drop === 'after') {
                                  Vue.set(targetNodeUpdate, 'children', data.children);
                              }
                              log$v.fine(data);
                              return
                          }
                      })

      }

      if(!processed) {
          // target path does not exist yet
          return me.getApi().insertNodeAt(target.pagePath+target.path, target.component, target.drop)
              .then( function (data) {
                  if(!targetNodeUpdate) {
                      return me.getApi().populatePageView(me.getNodeFromView('/pageView/path'))
                  } else {
                      if(targetNodeUpdate.fromTemplate === true) {
                          return me.getApi().populatePageView(me.getNodeFromView('/pageView/path'))
                      } else {
                          if(target.drop.startsWith('into')) {
                              Vue.set(targetNodeUpdate, 'children', data.children);
                          }
                          else if(target.drop === 'before' || target.drop === 'after')
                          {
                              Vue.set(targetNodeUpdate, 'children', data.children);
                          }
                          log$v.fine(data);
                      }
                  }
              })
      }
      // return new Promise( (resolve, reject) => {

      //     if(targetNode) {
      //         if(target.component) {
      //             me.getApi().insertNodeAt(target.pagePath+targetNode.path, componentPath, target.drop, variation)
      //                 .then( (data) => {
      //                     if(targetNodeUpdate.fromTemplate === true) {
      //                         me.getApi().populatePageView(me.getNodeFromView('/pageView/path'))
      //                     } else {
      //                         if(target.drop.startsWith('into')) {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         else if(target.drop === 'before' || target.drop === 'after')
      //                         {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         log.fine(data)
      //                         resolve()
      //                     }
      //                 })
      //         } else if(target.data) {
      //             me.getApi().insertNodeWithDataAt(target.pagePath+targetNode.path, target.data, target.drop)
      //                 .then( (data) => {
      //                     if(targetNodeUpdate.fromTemplate === true) {
      //                         me.getApi().populatePageView(me.getNodeFromView('/pageView/path')).then(() => { resolve() })
      //                     } else {
      //                         if (target.drop.startsWith('into')) {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         else if (target.drop === 'before' || target.drop === 'after') {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         resolve()
      //                         log.fine(data)
      //                     }
      //                 })
      //         }
      //     } else {
      //         // target path does not exist yet
      //         me.getApi().insertNodeAt(target.pagePath+target.path, target.component, target.drop)
      //             .then( (data) => {
      //                 if(!targetNodeUpdate) {
      //                     me.getApi().populatePageView(me.getNodeFromView('/pageView/path')).then( () => { resolve() })
      //                 } else {
      //                     if(targetNodeUpdate.fromTemplate === true) {
      //                         me.getApi().populatePageView(me.getNodeFromView('/pageView/path')).then( () => { resolve() })
      //                     } else {
      //                         if(target.drop.startsWith('into')) {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         else if(target.drop === 'before' || target.drop === 'after')
      //                         {
      //                             Vue.set(targetNodeUpdate, 'children', data.children)
      //                         }
      //                         log.fine(data)
      //                         resolve()
      //                     }
      //                 }
      //             })
      //     }

      // })


      // me.getApi().savePageEdit(view.pageView.path, nodeToSave).then( () => {
      //     delete view.state.editor;
      //     set(view, '/state/editorVisible', false)
      // })
      // me.getApi().populateComponentDefinitionFromNode(view.pageView.path+target).then( (name) => {
      //         log.fine('component name is', name)
      //         set(view, '/state/editor/component', name)
      //         set(view, '/state/editor/path', target)
      //         set(view, '/state/editorVisible', true)
      //         set(view, '/state/rightPanelVisible', true)
      //     }
      // )
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$w = LoggerFactory.logger('moveComponentToPath').setLevelDebug();

  function moveComponentToPath(me, target) {

      log$w.fine('moveComponentToPath()',target);

      var view = me.getView();

      var targetNodeUpdate = null;
      if(target.drop.startsWith('into')) {
          targetNodeUpdate = me.findNodeFromPath(view.pageView.page, target.path);
      } else if(target.drop === 'before' || target.drop === 'after') {
          var path = parentPath(target.path);
          targetNodeUpdate = me.findNodeFromPath(view.pageView.page, path.parentPath);
      } else {
          log$w.error('addComponentToPath() target.drop not in allowed values - value was', target.drop);
      }

      return new Promise( function (resolve, reject) {
          me.getApi().moveNodeTo(target.pagePath+target.path, target.pagePath+target.component, target.drop)
          .then( function (data) {
              var node = me.findNodeFromPath(view.pageView.page, target.component);
              var parent = me.findNodeFromPath(view.pageView.page, parentPath(target.component).parentPath);
              var index = parent.children.indexOf(node);
              parent.children.splice(index, 1);
              if(targetNodeUpdate.fromTemplate === true) {
                  me.getApi().populatePageView(me.getNodeFromView('/pageView/path')).then( function () { resolve(); });
              } else {
                  if(target.drop.startsWith('into')) {
                      Vue.set(targetNodeUpdate, 'children', data.children);
                  }
                  else if(target.drop === 'before' || target.drop === 'after')
                  {
                      Vue.set(targetNodeUpdate, 'children', data.children);
                  }
                  resolve();
              }
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$x = LoggerFactory.logger('selectObject').setLevelDebug();

  function selectObject(me, target) {

      log$x.fine(target);

      var view = me.getView();

      return new Promise( function (resolve, reject) {
          Vue.set(me.getNodeFromView('/state/tools'), 'edit', false);
          me.getApi().populateObject(target.selected, '/state/tools/object', 'data').then( function () {
              me.getApi().populateReferencedBy(target.selected).then( function () {
                  set(view, '/state/tools/object/show', target.selected);
                  resolve();
              });
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$y = LoggerFactory.logger('editObject').setLevelDebug();

  function editObject(me, target) {

      log$y.fine(target);

      var checksum = '';

      me.beforeStateAction( function(name) {
          if(name !== 'saveObjectEdit') {
              // if there was no change skip asking to save
              if(checksum === JSON.stringify(me.getNodeFromView('/state/tools/object/data'))) {
                  return true
              }
              var yes = confirm('save edit?');
              if(yes) {
                  var currentObject = me.getNodeFromView("/state/tools/object");
                  me.stateAction('saveObjectEdit', { data: currentObject.data, path: currentObject.show });
              }
          }
          return true
      });

      var view = me.getView();
      Vue.set(me.getNodeFromView('/state/tools'), 'edit', true);
      me.getApi().populateObject(target.selected, '/state/tools/object', 'data').then( function () {
          checksum = JSON.stringify(me.getNodeFromView('/state/tools/object/data'));
          set(view, '/state/tools/object/show', target.selected);
      });
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$z = LoggerFactory.logger('unselectObject').setLevelDebug();

  function unselectObject(me, target) {

      log$z.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          set(view, '/state/tools/object', undefined);
          resolve();
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$A = LoggerFactory.logger('saveObjectEdit').setLevelDebug();

  function saveObjectEdit(me, target) {

      log$A.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().saveObjectEdit(target.path, target.data).then( function () {
              resolve();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$B = LoggerFactory.logger('saveObjectEdit').setLevelDebug();

  function saveAssetProperties(me, target) {

      log$B.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().saveAssetProperties(target).then( function () {
              resolve();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$C = LoggerFactory.logger('deleteObject').setLevelDebug();

  function deleteObject(me, target) {

      log$C.fine('deleteObject',target);
      var api = me.getApi();
      return api.deleteObject(target)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$D = LoggerFactory.logger('createObject').setLevelDebug();

  function createObject(me, target) {

      log$D.fine(target);
      var api = me.getApi();
      return new Promise( function (resolve, reject) {
          api.createObject(target.parent, target.name, target.template).then( function () {
              if(target.data) {
                  api.saveObjectEdit(target.parent + '/' + target.name, target.data).then( function () {
                      if(target.returnTo) {
                          me.loadContent(target.returnTo+'.html/path' +SUFFIX_PARAM_SEPARATOR + target.parent);
                      } else {
                          me.loadContent('/content/admin/pages/objects.html/path' + SUFFIX_PARAM_SEPARATOR + target.parent);
                      }
                      resolve();
                  });
              }
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$E = LoggerFactory.logger('createObjectWizard').setLevelDebug();

  function createObjectWizard(me, target) {

      log$E.fine(target);

      return new Promise( function (resolve, reject) {
          if(target.target) {
              me.loadContent(target.target+'.html/path' + SUFFIX_PARAM_SEPARATOR +target.path);
          } else {
              me.loadContent('/content/admin/pages/objects/create.html/path'+ SUFFIX_PARAM_SEPARATOR +target.path);
          }
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$F = LoggerFactory.logger('selectAsset').setLevelDebug();

  function selectAsset(me, target) {

      log$F.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          me.getApi().populateComponentDefinitionFromNode('/apps/admin/components/assetview').then( function () {
              me.getApi().populateReferencedBy(target.selected).then( function () {
                  set(view, '/state/tools/asset/show', target.selected);
                  resolve();
              });
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$G = LoggerFactory.logger('unselectAsset').setLevelDebug();

  function unselectAsset(me, target) {

      log$G.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          set(view, '/state/tools/asset', undefined);
          resolve();
      });
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$H = LoggerFactory.logger('unselectPage').setLevelDebug();

  function unselectPage(me, target) {

      log$H.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          set(view, '/state/tools/page', undefined);
          resolve();
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$I = LoggerFactory.logger('unselectTemplate').setLevelDebug();

  function unselectTemplate(me, target) {

      log$I.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          set(view, '/state/tools/template', undefined);
          resolve();
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$J = LoggerFactory.logger('deleteAsset').setLevelDebug();

  function deleteAsset(me, target) {

      log$J.fine('deleteAsset',target);
      me.getNodeFromView('/state/tools').asset = null;
      var api = me.getApi();
      return api.deleteAsset(target)

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$K = LoggerFactory.logger('renameAsset').setLevelDebug();

  function renameAsset(me, target) {

      log$K.fine(target);
      var api = me.getApi();
      return api.renameAsset(target.path, target.name, target.title).then( function () {
          var path = me.getNodeFromView('/state/tools/assets');
          me.loadContent('/content/admin/pages/assets.html/path'+SUFFIX_PARAM_SEPARATOR+ path);
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$L = LoggerFactory.logger('moveAsset').setLevelDebug();

  function moveAsset(me, target) {

      log$L.fine(target);
      var api = me.getApi();
      return new Promise(function (resolve, reject) {
          api.moveAsset(target.path, target.to, target.type).then( function () {
              var path = me.getNodeFromView('/state/tools/assets');
              me.loadContent('/content/admin/pages/assets.html/path'+SUFFIX_PARAM_SEPARATOR+ path);
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$M = LoggerFactory.logger('showPageInfo').setLevelDebug();

  function showPageInfo(me, target) {

      log$M.fine(target);

      var view = me.getView();
      var tenant = view.state.tenant;

      return new Promise( function (resolve, reject) {
          return me.getApi().populateExplorerDialog(target.selected).then( function () {
              if(target.selected.startsWith(("/content/" + (tenant.name) + "/pages"))) {
                  return me.getApi().populateReferencedBy(target.selected).then( function () {
                      set(view, '/state/tools/page', target.selected);
                      resolve();
                  }).catch( function (error) { return reject(error); })
              } else if(target.selected.startsWith(("/content/" + (tenant.name) + "/templates"))) {
                  return me.getApi().populateReferencedBy(target.selected).then( function () {
                      set(view, '/state/tools/template', target.selected);
                      resolve();
                  }).catch( function (error) { return reject(error); })
              }
          }).catch( function (error) { return reject(error); })
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License") you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$N = LoggerFactory.logger('editPreview').setLevelDebug();

  function editPreview (me, target) {

    log$N.fine(target);
    target = target || 'preview';

    var state = {
      preview: '/state/tools/workspace/preview',
      igContainers: '/state/tools/workspace/ignoreContainers',
      pageViewView: '/pageView/view',
      view: '/state/tools/workspace/view'
    };
    var view = me.getView();
    var currIgContainers = get(view, state.igContainers, IgnoreContainers.DISABLED);
    var current = get(view, state.preview, '');

    return new Promise(function (resolve, reject) {
      if (target === 'preview') {
        if (current === 'preview') {
          set(view, state.preview, '');
          if (currIgContainers === IgnoreContainers.ON_HOLD) {
            set(view, state.igContainers, IgnoreContainers.ENABLED);
            set(view, state.pageViewView, IgnoreContainers.ENABLED);
          } else {
            set(view, state.pageViewView, view.state.tools.workspace.view);
          }
        } else {
          set(view, state.preview, target);
          set(view, state.pageViewView, target);
          if (currIgContainers === IgnoreContainers.ENABLED) {
            set(view, state.igContainers, IgnoreContainers.ON_HOLD);
          }
        }
      } else if (target === IgnoreContainers.ENABLED) {
        if (current !== 'preview') {
          if (currIgContainers === IgnoreContainers.ENABLED) {
            set(view, state.igContainers, IgnoreContainers.DISABLED);
            set(view, state.pageViewView, view.state.tools.workspace.view);
          } else {
            set(view, state.igContainers, target);
            set(view, state.pageViewView, target);
          }
        }
      } else {
        set(view, state.view, target);
      }
      me.eventBus.$emit('edit-preview', get(view, state.preview, ''));
      resolve();
    })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$O = LoggerFactory.logger('createAssetFolder').setLevelDebug();

  function createAssetFolder(me, target) {
      log$O.fine(target);
      var api = me.getApi();

      return new Promise( function (resolve, reject) {
          api.createFolder(target.parent, target.name).then( function () {
              me.loadContent('/content/admin/pages/assets.html/path'+ SUFFIX_PARAM_SEPARATOR + target.parent);
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$P = LoggerFactory.logger('createObjectFolder').setLevelDebug();

  function createObjectFolder(me, target) {
      log$P.fine(target);
      var api = me.getApi();

      return new Promise( function (resolve, reject) {
          api.createFolder(target.parent, target.name).then( function () {
              me.loadContent('/content/admin/pages/objects.html/path'+ SUFFIX_PARAM_SEPARATOR + target.parent);
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$Q = LoggerFactory.logger('createAssetFolderWizard').setLevelDebug();

  function createAssetFolderWizard(me, target) {

      log$Q.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/assets/create.html/path' +SUFFIX_PARAM_SEPARATOR +target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$R = LoggerFactory.logger('createObjectFolderWizard').setLevelDebug();

  function createObjectFolderWizard(me, target) {

      log$R.fine(target);

      return new Promise( function (resolve, reject) {
          me.loadContent('/content/admin/pages/objects/createFolder.html/path' +SUFFIX_PARAM_SEPARATOR +target);
          resolve();
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$S = LoggerFactory.logger('savePageProperties').setLevelDebug();

  function savePageProperties(me, target) {

      log$S.fine(target);

      var view = me.getView();
      var nodeData = {};

      nodeData.path = '/jcr:content';
      nodeData.component = target.component;

      var component = target.component;
      var schema = view.admin.componentDefinitions[component].model;
      var ogTagSchema = view.admin.componentDefinitions[component].ogTags;

      for(var i = 0; i < schema.fields.length; i++) {
          if(!schema.fields[i].readonly) {
              var srcName = schema.fields[i].model;
              var dstName = schema.fields[i]['x-model'] ? schema.fields[i]['x-model'] : srcName;
              nodeData[dstName] = target[srcName];
          }
      }
      for(var i$1 = 0; i$1 < ogTagSchema.fields.length; i$1++) {
          if(!ogTagSchema.fields[i$1].readonly) {
              var srcName$1 = ogTagSchema.fields[i$1].model;
              var dstName$1 = ogTagSchema.fields[i$1]['x-model'] ? ogTagSchema.fields[i$1]['x-model'] : srcName$1;
              nodeData[dstName$1] = target[srcName$1];
          }
      }

      log$S.fine(nodeData);
      return new Promise( function (resolve, reject) {
          me.getApi().savePageEdit(target.path, nodeData).then( function () {
              resolve();
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$T = LoggerFactory.logger('replicate').setLevelDebug();

  function replicate(me, target) {

      log$T.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().replicate(target).then( function () {
              resolve();
          }).catch( function (error) {
              log$T.debug('Failed to replicate: ' + error);
              reject('Unable to publish content due to error. '+ error);
          });
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$U = LoggerFactory.logger('moveTemplate').setLevelDebug();

  function moveTemplate(me, target) {

      log$U.fine(target);
      var api = me.getApi();
      api.moveTemplate(target.path, target.to, target.type).then( function () {
          var path = me.getNodeFromView('/state/tools/templates');
          me.loadContent('/content/admin/pages/templates.html/path'+SUFFIX_PARAM_SEPARATOR+ path);
      });

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$V = LoggerFactory.logger('renameObject').setLevelDebug();

  function renameObject(me, target) {

      log$V.fine(target);
      var api = me.getApi();
      return new Promise( function (resolve, reject) {
          api.renameObject(target.path, target.name).then( function () {
              var path = me.getNodeFromView('/state/tools/objects');
              if(target.returnTo) {
                  me.loadContent(target.returnTo+'.html/path' +SUFFIX_PARAM_SEPARATOR + path);
                  resolve();
              } else {
                  me.loadContent('/content/admin/pages/objects.html/path' + SUFFIX_PARAM_SEPARATOR + path);
              }
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$W = LoggerFactory.logger('movePage').setLevelDebug();

  function moveObject(me, target) {

      log$W.fine(target);
      var api = me.getApi();

      new Promise( function (resolve, reject) {
          api.movePage(target.path, target.to, target.type).then( function () {
              var path = me.getNodeFromView('/state/tools/objects');
              me.loadContent('/content/admin/pages/objects.html/path'+SUFFIX_PARAM_SEPARATOR+ path);
              resolve();
          });
      });

  }

  var log$X = LoggerFactory.logger('deleteTemplate').setLevelDebug();

  function deleteTemplate (me, target) {

    log$X.fine(target);

    var api = me.getApi();

    me.getNodeFromView('/state/tools').template = undefined;

    return api.deleteTemplate(target);
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$Y = LoggerFactory.logger('versions').setLevelDebug();

  function deleteVersion(me, target) {
      log$Y.fine(target);
      var api = me.getApi();
      return api.deleteVersion(target)
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$Z = LoggerFactory.logger('versions').setLevelDebug();

  function createVersion(me, target) {
      log$Z.fine(target);
      var api = me.getApi();
      return api.createVersion(target)
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$_ = LoggerFactory.logger('versions').setLevelDebug();

  function restoreVersion(me, target) {
      log$_.fine(target);
      var api = me.getApi();
      return api.restoreVersion(target.path, target.versionName)
  }

  var log$$ = LoggerFactory.logger('renameTemplate').setLevelDebug();

  function renameTemplate (me, target) {

    log$$.fine(target);

    var api = me.getApi();

    return api.renamePage(target.path, target.name, target.title).then(function () {
      var path = me.getNodeFromView('/state/tools/templates');
      me.loadContent(("/content/admin/pages/templates.html/path" + (SUFFIX_PARAM_SEPARATOR + path)));
    });
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   * Contributed by Cris Rockwell, University of Michigan
   */
  var log$10 = LoggerFactory.logger('recycleItem').setLevelDebug();

  function recycleItem(me, target) {
      log$10.fine(target);
      var api = me.getApi();
      return api.recycleItem(target)
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$11 = LoggerFactory.logger('recycleItem').setLevelDebug();

  function deleteRecyclable(me, target) {
      log$11.fine(target);
      var api = me.getApi();
      return api.deleteRecyclable(target)
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$12 = LoggerFactory.logger('tenantSetupReplication').setLevelDebug();

  function tenantSetupReplication(me, target) {

      log$12.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().tenantSetupReplication(target).then( function () {
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$13 = LoggerFactory.logger('backupTenant').setLevelDebug();

  function backupTenant(me, target) {

      log$13.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().backupTenant(target).then( function () {
              alert('done');
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$14 = LoggerFactory.logger('backupTenant').setLevelDebug();

  function downloadBackupTenant(me, target) {

      log$14.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().downloadBackupTenant(target).then( function () {
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$15 = LoggerFactory.logger('uploadBackupTenant').setLevelDebug();

  function uploadBackupTenant(me, target) {
      log$15.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().uploadBackupTenant(target.path, target.files, target.cb)
              .then( function () { return alert('done'); } );
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$16 = LoggerFactory.logger('restoreTenant').setLevelDebug();

  function restoreTenant(me, target) {

      log$16.fine(target);

      return new Promise( function (resolve, reject) {
          me.getApi().restoreTenant(target).then( function () {
              resolve();
          });
      })

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2020 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var log$17 = LoggerFactory.logger('acceptTermsAndConditions').setLevelDebug();

  function acceptTermsAndConditions(me, target) {

      log$17.fine(target);

      var view = me.getView();
      return new Promise( function (resolve, reject) {
          return me.getApi().acceptTermsAndConditions().then( function () {
              me.loadContent('/content/admin/pages/onboard/welcome.html');
              resolve();
          })
      })
  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   *
   * http://www.apache.org/licenses/LICENSE-2.0
   *
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var log$18 = LoggerFactory.logger('actions').setLevelDebug();

  var actions = [];

  actions['loadToolsNodesPath'] = loadToolsNodesPath;
  actions['selectToolsNodesPath'] = selectToolsNodesPath;
  actions['createTenantWizard'] = createTenantWizard;
  actions['createTenant'] = createTenant;
  actions['createPageWizard'] = createPageWizard;
  actions['createPage'] = createPage;
  actions['createPageFromSkeletonPage'] = createPageFromSkeletonPage;
  actions['deletePage'] = deletePage;
  actions['deleteTenant'] = deleteTenant;
  actions['configureTenant'] = configureTenant;
  actions['renamePage'] = renamePage;
  actions['movePage'] = movePage;
  actions['createTemplate'] = createTemplate;
  actions['createTemplateWizard'] = createTemplateWizard;
  actions['createFolder'] = createFolder;
  actions['deleteFolder'] = deleteFolder;
  actions['deleteFile'] = deleteFile;
  actions['uploadFiles'] = uploadFiles;
  actions['sourceImageWizard'] = sourceImageWizard;
  actions['fetchExternalAsset'] = fetchExternalAsset;
  actions['editPage'] = editPage;
  actions['editTemplate'] = editTemplate;
  actions['editComponent'] = editComponent;
  actions['savePageEdit'] = savePageEdit;
  actions['addComponentToPath'] = addComponentToPath;
  actions['moveComponentToPath'] = moveComponentToPath;
  actions['deletePageNode'] = deletePageNode;
  actions['cancelPageEdit'] = cancelPageEdit;
  actions['selectObject'] = selectObject;
  actions['editObject'] = editObject;
  actions['unselectObject'] = unselectObject;
  actions['saveObjectEdit'] = saveObjectEdit;
  actions['saveAssetProperties'] = saveAssetProperties;
  actions['deleteObject'] = deleteObject;
  actions['createObject'] = createObject;
  actions['createObjectWizard'] = createObjectWizard;
  actions['selectAsset'] = selectAsset;
  actions['showPageInfo'] = showPageInfo;
  actions['unselectAsset'] = unselectAsset;
  actions['unselectPage'] = unselectPage;
  actions['unselectTemplate'] = unselectTemplate;
  actions['deleteAsset'] = deleteAsset;
  actions['renameAsset'] = renameAsset;
  actions['moveAsset'] = moveAsset;
  actions['editPreview'] = editPreview;
  actions['createAssetFolder'] = createAssetFolder;
  actions['createAssetFolderWizard'] = createAssetFolderWizard;
  actions['createObjectFolder'] = createObjectFolder;
  actions['createObjectFolderWizard'] = createObjectFolderWizard;
  actions['renameObject'] = renameObject;
  actions['savePageProperties'] = savePageProperties;
  actions['replicate'] = replicate;
  actions['moveObject'] = moveObject;
  actions['showTemplateInfo'] = showPageInfo;
  actions['saveTemplateProperties'] = savePageProperties;
  actions['renameTemplate'] = renameTemplate;
  actions['moveTemplate'] = moveTemplate;
  actions['deleteTemplate'] = deleteTemplate;
  actions['recycleItem'] = recycleItem;
  actions['deleteRecyclable'] = deleteRecyclable;
  actions['deleteVersion'] = deleteVersion;
  actions['createVersion'] = createVersion;
  actions['restoreVersion'] = restoreVersion;
  actions['setTenant'] = setTenant;
  actions['tenantSetupReplication'] = tenantSetupReplication;
  actions['backupTenant'] = backupTenant;
  actions['downloadBackupTenant'] = downloadBackupTenant;
  actions['uploadBackupTenant'] = uploadBackupTenant;
  actions['restoreTenant'] = restoreTenant;
  actions['acceptTermsAndConditions'] = acceptTermsAndConditions;


  function noopAction(me, target) {
      log$18.error('state action noop with target:', target);
  }

  function getStateAction(name) {

      log$18.fine(actions);
      if(actions[name]) {
          return actions[name]
      } else {
          log$18.error('stateAction', name, 'missing');
          return noopAction
      }

  }

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var consoleERROR = console.error;

  if($perAdminApp) {
      $perAdminApp.getView().admin.consoleErrors = false;
  }

  console.error= function() {
      if($perAdminApp) {
          $perAdminApp.getView().admin.consoleErrors = true;
      }
      consoleERROR.apply(this, arguments);
  };

  var logger$2 = LoggerFactory.logger('perAdminApp').setLevelDebug();

  /**
   * registers a pop state listener for the adminui to track back/forward button and loads
   * the correct screen accordingly
   *
   * @private
   * @param e
   */
  window.onpopstate = function(e) {
      if(e && e.state && e.state.path) {
          loadContentImpl(e.state.path, false, true);
      }
  };

  /**
   * the view object containing all the data used to render the UI

   * @private
   * @type {null}
   */
  var view = null;

  /**
   * reference to the API Interface that's used to implement all backend functionality
   *
   * @private
   * @type {null}
   */
  var api = null;

  /**
   * the vuejs app that is created to render the admin ui
   *
   * @private
   * @type {null}
   */
  var app = null;

  /**
   * list of currently loaded vuejs components
   *
   * @private
   * @type {Array}
   */
  var loadedComponents = [];

  /** ?
   *
   * @private
   * @type {null}
   */
  var OSBrowser = null;

  /**
   * list of all the currently installed extensions
   *
   * @private
   * @type {Array}
   */
  var extensions = [];

  /**
   * dynamic component initializer\ - this function takes a name of a component and tries to
   * find the matching variable in the global scope if the component has not been registered
   * with vuejs yet.
   *
   * @private
   */
  function loadComponentImpl(name) {
      if(!loadedComponents[name]) {
          logger$2.fine('loading vuejs component', name);
          var segments = name.split('-');
          for(var i = 0; i < segments.length; i++) {
              segments[i] = segments[i].charAt(0).toUpperCase() + segments[i].slice(1);
          }
          if(window['cmp'+segments.join('')]) {
              Vue.component(name, window['cmp'+segments.join('')]);
          }
          loadedComponents[name] = true;
      } else {
          logger$2.fine('component',name, 'already present');
      }
  }

  /**
   * gets the global varibale backing a component by it's name (vuejs - name converted to camel case
   * and cmp added in front of it)
   *
   * @private
   * @param name
   * @return {*}
   */
  function getComponentByNameImpl(name) {
      var segments = name.split('-');
      for(var i = 0; i < segments.length; i++) {
          segments[i] = segments[i].charAt(0).toUpperCase() + segments[i].slice(1);
      }
      return window['cmp'+segments.join('')]
  }

  /**
   * loads data into the view through the populateByName function of the api
   *
   * @private
   * @param source
   * @return {*}
   */
  function loadData(source) {
      logger$2.fine('requesting to load data for', source);
      return api.populateByName(source)
  }

  /**
   * walks the current node tree and loads all the necessary data related to the page
   *
   * @private

   * @param node
   * @return {Promise}
   */
  function walkTreeAndLoad(node) {

      return new Promise( function (resolve, reject) {
          if(node.component) { loadComponentImpl(node.component); }
          if(node.dataFrom) {
              get(view, node.dataFrom, node.dataDefault);
          }
          var promises = [];
          if(node.source) {
              promises.push(loadData(node.source));
          }
          if(node.children) {
              node.children.forEach(function (child) {
                  promises.push(walkTreeAndLoad(child));
              });
          }
          Promise.all(promises).then( function () { return resolve(); } );
      })
  }

  /**
   * initializes the vuejs app
   *
   * @private
   */
  function initPeregrineApp() {
      logger$2.fine('initPeregrineApp');
      logger$2.fine(JSON.stringify(view, true, 2));

      Vue.config.productionTip = false;
      Vue.use(i18n);
      Vue.use(experiences);
      var lang = view.state.language;
      var i18nData = view.admin.i18n;
      var tenant = view ? (view.state ? view.state.tenant : undefined) : undefined;

      app = new Vue({
          el: '#peregrine-adminapp',
          data: view
      });

      var state = sessionStorage.getItem('perAdminApp.state');
      var admin = sessionStorage.getItem('perAdminApp.admin');


      // if(state && admin) {
      //     view.state = JSON.parse(state)
      //     view.admin = JSON.parse(admin)

      //     // make i18n and language selection survive session storage
      //     view.state.language = lang
      //     view.admin.i18n = i18nData
      //     if(tenant) { view.state.tenant = tenant }
      // }

      app.$watch('state', function(newVal, oldVal) {
          sessionStorage.setItem('perAdminApp.state', JSON.stringify(newVal));
      }, { deep: true });
      app.$watch('admin', function(newVal, oldVal) {
          sessionStorage.setItem('perAdminApp.admin', JSON.stringify(newVal));
      }, { deep: true });
  }

  /**
   * conversion of suffix paramters to model
   *
   * @private
   * @param suffixParams
   * @param mappers
   */
  function suffixParamsToModel(suffixParams, mappers) {

      if(mappers) {
          for(var i = 0; i < mappers.length; i+=2) {

              var paramName = mappers[i];
              var paramPath = mappers[i+1];
              var paramValue = suffixParams[paramName];

              if(paramValue) {
                  logger$2.fine('set',paramPath,'to',paramValue);
                  set(view, paramPath, paramValue);
              }
          }
      }

  }

  /**
   * process all the defined loaders from the data model
   *
   * @private
   * @param loaders
   * @return {Promise}
   */
  function processLoaders(loaders) {

      return new Promise( function (resolve, reject) {
          var promises = [];
          if(loaders) {
              for(var i = 0; i < loaders.length; i++) {
                  var loader = loaders[i].split(':');
                  if(loader.length < 2) {
                      logger$2.fine('unknown loader', loaders[i]);
                  } else {
                      logger$2.fine('loading data with', loader[0], loader[1]);
                      var pathFrom = loader[1];
                      var dataToLoad = getNodeFromImpl(view, pathFrom);
                      logger$2.fine(dataToLoad);
                      if(api[loader[0]]) {
                          promises.push(api[loader[0]](dataToLoad));
                      } else {
                          logger$2.error('missing', loader[0]);
                          reject('missing ' + loader[0]+' '+dataToLoad);
                      }
                  }
              }
          }
          Promise.all(promises).then( function () { return resolve(); } );
      })
  }

  /**
   * Implementation of the loadContent function of the $perAdminApp interface.
   *
   * checks if user is logged in then loads the data for the given page and processes the tree
   * for all loaders and component registration. Finally updates the history and applies the
   * changes to the view
   *
   * @private
   *
   */
  function loadContentImpl(initialPath, firstTime, fromPopState) {
      logger$2.fine('loading content for', initialPath);
      view.admin.consoleErrors = false;

      if(!runBeforeStateActions() ) {
          logger$2.fine('not allowed to switch state');
          return
      }

      var pathInfo = makePathInfo(initialPath.toString());
      var path = pathInfo.path;

      var dataUrl = pagePathToDataPath(path);

      view.status = undefined;

      api.populateUser()
          .then(function() {
              if(pathInfo.suffixParams.path) {
                  var segments = pathInfo.suffixParams.path.split('/');
                  if(segments.length >= 3) {
                      if(view.state.tenant && view.state.tenant.name !== segments[2]) {
                          logger$2.error('tenant mismatch');
                      } else {
                          logger$2.fine('tenant missing');
                          return api.populateTenants().then( function () {
                              var tenant = view.admin.tenants.filter( function (node) { return node.name === segments[2]; } );
                              if(tenant.length >= 1) {
                                  view.state.tenant = tenant[0];
                              } else {
                                  logger$2.error('tenant does not exist or no access to tenant');
                              }
                          })
                      }
                  }
              }
          })
          .then(function() {
              api.populateContent(dataUrl)
                  .then( function () {
                      logger$2.fine('got data for', path);
                      walkTreeAndLoad(view.adminPageStaged).then( function() {
                          suffixParamsToModel(pathInfo.suffixParams, view.adminPageStaged.suffixToParameter);

                          processLoaders(view.adminPageStaged.loaders).then( function () {
                              if(firstTime) {
                                  view.adminPage = view.adminPageStaged;
                                  view.status = 'loaded';
                                  initPeregrineApp();
                              } else {
                                  view.adminPage = view.adminPageStaged;
                                  view.status = 'loaded';
                              }

                              delete view.adminPageStaged;

                              if(!fromPopState) {
                                  var params = view.adminPage.suffixToParameter;
                                  var suffix = "";
                                  if(params) {
                                      var rendered = [];
                                      for(var i = 0; i < params.length; i+=2) {
                                          if(rendered.indexOf(params[i]) >= 0) {
                                              continue;
                                          } else {
                                              rendered.push(params[i]);
                                          } 
                                          if(i === 0) {
                                              suffix += '/';
                                          } else {
                                              suffix += SUFFIX_PARAM_SEPARATOR;
                                          }

                                          suffix += params[i];
                                          suffix += SUFFIX_PARAM_SEPARATOR;
                                          suffix += getNodeFromImpl(view, params[i+1]);
                                      }
                                  }
                                  var targetPath = initialPath.slice(0, initialPath.indexOf('.html')) + '.html' + suffix;

                                  if(document.location !== targetPath) {
                                      document.title = getNodeFromImpl(view, '/adminPage/title');
                                      history.pushState({peregrinevue:true, path: targetPath}, targetPath, targetPath);
                                  }
                              }
                          });

                      });
                  }).catch(function(error) {
                      logger$2.error("error getting %s %j", dataUrl, error);
                  });
          });
  }

  /**
   * finds a UI action in the node tree that makes up the currently rendered page. Walks the full tree
   *
   * @private
   * @param component
   * @param command
   * @param target
   * @return {boolean}
   */
  function findActionInTree(component, command, target) {
      if(component.$options.methods && component.$options.methods[command]) {
          component.$options.methods[command](component, target);
          return true
      } else {
          var children = component.$children;
          for(var i = 0; i < children.length; i++) {
              var ret = findActionInTree(children[i], command, target);
              if(ret) { return true; }
          }
      }
  }

  /**
   * implementation of $perAdminApp.action()
   *
   * @private
   * @param component
   * @param command
   * @param target
   */
  function actionImpl(component, command, target) {
      if(component.$options.methods && component.$options.methods[command]) {
          return component.$options.methods[command](component, target)
      } else {
          if(component.$parent === component.$root) {
              if(!findActionInTree(component.$root, command, target)) {
                  logger$2.error('action', command, 'not found, ignored, traget was', target);
              }
          } else {
              return actionImpl(component.$parent, command, target)
          }
      }
  }

  /**
   * keeps a list of the current state actions we want to perform after another state action is
   * triggered (for example to ask if a change in the editor should be saved)
   *
   * @type {Array}
   */
  var beforeStateActions = [];

  function beforeStateActionImpl(fun) {
      beforeStateActions.push(fun);
  }

  function runBeforeStateActions(name) {
      // execute all before state actions
      var actions = [];
      if(beforeStateActions.length > 0) {
          for(var i = 0; i < beforeStateActions.length; i++) {
              actions.push(beforeStateActions[i](name));
          }
      }

      return new Promise( function (resolve) {
          Promise.all(actions).then( function () {
              beforeStateActions = [];
              resolve();
          });
      });
      // console.log(ret);

      // // clear the actions
      // return true
  }

  var waitStack = [];

  function enterWaitState() {
      waitStack.push('wait');
      setTimeout( function() {
          if(waitStack.length > 0) {
              document.getElementById('waitMask').style.display = 'inherit';
          }
      }, 100);
  }

  function exitWaitState() {
      waitStack.pop();
      if(waitStack.length === 0) {
          document.getElementById('waitMask').style.display = 'none';
      }
  }

  /**
   * implementation of $perAdminApp.stateAction()
   *
   * @private
   * @param name
   * @param target
   */
  function stateActionImpl(name, target) {
      enterWaitState();
      return new Promise( function (resolve, reject) {
          runBeforeStateActions(name).then( function () {
              try {
                  var stateAction = getStateAction(name);
                  var action = stateAction($perAdminApp, target);
                  Promise.resolve(action).then(function (result) {
                      exitWaitState();
                      if(result && result.startsWith('Uncaught (in promise')) {
                          notifyUserImpl('error', result);
                          reject();
                      } else {
                          resolve();
                      }
                  }).catch(function (error) {
                      exitWaitState();
                      notifyUserImpl('error', error);
                      reject();
                  });
              } catch(error) {
                  exitWaitState();
                  reject(error);
              }
          });
      })

  }

  /**
   * implementation of $perAdminApp.getNodeFrom()
   *
   * @private
   * @param node
   * @param path
   * @return {*}
   */
  function getNodeFromImpl(node, path) {
      return get(node, path)
  }

  /**
   * implementation of $perAdminApp.getNodeFromOrNull()
   *
   * @private
   * @param node
   * @param path
   * @return {*}
   */
  function getNodeFromOrNullImpl(node, path) {

      path = path.slice(1).split('/').reverse();
      while(path.length > 0) {
          var segment = path.pop();
          if(!node[segment]) {
              return null
          }
          node = node[segment];
      }
      return node
  }

  /**
   * implementation of $perAdminApp.getNodeFromWithDefault()
   *
   * @private
   * @param node
   * @param path
   * @param value
   * @return {*}
   */
  function getNodeFromWithDefaultImpl(node, path, value) {
      return get(node, path, value)
  }

  /**
   * implementation of $perAdminApp.findNodeFromPath()
   *
   * @private
   * @param node
   * @param path
   * @return {*}
   */
  function findNodeFromPathImpl(node, path) {
      if(node.path === path) { return node }
      if(node.children) {
          for(var i = 0; i < node.children.length; i++) {
              if(node.children[i].path === path) {
                  // found match
                  return node.children[i]
              } else if(path && path.indexOf(node.children[i].path) === 0) {
                  var res = findNodeFromPathImpl(node.children[i], path);
                  if(res) { return res }
              }
          }
      }
  }

  /**
   * implementation of $perAdminApp.notifyUser()
   *
   * @private
   * @param title
   * @param message
   * @param options
   */
  function notifyUserImpl(title, message, options) {
      set(view, '/state/notification/title', title);
      set(view, '/state/notification/message', message);
      $('#notifyUserModal').modal('open', options);
  }

  /**
   * implementation of $perAdminApp.toast()
   *
   * @private
   * @param message
   * @param className
   * @param displayLength
   * @param callback
   */
  function toastImpl(message, className, displayLength, callback) {
      var toast = Materialize.toast(message, displayLength, className, callback);
      toast.el.addEventListener('click', function () { return toast.remove(); });
  }

  /**
   * implementation of $perAdminApp.askUser()
   *
   * @private
   * @param title
   * @param message
   * @param options
   */
  function askUserImpl(title, message, options) {
      set(view, '/state/notification/title', title);
      set(view, '/state/notification/message', message);
      var yesText = options.yesText ? options.yesText : 'Yes';
      var noText = options.noText ? options.noText : 'No';
      set(view, '/state/notification/yesText', yesText);
      set(view, '/state/notification/noText', noText);
      options.dismissible = false;
      options.takeAction = false;
      options.complete = function() {
          var answer = $('#askUserModal').modal('getInstance').options.takeAction;
          if(answer && options.yes) {
              options.yes();
          } else if(options.no) {
              options.no();
          }
      };
      $('#askUserModal').modal(options);
      $('#askUserModal').modal('open');
  }

  /**
   * implementation of $perAdminApp.promptUser()
   *
   * @private
   * @param title
   * @param message
   * @param options
   */
  function promptUserImpl(title, message, options) {
      set(view, '/state/notification/title', title);
      set(view, '/state/notification/message', message);
      var yesText = options.yesText ? options.yesText : 'Ok';
      var noText = options.noText ? options.noText : 'Cancel';
      set(view, '/state/notification/yesText', yesText);
      set(view, '/state/notification/noText', noText);

      options.dismissible = false;
      options.takeAction = false;
      options.complete = function() {
          var answer = $('#promptUserModal').modal('getInstance').options.takeAction;
          var value = $('#promptUserModal').modal('getInstance').options.value;
          if(answer && options.yes) {
              options.yes(value);
          } else if(options.no) {
              options.no();
          }
      };
      $('#promptUserModal').modal(options);
      $('#promptUserModal').modal('open');
  }

  /**
   * implementation of $perAdminApp.isPreviewMode()
   *
   * @private
   * @return {boolean}
   */
  function isPreviewModeImpl() {
      var mode = getNodeFromOrNullImpl(view, '/state/tools/workspace/view');
      if(mode == null) { return false }
      return mode === 'preview'
  }

  /**
   * implementation of $perAdminApp.getOSBrowser()
   *
   * @private
   * @return {null}
   */
  function getOSBrowserImpl() {
      if(OSBrowser == null){
          switch(true) {
              case (window.navigator.userAgent.indexOf('Edge') != -1):
                  OSBrowser = 'edge';
                  break
              case (window.navigator.userAgent.indexOf('Mac') != -1):
                  OSBrowser = 'mac';
                  break
              case (window.navigator.userAgent.indexOf('Win') != -1):
                  OSBrowser = 'win';
                  break
              default:
                  OSBrowser = 'unknown';
          }
      }
      return OSBrowser
  }

  /**
   * implementation of $perAdminApp.registerExtension()
   *
   * @private
   * @param id
   * @param name
   */
  function registerExtensionImpl(id, name) {
      var extensionList = extensions[id];
      if(!extensionList) {
          extensions[id] = [name];
      } else {
          extensionList.push(name);
      }
  }

  /**
   * implementation of $perAdminApp.getExtension()
   *
   * @private
   * @param id
   * @return {*}
   */
  function getExtensionImpl(id) {
      return extensions[id]
  }

  function loadi18nImpl() {
      if(!view.state.language) {
          Vue.set(view.state, 'language', 'en');
      }
      api.populateI18N(view.state.language);
  }

  /**
   * helper function to call the backend every minute to keep the session alive
   */
  function sessionKeepAlive() {
      setInterval(function() {
          api.populateUser();
      },1000 * 60);
  }

  /**
   * @exports PerAdminApp
   * @namespace PerAdminApp
   *
   */
  var PerAdminApp = {

      eventBus: new Vue(),

      /**
       *
       * initialize the peregrine administation console with a view object
       *
       * @memberOf PerAdminApp
       * @method
       * @param {Object} perAdminAppView - the basic view object with all the root level nodes defined
       */
      init: function init(perAdminAppView) {
          view = perAdminAppView;
          api = new PerApi(new PerAdminImpl(PerAdminApp));
          sessionKeepAlive();
      },

      /**
       * returns a list of all loggers. This is mostly used by the debug console to display/manage the loggers
       *
       * @memberOf PerAdminApp
       * @method
       * @return {*}
       */
      getLoggers: function getLoggers() {
          return LoggerFactory.getLoggers()
      },

      /**
       *
       * get a named logger
       *
       * @memberOf PerAdminApp
       * @method
       * @param {string} name - the name of the logger to fetch, always returns a logger
       * @return {Logger}
       */
      getLogger: function getLogger(name) {
          if(!name) { return logger$2 }
          logger$2.fine('getting logger for',name);
          return LoggerFactory.logger(name)
      },

      /**
       * convenience method to get the api
       *
       * @memberOf PerAdminApp
       * @method
       * @return {*}
       */
      getApi: function getApi() {
          return api
      },

      /**
       * convenience method to get the view the admin console is based on
       *
       * @memberOf PerAdminApp
       * @method
       * @return {*}
       */
      getView: function getView() {
          return view
      },

      /**
       * load content (eg go to another page)
       *
       * @memberOf PerAdminApp
       * @method
       * @param {string} path - the path to load the content from
       * @param {boolean} firstTime - is vuejs already instantiated?
       */
      loadContent: function loadContent(path, firstTime) {
          if ( firstTime === void 0 ) firstTime = false;

          loadContentImpl(path, firstTime);
      },

      /**
       * loads a component by name. pcms only defines components with a camel cased name
       * cmp{component-name}. In order to keep the amount of components within the vue
       * scope as low as possible this method needs to be called with the component name
       * for vuejs to actually know about it.
       *
       * In the future this method may be used to lazy load the js file for a component
       *
       * @memberOf PerAdminApp
       * @method
       * @param name
       */
      loadComponent: function loadComponent(name) {
          loadComponentImpl(name);
      },

      /**
       * Finds a component by the given name.
       *
       * This is helpful if we need to find a component based on a name and execute a method
       * on the component (currently used by the editor before the editing dialog is presented
       * to alter the schema and before a save to trim/rewrite what we save into the backend)
       *
       * @memberOf PerAdminApp
       * @method
       * @param name
       */
      getComponentByName: function getComponentByName(name) {
          return getComponentByNameImpl(name)
      },

      /**
       * Used to handle admin user interface actions (also see admin-component-action).
       *
       * This method will search for a vue component of the current page starting at `component` and all its
       * parents for a component that contains a method with the name `command`. If no method can be found
       * in the parents then it will search the whole vue tree.
       *
       * Once a method is found it is called with command(me, target)
       *
       * `me` is the actual vue component, `target` is the target object provided to this method
       *
       * @memberOf PerAdminApp
       * @method
       * @param {Vue} component - the vue component calling this action
       * @param {string} command - the method(command) to find in the vue structure
       * @param {Object} target - data to handle the action
       */
      action: function action(component, command, target) {
          return actionImpl(component, command, target)
      },

      /**
       * trigger a registered state action with the provided target information
       *
       * @memberOf PerAdminApp
       * @method
       * @param name
       * @param target
       */
      stateAction: function stateAction(name, target) {
          return stateActionImpl(name, target)
      },

      /**
       * get a node from the given objec with the given path
       *
       * @memberOf PerAdminApp
       * @method
       * @param node
       * @param path
       */
      getNodeFrom: function getNodeFrom(node, path) {
          return getNodeFromImpl(node, path)
      },

      /**
       * get a node from the current view object with the given path
       *
       * @memberOf PerAdminApp
       * @method
       * @param path
       */
      getNodeFromView: function getNodeFromView(path) {
          return getNodeFromImpl(this.getView(), path)
      },

      /**
       * get a node from the current view object with the given path or null if not defined
       *
       * @memberOf PerAdminApp
       * @method
       * @param path
       */
      getNodeFromViewOrNull: function getNodeFromViewOrNull(path) {
          return getNodeFromOrNullImpl(this.getView(), path)
      },

      /**
       *
       * get a node from the current view object with the given path and set value as the
       * default if not yet defined
       *
       * @memberOf PerAdminApp
       * @method
       * @param path
       * @param value
       */
      getNodeFromViewWithDefault: function getNodeFromViewWithDefault(path, value) {
          return getNodeFromWithDefaultImpl(this.getView(), path, value)
      },

      /**
       *
       *  find a node with a property path that is equal to path. This also looks at all the
       *  children of the node.
       *
       * @memberOf PerAdminApp
       * @method
       * @param node
       * @param path
       */
      findNodeFromPath: function findNodeFromPath(node, path) {
          return findNodeFromPathImpl(node, path)
      },

      /**
       * get the backing application that has been created for peregrine (vue object)
       *
       * @memberOf PerAdminApp
       * @method
       * @return {*}
       */
      getApp: function getApp() {
          return app;
      },

      /**
       * modal with the given title and message to notify the user, calls the callback on close if provided
       *
       *
       * @memberOf PerAdminApp
       * @method
       * @param title
       * @param message
       * @param options
       */
      notifyUser: function notifyUser(title, message, options) {
          notifyUserImpl(title, message, options);
      },

      /**
       * toast with the given title and message to notify the user, calls the callback on close if provided
       *
       *
       * @memberOf PerAdminApp
       * @method
       * @param message
       * @param className
       * @param displayLength
       * @param callback
       */
      toast: function toast(message, className, displayLength, callback) {
          if ( displayLength === void 0 ) displayLength=4000;
          if ( callback === void 0 ) callback=null;

          toastImpl(message, className, displayLength, callback);
      },

      /**
       * modal with the given title and message to ask the user, calls the callback on close if provided
       *
       *
       * @memberOf PerAdminApp
       * @method
       * @param title
       * @param message
       * @param options
       */
      askUser: function askUser(title, message, options) {
          askUserImpl(title, message, options);
      },

      /**
       * modal with the given title and message to ask the user and a field for user input,
       * calls the callback on close if provided
       *
       *
       * @memberOf PerAdminApp
       * @method
       * @param title
       * @param message
       * @param options
       */
      promptUser: function promptUser(title, message, options) {
          promptUserImpl(title, message, options);
      },


      /**
       * returns true if the editor is currently in preview mode
       *
       * @memberOf PerAdminApp
       * @method
       */
      isPreviewMode: function isPreviewMode() {
          return isPreviewModeImpl()
      },

      /**
       * returns the OS? Used for some browser dependent code
       *
       * @memberOf PerAdminApp
       * @method
       */
      getOSBrowser: function getOSBrowser(){
          return getOSBrowserImpl()
      },


      /**
       * allows for an extension to be registered to implement custom UI code in the admin console
       *
       * @memberOf PerAdminApp
       * @method
       * @param id
       * @param name
       */
      registerExtension: function registerExtension(id, name) {
          registerExtensionImpl(id, name);
      },

      /**
       * entry point for front end to grab extensions to the UI
       *
       * @memberOf PerAdminApp
       * @method
       * @param id
       */
      getExtension: function getExtension(id) {
          return getExtensionImpl(id)
      },

      getExperiences: function getExperiences() {
          var experiences = this.getNodeFromView('/state/currentExperiences');
          if(!experiences) {
              Vue.set(this.getView().state, 'currentExperiences', []);
              return this.getNodeFromView('/state/currentExperiences')
          }
          return experiences
      },

      loadi18n: function loadi18n() {
          loadi18nImpl();
      },

      forceFullRedraw: function forceFullRedraw() {
          this.getView().adminPage = JSON.parse(JSON.stringify(this.getView().adminPage));
      },

      beforeStateAction: function beforeStateAction(fun) {
          beforeStateActionImpl(fun);
      },

      normalizeString: function normalizeString(val, separator) {
          if ( separator === void 0 ) separator='-';

          return val.normalize("NFD")
              .replace(/[\u0300-\u036f]/g, "")
              .replace(/\W/g, separator)
              .toLowerCase();
      }

  };

  return PerAdminApp;

}());
