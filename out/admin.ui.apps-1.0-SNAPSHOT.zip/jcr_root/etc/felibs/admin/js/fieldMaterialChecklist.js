var cmpFieldMaterialChecklist = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  var script = {
    mixins: [ VueFormGenerator.abstractField ], 
    data: function data() {
      return {
        isExpanded: false
      };
    },
    computed: {
      items: function items() {
        var values = this.schema.values;
        if (typeof(values) == "function") {
          return values.apply(this, [this.model, this.schema]);
        } else
          { return values; }
      },
      selectedCount: function selectedCount() {
        if (this.value)
          { return this.value.length; }

        return 0;
      }, 
      dropdownValue: function dropdownValue(){
        return this.selectedCount + ' selected'
      } 
    },
    methods: {
      getItemValue: function getItemValue(item) {
        if (_.isObject(item)){
          if (typeof this.schema["checklistOptions"] !== "undefined" && typeof this.schema["checklistOptions"]["value"] !== "undefined") {
            return item[this.schema.checklistOptions.value];
          } else {
            if (typeof item["value"] !== "undefined") {
              return item.value;
            } else {
              throw "`value` is not defined. If you want to use another key name, add a `value` property under `checklistOptions` in the schema. https://icebob.gitbooks.io/vueformgenerator/content/fields/checklist.html#checklist-field-with-object-values";
            }
          }
        } else {
          return item;
        }
      },
      getItemName: function getItemName(item) {
        if (_.isObject(item)){
          if (typeof this.schema["checklistOptions"] !== "undefined" && typeof this.schema["checklistOptions"]["name"] !== "undefined") {
            return item[this.schema.checklistOptions.name];
          } else {
            if (typeof item["name"] !== "undefined") {
              return item.name;
            } else {
              throw "`name` is not defined. If you want to use another key name, add a `name` property under `checklistOptions` in the schema. https://icebob.gitbooks.io/vueformgenerator/content/fields/checklist.html#checklist-field-with-object-values";
            }
          }
        } else {
          return item;
        }
      },
      isItemChecked: function isItemChecked(item) {
        return (this.value && this.value.indexOf(this.getItemValue(item)) != -1);
      },
      onChanged: function onChanged(event, item) {
        if (_.isNil(this.value) || !Array.isArray(this.value)){
          this.value = [];
        }

        if (event.target.checked) {
          // Note: If you modify this.value array, it won't trigger the `set` in computed field
          var arr = _.clone(this.value);
          arr.push(this.getItemValue(item));
          this.value = arr;
        } else {
          // Note: If you modify this.value array, it won't trigger the `set` in computed field
          var arr$1 = _.clone(this.value);
          arr$1.splice(this.value.indexOf(this.getItemValue(item)), 1);
          this.value = arr$1;
        }
      },
      onExpandCombo: function onExpandCombo() {
        this.isExpanded = !this.isExpanded;       
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", { staticClass: "wrap" }, [
      _vm.schema.listBox && !_vm.schema.preview
        ? _c(
            "ul",
            { staticClass: "check-list", attrs: { disabled: _vm.disabled } },
            _vm._l(_vm.items, function(item) {
              return _c("li", [
                _c("span", [
                  _c("input", {
                    attrs: {
                      id: "material-checklist-" + _vm.getItemName(item),
                      type: "checkbox",
                      disabled: _vm.disabled
                    },
                    domProps: { checked: _vm.isItemChecked(item) },
                    on: {
                      change: function($event) {
                        return _vm.onChanged($event, item)
                      }
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "label",
                    {
                      attrs: {
                        for: "material-checklist-" + _vm.getItemName(item)
                      }
                    },
                    [_vm._v(_vm._s(_vm.getItemName(item)))]
                  )
                ])
              ])
            }),
            0
          )
        : _vm._e(),
      _vm._v(" "),
      !_vm.schema.listBox && !_vm.schema.preview
        ? _c(
            "div",
            {
              staticClass: "select-wrapper checklist-dropdown",
              class: { expanded: _vm.isExpanded }
            },
            [
              _c("span", { staticClass: "caret" }),
              _vm._v(" "),
              _c("input", {
                ref: "selectInput",
                staticClass: "form-control select-dropdown",
                attrs: { type: "text" },
                domProps: { value: _vm.dropdownValue },
                on: { click: _vm.onExpandCombo }
              }),
              _vm._v(" "),
              _vm.isExpanded
                ? [
                    _c(
                      "ul",
                      { staticClass: "dropdown-content select-dropdown" },
                      [
                        _c("li", { staticClass: "disabled" }, [
                          _c("span", [_vm._v(_vm._s(_vm.dropdownValue))])
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.items, function(item) {
                          return _c(
                            "li",
                            { class: { "is-checked": _vm.isItemChecked(item) } },
                            [
                              _c("span", [
                                _c("input", {
                                  attrs: {
                                    id:
                                      "material-checklist-" +
                                      _vm.getItemName(item),
                                    type: "checkbox",
                                    disabled: _vm.disabled
                                  },
                                  domProps: { checked: _vm.isItemChecked(item) },
                                  on: {
                                    change: function($event) {
                                      return _vm.onChanged($event, item)
                                    }
                                  }
                                }),
                                _vm._v(" "),
                                _c(
                                  "label",
                                  {
                                    attrs: {
                                      for:
                                        "material-checklist-" +
                                        _vm.getItemName(item)
                                    }
                                  },
                                  [_vm._v(_vm._s(_vm.getItemName(item)))]
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _c("div", {
                      staticClass: "dropdown-bg",
                      on: { click: _vm.onExpandCombo }
                    })
                  ]
                : _vm._e()
            ],
            2
          )
        : _vm._e(),
      _vm._v(" "),
      _vm.schema.preview
        ? _c(
            "ul",
            { staticClass: "preview-list" },
            _vm._l(_vm.items, function(item) {
              return _vm.isItemChecked(item)
                ? _c("li", { staticClass: "preview-item" }, [
                    _vm._v(_vm._s(_vm.getItemName(item)))
                  ])
                : _vm._e()
            }),
            0
          )
        : _vm._e()
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
