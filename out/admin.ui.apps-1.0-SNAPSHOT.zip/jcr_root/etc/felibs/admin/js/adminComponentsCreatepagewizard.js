var cmpAdminComponentsCreatepagewizard = (function () {
    'use strict';

    var NodeNameValidation = {
        data: function data() {
            var this$1 = this;

            return {
                formmodel: {
                    path: $perAdminApp.getNodeFromView('/state/tools/pages'),
                    name: '',
                    title: '',
                    templatePath: '',
                    skeletonPagePath: ''
                },
                formOptions: {
                    validationErrorClass: "has-error",
                    validationSuccessClass: "has-success",
                    validateAfterChanged: true,
                    focusFirstField: true
                },
                nameChanged: false,
                nameSchema: {
                    fields: [
                        {
                            type: "input",
                            inputType: "text",
                            label: "Title",
                            model: "title",
                            required: true,
                            onChanged: function (model, newVal, oldVal, field) {
                              if(!this$1.nameChanged && this$1.uNodeType !== "Asset") {
                                  this$1.formmodel.name = $perAdminApp.normalizeString(newVal);
                              }
                            }
                        },
                        {
                            type: "input",
                            inputType: "text",
                            label: "Name",
                            model: "name",
                            required: true,
                            onChanged: function (model, newVal, oldVal, field) {
                                this$1.nameChanged = true;
                            },
                            validator: [this.nameAvailable, this.validPageName]
                        }
                    ]
                }
            }
        },
        methods: {
            validPageName: function(event) {
                var value = event;
                if (event && event instanceof Object && event.data) {
                    value = event.data;
                }
                if(!value || value.length === 0) {
                    return [this.$i18n('Name is required.')]
                }
                var regExMatch = /[^0-9a-zA-Z_-]/;
                var errorMsg = 'Page names may only contain letters, numbers, underscores, and dashes';
                if (this.uNodeType === "Asset") {
                    regExMatch = /[^0-9a-z.A-Z_-]/;
                    errorMsg = 'Assets names may only contain letters, numbers, underscores, and dashes';
                }

                if (value.match(regExMatch)) {
                    return [this.$i18n(errorMsg)]
                }
                return [];
            },
            nameAvailable: function(value) {
                if(!value || value.length === 0) {
                    return [this.$i18n('Name is required')]
                }
                if (this.node) {
                    var parent = this.node.path.replace("/"+this.node.name, "");
                    if ($perAdminApp.getApi().nameAvailable(value, parent)) {
                        return []
                    } else {
                        return [this.$i18n('Name is already in use')]
                    }
                } else {
                    var folder = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, this.formmodel.path);
                    for(var i = 0; i < folder.children.length; i++) {
                        if(folder.children[i].name === value) {
                            return [this.$i18n('Name is already in use.')]
                        }
                    }
                    return []
                }
            }
        }
    };

    //

    var script = {
        props: ['model'],
        data: function data() {
            return {
                formErrors: {
                    unselectedTemplateError: false
                },
                isLastStep: false
            }
        },
        created: function created() {
            //By default select the first item in the list;
            if(this.templates && this.templates.length > 0) {
                this.selectTemplate(this, this.templates[0].path);
            }
        },
        mixins: [NodeNameValidation],
        computed: {
            pageSchema: function pageSchema() {
                if(this.formmodel.templatePath !== '') {
                    var definitions = $perAdminApp.getNodeFromView('/admin/componentDefinitions');
                    if(definitions) {
                        // todo: component should be resolved through the template
                        var comp = 'pagerendervue-structure-page';
                        var def = $perAdminApp.getNodeFromView('/admin/componentDefinitions')[comp];
                        return def
                    }
                }
            },
            templates: function templates() {
                var templates = $perAdminApp.getNodeFromViewOrNull('/admin/templates/data');
                var siteRootParts = this.formmodel.path.split('/').slice(0,4);
                siteRootParts[3] = 'templates';
                var siteRoot = siteRootParts.join('/');
                return templates.filter( function (item) { return item.path.startsWith(siteRoot); })
            },
            skeletonPages: function skeletonPages() {
                var siteRoot = this.formmodel.path.split('/').slice(0,4).join('/') + '/skeleton-pages';
                var skeletonPageRoot = $perAdminApp.findNodeFromPath(this.$root.$data.admin.skeletonNodes, siteRoot);
                if(skeletonPageRoot) {
                    return skeletonPageRoot.children
                }
                return []
            }
        }
        ,
        methods: {
            selectTemplate: function selectTemplate(me, target){
                if(me === null) { me = this; }
                me.formmodel.templatePath = target;
                me.formmodel.skeletonPagePath = '';
                this.validateTabOne(me);
            },
            selectSkeletonPage: function selectSkeletonPage(me, target){
                if(me === null) { me = this; }
                me.formmodel.skeletonPagePath = target;
                me.formmodel.templatePath = '';
                this.validateTabOne(me);
            },
            isSelected: function isSelected(target) {
                return this.formmodel.templatePath === target || this.formmodel.skeletonPagePath === target
            },
            onComplete: function onComplete(edit) {
                if ( edit === void 0 ) edit=true;

                var payload = {
                    parent: this.formmodel.path,
                    name: this.formmodel.name,
                    template: this.formmodel.templatePath,
                    title: this.formmodel.title,
                    data: this.formmodel,
                    edit: edit
                };

                if(this.formmodel.templatePath) {
                    payload.template = this.formmodel.templatePath;
                    $perAdminApp.stateAction('createPage', payload);
                } else if (this.formmodel.skeletonPagePath) {
                    payload.skeletonPagePath = this.formmodel.skeletonPagePath;
                    $perAdminApp.stateAction('createPageFromSkeletonPage', payload);
                } else {
                    throw 'error creating page: no template or skeleton page given!'
                }
            },
            validateTabOne: function validateTabOne(me) {
                me.formErrors.unselectedTemplateError = ('' === '' + me.formmodel.templatePath && '' === '' + me.formmodel.skeletonPagePath);

                return !me.formErrors.unselectedTemplateError;
            },
            leaveTabOne: function leaveTabOne() {
                var this$1 = this;

                if('' !== ''+this.formmodel.templatePath) {
                    $perAdminApp.getApi().populateComponentDefinitionFromNode(this.formmodel.templatePath);
                }
                if('' !== ''+this.formmodel.skeletonPagePath) {
                    var skeletonPage = this.skeletonPages.find(function (bp) {
                        return bp.path == this$1.formmodel.skeletonPagePath
                    });
                    $perAdminApp.getApi().populateComponentDefinitionFromNode(skeletonPage.templatePath);
                }

                return this.validateTabOne(this);
            },
            leaveTabTwo: function leaveTabTwo() {
                var isValid = this.$refs.nameTab.validate();
                if (isValid) {
                    this.isLastStep = true;
                }
                return isValid
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        { staticClass: "container" },
        [
          _c(
            "form-wizard",
            {
              attrs: {
                title: "create a page",
                subtitle: "",
                "error-color": "#d32f2f",
                color: "#546e7a"
              },
              on: { "on-complete": _vm.onComplete }
            },
            [
              _c(
                "tab-content",
                {
                  attrs: {
                    title: "select template",
                    "before-change": _vm.leaveTabOne
                  }
                },
                [
                  _c("fieldset", { staticClass: "vue-form-generator" }, [
                    _c("div", { staticClass: "form-group required" }, [
                      _c("div", { staticClass: "row" }, [
                        _c("div", { staticClass: "col s6" }, [
                          _c("label", [_vm._v("Select Template")]),
                          _vm._v(" "),
                          _c(
                            "ul",
                            { staticClass: "collection" },
                            _vm._l(_vm.templates, function(template) {
                              return _c(
                                "li",
                                {
                                  key: template.path,
                                  staticClass: "collection-item",
                                  class: _vm.isSelected(template.path)
                                    ? "active"
                                    : "",
                                  on: {
                                    click: function($event) {
                                      $event.stopPropagation();
                                      $event.preventDefault();
                                      return _vm.selectTemplate(null, template.path)
                                    }
                                  }
                                },
                                [
                                  _c("admin-components-action", {
                                    attrs: {
                                      model: {
                                        command: "selectTemplate",
                                        target: template.path,
                                        title: template.title
                                          ? template.title
                                          : template.name
                                      }
                                    }
                                  })
                                ],
                                1
                              )
                            }),
                            0
                          ),
                          _vm._v(" "),
                          _vm.skeletonPages && _vm.skeletonPages.length > 0
                            ? _c("div", [
                                _vm._v("\n                                OR"),
                                _c("br"),
                                _vm._v(" "),
                                _c("label", [_vm._v("Select Skeleton-Page")]),
                                _vm._v(" "),
                                _c(
                                  "ul",
                                  { staticClass: "collection" },
                                  _vm._l(_vm.skeletonPages, function(skeletonPage) {
                                    return _c(
                                      "li",
                                      {
                                        key: skeletonPage.path,
                                        staticClass: "collection-item",
                                        class: _vm.isSelected(skeletonPage.path)
                                          ? "active"
                                          : "",
                                        on: {
                                          click: function($event) {
                                            $event.stopPropagation();
                                            $event.preventDefault();
                                            return _vm.selectSkeletonPage(
                                              null,
                                              skeletonPage.path
                                            )
                                          }
                                        }
                                      },
                                      [
                                        _c("admin-components-action", {
                                          attrs: {
                                            model: {
                                              command: "selectSkeletonPage",
                                              target: skeletonPage.path,
                                              title: skeletonPage.name
                                            }
                                          }
                                        })
                                      ],
                                      1
                                    )
                                  }),
                                  0
                                )
                              ])
                            : _vm._e(),
                          _vm._v(" "),
                          _vm.formErrors.unselectedTemplateError
                            ? _c("div", { staticClass: "errors" }, [
                                _c("span", { attrs: { "track-by": "index" } }, [
                                  _vm._v("selection required")
                                ])
                              ])
                            : _vm._e()
                        ]),
                        _vm._v(" "),
                        _c("div", { staticClass: "col s6" }, [
                          _c("label", [_vm._v("Preview")]),
                          _vm._v(" "),
                          _c("div", { staticClass: "iframe-container" }, [
                            _vm.formmodel.skeletonPagePath
                              ? _c("iframe", {
                                  attrs: {
                                    src: _vm.formmodel.skeletonPagePath + ".html",
                                    "data-per-mode": "preview"
                                  }
                                })
                              : _vm._e(),
                            _vm._v(" "),
                            _vm.formmodel.templatePath
                              ? _c("iframe", {
                                  attrs: {
                                    src: _vm.formmodel.templatePath + ".html",
                                    "data-per-mode": "preview"
                                  }
                                })
                              : _vm._e()
                          ])
                        ])
                      ])
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "tab-content",
                {
                  attrs: { title: "choose name", "before-change": _vm.leaveTabTwo }
                },
                [
                  _c("vue-form-generator", {
                    ref: "nameTab",
                    attrs: {
                      model: _vm.formmodel,
                      schema: _vm.nameSchema,
                      options: _vm.formOptions
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c("tab-content", { attrs: { title: "verify" } }, [
                _vm._v(
                  "\n            Creating Page `" +
                    _vm._s(_vm.formmodel.name) +
                    "` from\n            "
                ),
                _vm.formmodel.templatePath
                  ? _c("span", [
                      _vm._v(
                        "template `" + _vm._s(_vm.formmodel.templatePath) + "`"
                      )
                    ])
                  : _vm.formmodel.skeletonPagePath
                  ? _c("span", [
                      _vm._v(
                        "skeleton page `" +
                          _vm._s(_vm.formmodel.skeletonPagePath) +
                          "`"
                      )
                    ])
                  : _vm._e()
              ]),
              _vm._v(" "),
              _vm.isLastStep
                ? _c(
                    "span",
                    {
                      attrs: { slot: "custom-buttons-right", role: "button" },
                      slot: "custom-buttons-right"
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "wizard-btn outline",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              return _vm.onComplete(false)
                            }
                          }
                        },
                        [_vm._v("\n                Finish\n           ")]
                      )
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "span",
                {
                  attrs: { slot: "finish", role: "button", tabindex: "0" },
                  slot: "finish"
                },
                [
                  _c(
                    "button",
                    {
                      staticClass: "wizard-btn finish",
                      attrs: { tabindex: "-1", type: "button" }
                    },
                    [_vm._v("\n            Finish and Edit!\n            ")]
                  )
                ]
              )
            ],
            1
          )
        ],
        1
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-d58ad3f8_0", { source: "\n.iframe-container {\n    overflow: hidden;\n    padding-top: 56.25%;\n    position: relative;\n}\n.iframe-container iframe {\n    border: 0;\n    height: 200%;\n    left: 0;\n    position: absolute;\n    top: 0;\n    width: 200%;\n    transform: scale(0.5) translate(-50%, -50%);\n}\n\n\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/createpagewizard/template.vue"],"names":[],"mappings":";AA4NA;IACA,gBAAA;IACA,mBAAA;IACA,kBAAA;AACA;AAEA;IACA,SAAA;IACA,YAAA;IACA,OAAA;IACA,kBAAA;IACA,MAAA;IACA,WAAA;IACA,2CAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n\n  http://www.apache.org/licenses/LICENSE-2.0\n\n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n<div class=\"container\">\n    <form-wizard\n      v-bind:title=\"'create a page'\"\n      v-bind:subtitle=\"''\" @on-complete=\"onComplete\"\n      error-color=\"#d32f2f\"\n      color=\"#546e7a\">\n        <tab-content title=\"select template\" :before-change=\"leaveTabOne\">\n            <fieldset class=\"vue-form-generator\">\n                <div class=\"form-group required\">\n                    <div class=\"row\">\n                        <div class=\"col s6\">\n                            <label>Select Template</label>\n                            <ul class=\"collection\">\n                                <li class=\"collection-item\"\n                                    v-for=\"template in templates\"\n                                    v-on:click.stop.prevent=\"selectTemplate(null, template.path)\"\n                                    v-bind:class=\"isSelected(template.path) ? 'active' : ''\"\n                                    v-bind:key=\"template.path\">\n                                    <admin-components-action v-bind:model=\"{ command: 'selectTemplate', target: template.path, title: template.title ? template.title : template.name }\"></admin-components-action>\n                                </li>\n                            </ul>\n                            <div v-if=\"skeletonPages && skeletonPages.length > 0\">\n                                OR<br/>\n                                <label>Select Skeleton-Page</label>\n                                <ul class=\"collection\">\n                                    <li class=\"collection-item\"\n                                        v-for=\"skeletonPage in skeletonPages\"\n                                        v-on:click.stop.prevent=\"selectSkeletonPage(null, skeletonPage.path)\"\n                                        v-bind:class=\"isSelected(skeletonPage.path) ? 'active' : ''\"\n                                        v-bind:key=\"skeletonPage.path\">\n                                        <admin-components-action v-bind:model=\"{ command: 'selectSkeletonPage', target: skeletonPage.path, title: skeletonPage.name }\"></admin-components-action>\n                                    </li>\n                                </ul>\n                            </div>\n                            <div v-if=\"formErrors.unselectedTemplateError\" class=\"errors\">\n                                <span track-by=\"index\">selection required</span>\n                            </div>\n                        </div>\n                        <div class=\"col s6\">\n                            <label>Preview</label>\n                            <div class=\"iframe-container\">\n                                <iframe v-if=\"formmodel.skeletonPagePath\"\n                                        v-bind:src=\"formmodel.skeletonPagePath + '.html'\" data-per-mode=\"preview\">\n                                </iframe>\n                                <iframe v-if=\"formmodel.templatePath\"\n                                        v-bind:src=\"formmodel.templatePath + '.html'\" data-per-mode=\"preview\">\n                                </iframe>\n                            </div>\n                        </div>\n                    </div>\n                </div>\n            </fieldset>\n        </tab-content>\n        <tab-content title=\"choose name\" :before-change=\"leaveTabTwo\">\n            <vue-form-generator\n              :model   =\"formmodel\"\n              :schema  =\"nameSchema\"\n              :options =\"formOptions\"\n              ref      =\"nameTab\">\n            </vue-form-generator>\n        </tab-content>\n        <tab-content title=\"verify\">\n            Creating Page `{{formmodel.name}}` from\n            <span v-if=\"formmodel.templatePath\">template `{{formmodel.templatePath}}`</span>\n            <span v-else-if=\"formmodel.skeletonPagePath\">skeleton page `{{formmodel.skeletonPagePath}}`</span>\n        </tab-content>\n        <span v-if=\"isLastStep\" slot=\"custom-buttons-right\" role=\"button\">\n            <button type=\"button\" class=\"wizard-btn outline\" @click=\"onComplete(false)\">\n                Finish\n           </button>\n        </span>\n        <span slot=\"finish\" role=\"button\" tabindex=\"0\">\n            <button tabindex=\"-1\" type=\"button\" class=\"wizard-btn finish\">\n            Finish and Edit!\n            </button>\n        </span>\n    </form-wizard>\n</div>\n</template>\n\n<script>\n    import NodeNameValidation from '../../../../../../js/mixins/NodeNameValidation'\n\n    export default {\n        props: ['model'],\n        data() {\n            return {\n                formErrors: {\n                    unselectedTemplateError: false\n                },\n                isLastStep: false\n            }\n        },\n        created() {\n            //By default select the first item in the list;\n            if(this.templates && this.templates.length > 0) {\n                this.selectTemplate(this, this.templates[0].path);\n            }\n        },\n        mixins: [NodeNameValidation],\n        computed: {\n            pageSchema() {\n                if(this.formmodel.templatePath !== '') {\n                    const definitions = $perAdminApp.getNodeFromView('/admin/componentDefinitions')\n                    if(definitions) {\n                        // todo: component should be resolved through the template\n                        const comp = 'pagerendervue-structure-page'\n                        const def = $perAdminApp.getNodeFromView('/admin/componentDefinitions')[comp]\n                        return def\n                    }\n                }\n            },\n            templates() {\n                const templates = $perAdminApp.getNodeFromViewOrNull('/admin/templates/data')\n                const siteRootParts = this.formmodel.path.split('/').slice(0,4)\n                siteRootParts[3] = 'templates'\n                const siteRoot = siteRootParts.join('/')\n                return templates.filter( (item) => item.path.startsWith(siteRoot))\n            },\n            skeletonPages() {\n                const siteRoot = this.formmodel.path.split('/').slice(0,4).join('/') + '/skeleton-pages'\n                const skeletonPageRoot = $perAdminApp.findNodeFromPath(this.$root.$data.admin.skeletonNodes, siteRoot)\n                if(skeletonPageRoot) {\n                    return skeletonPageRoot.children\n                }\n                return []\n            }\n        }\n        ,\n        methods: {\n            selectTemplate(me, target){\n                if(me === null) me = this\n                me.formmodel.templatePath = target\n                me.formmodel.skeletonPagePath = ''\n                this.validateTabOne(me);\n            },\n            selectSkeletonPage(me, target){\n                if(me === null) me = this\n                me.formmodel.skeletonPagePath = target\n                me.formmodel.templatePath = ''\n                this.validateTabOne(me);\n            },\n            isSelected(target) {\n                return this.formmodel.templatePath === target || this.formmodel.skeletonPagePath === target\n            },\n            onComplete(edit=true) {\n                const payload = {\n                    parent: this.formmodel.path,\n                    name: this.formmodel.name,\n                    template: this.formmodel.templatePath,\n                    title: this.formmodel.title,\n                    data: this.formmodel,\n                    edit\n                }\n\n                if(this.formmodel.templatePath) {\n                    payload.template = this.formmodel.templatePath\n                    $perAdminApp.stateAction('createPage', payload)\n                } else if (this.formmodel.skeletonPagePath) {\n                    payload.skeletonPagePath = this.formmodel.skeletonPagePath\n                    $perAdminApp.stateAction('createPageFromSkeletonPage', payload)\n                } else {\n                    throw 'error creating page: no template or skeleton page given!'\n                }\n            },\n            validateTabOne(me) {\n                me.formErrors.unselectedTemplateError = ('' === '' + me.formmodel.templatePath && '' === '' + me.formmodel.skeletonPagePath);\n\n                return !me.formErrors.unselectedTemplateError;\n            },\n            leaveTabOne() {\n                if('' !== ''+this.formmodel.templatePath) {\n                    $perAdminApp.getApi().populateComponentDefinitionFromNode(this.formmodel.templatePath)\n                }\n                if('' !== ''+this.formmodel.skeletonPagePath) {\n                    const skeletonPage = this.skeletonPages.find(bp => {\n                        return bp.path == this.formmodel.skeletonPagePath\n                    })\n                    $perAdminApp.getApi().populateComponentDefinitionFromNode(skeletonPage.templatePath)\n                }\n\n                return this.validateTabOne(this);\n            },\n            leaveTabTwo() {\n                const isValid = this.$refs.nameTab.validate()\n                if (isValid) {\n                    this.isLastStep = true\n                }\n                return isValid\n            }\n        }\n    }\n</script>\n\n<style>\n.iframe-container {\n    overflow: hidden;\n    padding-top: 56.25%;\n    position: relative;\n}\n\n.iframe-container iframe {\n    border: 0;\n    height: 200%;\n    left: 0;\n    position: absolute;\n    top: 0;\n    width: 200%;\n    transform: scale(0.5) translate(-50%, -50%);\n}\n\n\n</style>\n"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
