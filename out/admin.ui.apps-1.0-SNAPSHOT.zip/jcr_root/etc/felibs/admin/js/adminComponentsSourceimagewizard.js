var cmpAdminComponentsSourceimagewizard = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //


    var script = {
        props: ['model'],

        beforeCreate: function beforeCreate() {
            var perState = $perAdminApp.getNodeFromViewOrNull('/state'); 
            perState.imageSearch = perState.imageSearch || {
                results: null,
                totalHits: null,
                scrollPos: null,
                currentPage: null,
                input: null,
                numPages: null
            };
        },

        data: function data() {
            return {
                state: $perAdminApp.getNodeFromViewOrNull('/state/imageSearch'),
                viewing: null,
                uploading: null,
                containerWidth: null,
                columns: null,
                itemsPerPage: null,
                endOfResults: false,
                loading: false
            }
        },

        computed: {
            tags: function tags() { return this.viewing.tags.split(', ') }
        },

        mounted: function mounted() {
            this.containerWidth = this.$refs.wrapper.offsetWidth;
            this.columns = Math.floor(this.containerWidth / 160);
            this.itemsPerPage = this.columns * 5;
        },

        methods: {

            requestImages: function requestImages() {
                var this$1 = this;

                var API_KEY = '5575459-c51347c999199b9273f4544d4';
                var URL = "https://pixabay.com/api/?key=" + API_KEY+
                            "&page=" + (this.state.currentPage)+
                            "&per_page=" + (this.itemsPerPage)+
                            "&q=" + (encodeURIComponent(this.state.input));
                $.getJSON( URL, function (data) {
                    this$1.state.results = this$1.state.results.concat(data.hits);
                    this$1.state.totalHits = data.totalHits;
                    this$1.state.numPages = Math.ceil(data.totalHits/this$1.itemsPerPage);
                    this$1.loading = false;
                });
            },

            search: function search() {
                this.viewing = null;
                this.endOfResults = false;
                this.state.currentPage = 1;
                this.state.results = [];
                this.loading = true;
                this.requestImages();
            },

            handleScroll: function handleScroll(e) {
                if (!this.loading) { 
                    var scrollPos = e.target.scrollTop + e.target.offsetHeight;
                    var fullHeight    = e.target.scrollHeight;
                    var distanceLeft = fullHeight - scrollPos;
                    //Load the next page when we near the bottom of the last
                    if( distanceLeft < e.target.offsetHeight * 0.25   ) {
                        this.loadNextPage();
                    }
                }
            },

            loadNextPage: function loadNextPage() {
                if (this.state.currentPage < this.state.numPages) {
                    this.state.currentPage++;
                    this.loading = true;
                    this.requestImages();
                }
                else {
                    this.endOfResults = true;
                }

            },

            select: function select(index) {
                this.uploading = null;
                this.viewing = this.state.results[index];
                this.viewing.index = index;
                this.viewing.name = this.viewing.previewURL.split('/').pop();
                if (index >= this.state.results.length - 1) { this.loadNextPage(); }
            },
            deSelect: function deSelect() {
                this.viewing = null;
            },

            uploadProgress: function uploadProgress(percent) {
                this.uploading = percent;
            },

            addImage: function addImage(item, name) {
                var this$1 = this;

                this.uploading = 0;
                $perAdminApp.stateAction('fetchExternalAsset', { 
                    url: item.webformatURL, 
                    path: $perAdminApp.getNodeFromView('/state/tools/assets'), 
                    name: name,
                    config: { onUploadProgress: function (ev) { return this$1.uploadProgress(Math.floor((ev.loaded * 100) / ev.total)); } },
                    error: function () { return this$1.uploading = null; }
                });
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        {
          ref: "wrapper",
          class: [
            "sourceimagewizard",
            "container",
            { "initial-search": !_vm.state.results }
          ]
        },
        [
          _c("div", { staticClass: "search-bar" }, [
            _vm.viewing
              ? _c(
                  "button",
                  {
                    staticClass: "back-to-grid btn-flat",
                    on: {
                      click: function($event) {
                        $event.preventDefault();
                        $event.stopPropagation();
                        return _vm.deSelect()
                      }
                    }
                  },
                  [
                    _c("i", { staticClass: "material-icons" }, [_vm._v("grid_on")]),
                    _c("span", [_vm._v("back to results")])
                  ]
                )
              : _vm._e(),
            _vm._v(" "),
            _c(
              "form",
              {
                class: ["image-search", { previewing: _vm.viewing }],
                on: {
                  submit: function($event) {
                    $event.preventDefault();
                    return _vm.search()
                  }
                }
              },
              [
                _c("input", {
                  directives: [
                    {
                      name: "model",
                      rawName: "v-model",
                      value: _vm.state.input,
                      expression: "state.input"
                    }
                  ],
                  attrs: {
                    type: "text",
                    placeholder: _vm.$i18n("searchImageAsset"),
                    tabindex: "1",
                    autofocus: ""
                  },
                  domProps: { value: _vm.state.input },
                  on: {
                    input: function($event) {
                      if ($event.target.composing) {
                        return
                      }
                      _vm.$set(_vm.state, "input", $event.target.value);
                    }
                  }
                }),
                _vm._v(" "),
                _c(
                  "button",
                  {
                    staticClass: "image-search-submit",
                    attrs: {
                      type: "submit",
                      title: _vm.$i18n("search"),
                      class: "image-search-submit"
                    }
                  },
                  [_c("i", { staticClass: "material-icons" }, [_vm._v("search")])]
                )
              ]
            )
          ]),
          _vm._v(" "),
          !_vm.state.results
            ? _c("div", { staticClass: "center" }, [
                _c("span", [_vm._v(_vm._s(_vm.$i18n("pixabaySearchHint")) + "!")])
              ])
            : _vm._e(),
          _vm._v(" "),
          _vm.state.results
            ? _c("div", { staticClass: "search-content" }, [
                _vm.state.results.length < 1 && !_vm.loading
                  ? _c("span", { staticClass: "no-results" }, [
                      _vm._v(
                        "No images found for '" + _vm._s(_vm.state.input) + "'"
                      )
                    ])
                  : _vm.viewing
                  ? _c("div", { staticClass: "image-preview" }, [
                      _c("div", { staticClass: "image-row" }, [
                        _c(
                          "button",
                          {
                            class: [
                              "btn-flat",
                              "btn-large",
                              { disabled: _vm.viewing.index == 0 }
                            ],
                            on: {
                              click: function($event) {
                                $event.preventDefault();
                                $event.stopPropagation();
                                return _vm.select(_vm.viewing.index - 1)
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("keyboard_arrow_left")
                            ])
                          ]
                        ),
                        _vm._v(" "),
                        _c("div", { staticClass: "image-container" }, [
                          _c("img", { attrs: { src: _vm.viewing.webformatURL } }),
                          _vm._v(" "),
                          _vm.uploading
                            ? _c("div", { staticClass: "progress" }, [
                                _c("div", {
                                  staticClass: "determinate",
                                  style: { width: _vm.uploading + "%" }
                                })
                              ])
                            : _c(
                                "form",
                                {
                                  staticClass: "image-rename-form",
                                  on: {
                                    submit: function($event) {
                                      $event.preventDefault();
                                      return _vm.addImage(
                                        _vm.state.results[_vm.viewing.index],
                                        _vm.viewing.name
                                      )
                                    }
                                  }
                                },
                                [
                                  _c("input", {
                                    directives: [
                                      {
                                        name: "model",
                                        rawName: "v-model",
                                        value: _vm.viewing.name,
                                        expression: "viewing.name"
                                      }
                                    ],
                                    attrs: { type: "text", autofocus: "" },
                                    domProps: { value: _vm.viewing.name },
                                    on: {
                                      input: function($event) {
                                        if ($event.target.composing) {
                                          return
                                        }
                                        _vm.$set(
                                          _vm.viewing,
                                          "name",
                                          $event.target.value
                                        );
                                      }
                                    }
                                  }),
                                  _vm._v(" "),
                                  _vm._m(0)
                                ]
                              )
                        ]),
                        _vm._v(" "),
                        _c(
                          "button",
                          {
                            class: [
                              "btn-flat",
                              "btn-large",
                              {
                                disabled:
                                  _vm.viewing.index == _vm.state.results.length - 1
                              }
                            ],
                            on: {
                              click: function($event) {
                                $event.preventDefault();
                                $event.stopPropagation();
                                return _vm.select(_vm.viewing.index + 1)
                              }
                            }
                          },
                          [
                            _c("i", { staticClass: "material-icons" }, [
                              _vm._v("keyboard_arrow_right")
                            ])
                          ]
                        )
                      ]),
                      _vm._v(" "),
                      _c("div", { staticClass: "image-preview-details" }, [
                        _c("span", { staticClass: "resolution" }, [
                          _vm._v(
                            _vm._s(_vm.viewing.webformatWidth) +
                              " x " +
                              _vm._s(_vm.viewing.webformatHeight)
                          )
                        ]),
                        _vm._v(" "),
                        _c(
                          "div",
                          { staticClass: "chipcontainer" },
                          _vm._l(_vm.tags, function(tag) {
                            return _c("div", { staticClass: "chip" }, [
                              _vm._v(_vm._s(tag))
                            ])
                          }),
                          0
                        )
                      ])
                    ])
                  : _c(
                      "div",
                      {
                        staticClass: "image-results",
                        on: { scroll: _vm.handleScroll }
                      },
                      [
                        _vm._l(_vm.state.results, function(item, i) {
                          return _c("div", {
                            staticClass: "image-item hoverable",
                            style: {
                              backgroundImage: "url('" + item.previewURL + "')"
                            },
                            on: {
                              click: function($event) {
                                $event.stopPropagation();
                                return _vm.select(i)
                              }
                            }
                          })
                        }),
                        _vm._v(" "),
                        _c("div", { staticClass: "image-results-status" }, [
                          _vm.endOfResults
                            ? _c("div", { staticClass: "col s12" }, [
                                _c("span", [_vm._v("end of results")])
                              ])
                            : _c(
                                "div",
                                { staticClass: "preloader-wrapper small active" },
                                [_vm._m(1)]
                              )
                        ])
                      ],
                      2
                    )
              ])
            : _vm._e()
        ]
      )
    };
    var __vue_staticRenderFns__ = [
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c(
          "button",
          {
            staticClass: "btn waves-effect waves-light",
            attrs: { type: "submit" }
          },
          [_c("i", { staticClass: "material-icons" }, [_vm._v("save")])]
        )
      },
      function() {
        var _vm = this;
        var _h = _vm.$createElement;
        var _c = _vm._self._c || _h;
        return _c("div", { staticClass: "spinner-layer spinner-green-only" }, [
          _c("div", { staticClass: "circle-clipper left" }, [
            _c("div", { staticClass: "circle" })
          ]),
          _c("div", { staticClass: "gap-patch" }, [
            _c("div", { staticClass: "circle" })
          ]),
          _c("div", { staticClass: "circle-clipper right" }, [
            _c("div", { staticClass: "circle" })
          ])
        ])
      }
    ];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
