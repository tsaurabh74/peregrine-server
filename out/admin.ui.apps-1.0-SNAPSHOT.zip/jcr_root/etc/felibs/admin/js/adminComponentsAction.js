var cmpAdminComponentsAction = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

        /**
         * admin-components-action can be used to trigger a UI action in the app. This component
         * renders either a basic link or an icon. The component supports rendering of a default slot
         *
         * on click of this component triggers a $perAdminApp.action() and tries to find a vue component
         * in the parents that defines a method with the name of the command. If not found in the parent
         * hierarchy then the complete vue tree will be searched for the action
         *
         * @example <caption>simple use case</caption>
         * <admin-components-action :model="{ action: 'save', target: item, title: 'save' }"></admin-components-action>
         *
         * @example <caption>icon use case</caption>
         * <admin-components-action :model="{ action: 'save', target: item, type: 'icon', title: 'open' }"></admin-components-action>
         *
         * @example <caption>slot</caption>
         * <admin-components-action :model="{ action: 'save', target: item }">
         *     <div>hello world</div>
         * </admin-components-action>
         *
         * @module admin/components/action
         * @param {Object} model - the model for this component
         * @param {string} model.action - the name of the action
         * @param {Object} model.target - an object containing all the information for this action
         * @param {string} model.tooltipTitle - used for tooltip/hover
         * @param {string} model.title - the title to be displayed
         * @param {string} model.type - if type === icon the action will be rendered as an icon
         * @param {string} model.classes - additional classes to be added to the action
         *
         */
        var script = {
        props: {
            model: Object,
            tag: {
                type: String,
                default: 'span'
            }
        },
        data: function() {
            return {
                clickCount: 0,
                clickTimer: null,
                dblClickDelay: 200
            };
        },
        computed: {

            /**
             *
             * checks if this action is currently selected using the model.stateFrom and model.stateFromDefault
             * properties of the action
             *
             * @return {boolean}
             *
             */
            isSelected: function isSelected() {
                if(!this.model.stateFrom) { return false }
                var currentState = $perAdminApp.getNodeFromViewOrNull(this.model.stateFrom);
                if(!currentState) {
                    if(this.model.stateFromDefault) {
                        return true
                    }
                } else if(currentState === this.model.target) {
                    return true
                }
                return false
            },

            /**
             *
             * returns the display title for this action. Logs an error if no title and no tooltipTitle
             * is defined in the model
             *
             * @method computed:title
             * @return {string} - the display title
             *
             */
            title: function title() {
                if(this.model.tooltipTitle) {
                    if (this.model.experiences) {
                        return this.$exp(this.model, 'tooltipTitle', this.model.tooltipTitle);
                    }
                    return this.model.tooltipTitle;
                }
                if(this.model.title) {
                    if (this.model.experiences) {
                        return this.$exp(this.model, 'title', this.model.title);
                    }
                    return this.model.title
                }
                /* eslint-disable no-console */
                console.error('missing alt', this.model.command, this.model.path);
                /* eslint-enable no-console */
                return this.model.command
            },
            target: function target() {
                if(this.model.target && typeof this.model.target === 'string') {
                    return this.model.target
                }
                if(this.model.target && typeof this.model.target.path) {
                    return this.model.target.path
                }
                return '#'
            },
            targetHtml: function targetHtml() {
                if(this.target.indexOf('.html') >= 0) { return this.target }
                return this.target !== '#' ? this.target + '.html' : '#'
            },
            visible: function visible() {
                if(this.model.visibility) {
                    return exprEval.Parser.evaluate( this.model.visibility, $perAdminApp.getView() );
                } else {
                    return true;
                }
            }
        },
        methods: {

            /**
             *  triggers the action specified by the model
             *
             *  @method methods:action
             * @param {event} e - event
             */
            action: function(e) {
                $perAdminApp.action(this, this.model.command, this.model.target);
            },
            dblClickAction: function(e) {
                $perAdminApp.action(this, this.model.dblClickCommand, this.model.dblClickTarget);
            },
            onClick: function(e) {
                var this$1 = this;

                if(!this.model.dblClickCommand) {
                    this.action(e);
                } else {
                    this.clickCount++;
                    if(this.clickCount === 1) {
                        this.timer = setTimeout(function () {
                            this$1.clickCount = 0;
                            this$1.action(e);
                        }, this.dblClickDelay);
                    } else {
                        clearTimeout(this.timer);
                        this.dblClickAction(e);
                        this.clickCount = 0;
                    }
                }
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _vm.visible
        ? _c(_vm.tag, { tag: "component" }, [
            !_vm.model.type
              ? _c(
                  "a",
                  {
                    class: _vm.model.classes,
                    attrs: { href: _vm.targetHtml, title: _vm.title },
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.onClick($event)
                      }
                    }
                  },
                  [
                    _vm._v("\n        " + _vm._s(_vm.model.title) + "\n        "),
                    _vm._t("default")
                  ],
                  2
                )
              : _vm._e(),
            _vm._v(" "),
            _vm.model.type === "icon"
              ? _c(
                  "a",
                  {
                    staticClass: "btn-floating waves-effect waves-light",
                    class: _vm.model.classes,
                    attrs: { title: _vm.title, href: _vm.target },
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.action($event)
                      }
                    }
                  },
                  [
                    _c(
                      "i",
                      {
                        staticClass: "material-icons",
                        class: _vm.isSelected ? "actionSelected" : ""
                      },
                      [
                        _vm._v(
                          "\n            " +
                            _vm._s(
                              _vm.model.icon ? _vm.model.icon : _vm.model.title
                            ) +
                            "\n            "
                        ),
                        _vm._t("default")
                      ],
                      2
                    )
                  ]
                )
              : _vm._e()
          ])
        : _vm._e()
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-58ca5b95_0", { source: "\n.actionSelected {\n    background-color: white !important;\n    color: #37474f !important;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/action/template.vue"],"names":[],"mappings":";AA0MA;IACA,kCAAA;IACA,yBAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->   \n<template>\n    <component :is=\"tag\" v-if=\"visible\">\n        <a \n            v-if                    = \"!model.type\"\n            v-bind:href             = \"targetHtml\"\n            v-bind:title            = \"title\"\n            v-on:click.stop.prevent = \"onClick\"\n            v-bind:class            = \"model.classes\">\n            {{model.title}}\n            <slot></slot>\n        </a>\n        <a \n            v-if                    = \"model.type === 'icon'\" \n            v-bind:title            = \"title\"\n            v-bind:href             = \"target\" \n            v-on:click.stop.prevent = \"action\" \n            class                   = \"btn-floating waves-effect waves-light\" \n            v-bind:class            = \"model.classes\">\n            <i class=\"material-icons\" v-bind:class=\"isSelected ? 'actionSelected' : ''\">\n                {{model.icon ? model.icon : model.title}}\n                <slot></slot>\n            </i>\n        </a>\n    </component>\n</template>\n\n<script>\n    /**\n     * admin-components-action can be used to trigger a UI action in the app. This component\n     * renders either a basic link or an icon. The component supports rendering of a default slot\n     *\n     * on click of this component triggers a $perAdminApp.action() and tries to find a vue component\n     * in the parents that defines a method with the name of the command. If not found in the parent\n     * hierarchy then the complete vue tree will be searched for the action\n     *\n     * @example <caption>simple use case</caption>\n     * <admin-components-action :model=\"{ action: 'save', target: item, title: 'save' }\"></admin-components-action>\n     *\n     * @example <caption>icon use case</caption>\n     * <admin-components-action :model=\"{ action: 'save', target: item, type: 'icon', title: 'open' }\"></admin-components-action>\n     *\n     * @example <caption>slot</caption>\n     * <admin-components-action :model=\"{ action: 'save', target: item }\">\n     *     <div>hello world</div>\n     * </admin-components-action>\n     *\n     * @module admin/components/action\n     * @param {Object} model - the model for this component\n     * @param {string} model.action - the name of the action\n     * @param {Object} model.target - an object containing all the information for this action\n     * @param {string} model.tooltipTitle - used for tooltip/hover\n     * @param {string} model.title - the title to be displayed\n     * @param {string} model.type - if type === icon the action will be rendered as an icon\n     * @param {string} model.classes - additional classes to be added to the action\n     *\n     */\n    export default {\n    props: {\n        model: Object,\n        tag: {\n            type: String,\n            default: 'span'\n        }\n    },\n    data: function() {\n        return {\n            clickCount: 0,\n            clickTimer: null,\n            dblClickDelay: 200\n        };\n    },\n    computed: {\n\n        /**\n         *\n         * checks if this action is currently selected using the model.stateFrom and model.stateFromDefault\n         * properties of the action\n         *\n         * @return {boolean}\n         *\n         */\n        isSelected() {\n            if(!this.model.stateFrom) return false\n            let currentState = $perAdminApp.getNodeFromViewOrNull(this.model.stateFrom)\n            if(!currentState) {\n                if(this.model.stateFromDefault) {\n                    return true\n                }\n            } else if(currentState === this.model.target) {\n                return true\n            }\n            return false\n        },\n\n        /**\n         *\n         * returns the display title for this action. Logs an error if no title and no tooltipTitle\n         * is defined in the model\n         *\n         * @method computed:title\n         * @return {string} - the display title\n         *\n         */\n        title() {\n            if(this.model.tooltipTitle) {\n                if (this.model.experiences) {\n                    return this.$exp(this.model, 'tooltipTitle', this.model.tooltipTitle);\n                }\n                return this.model.tooltipTitle;\n            }\n            if(this.model.title) {\n                if (this.model.experiences) {\n                    return this.$exp(this.model, 'title', this.model.title);\n                }\n                return this.model.title\n            }\n            /* eslint-disable no-console */\n            console.error('missing alt', this.model.command, this.model.path)\n            /* eslint-enable no-console */\n            return this.model.command\n        },\n        target() {\n            if(this.model.target && typeof this.model.target === 'string') {\n                return this.model.target\n            }\n            if(this.model.target && typeof this.model.target.path) {\n                return this.model.target.path\n            }\n            return '#'\n        },\n        targetHtml() {\n            if(this.target.indexOf('.html') >= 0) return this.target\n            return this.target !== '#' ? this.target + '.html' : '#'\n        },\n        visible() {\n            if(this.model.visibility) {\n                return exprEval.Parser.evaluate( this.model.visibility, $perAdminApp.getView() );\n            } else {\n                return true;\n            }\n        }\n    },\n    methods: {\n\n        /**\n         *  triggers the action specified by the model\n         *\n         *  @method methods:action\n         * @param {event} e - event\n         */\n        action: function(e) {\n            $perAdminApp.action(this, this.model.command, this.model.target)\n        },\n        dblClickAction: function(e) {\n            $perAdminApp.action(this, this.model.dblClickCommand, this.model.dblClickTarget)\n        },\n        onClick: function(e) {\n            if(!this.model.dblClickCommand) {\n                this.action(e);\n            } else {\n                this.clickCount++;\n                if(this.clickCount === 1) {\n                    this.timer = setTimeout(() => {\n                        this.clickCount = 0;\n                        this.action(e);\n                    }, this.dblClickDelay);\n                } else {\n                    clearTimeout(this.timer);\n                    this.dblClickAction(e);\n                    this.clickCount = 0;\n                }\n            }\n        }\n    }\n}\n</script>\n\n<style>\n    .actionSelected {\n        background-color: white !important;\n        color: #37474f !important;\n    }\n</style>\n"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
