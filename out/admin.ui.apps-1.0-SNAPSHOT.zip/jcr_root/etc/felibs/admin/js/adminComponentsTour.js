var cmpAdminComponentsTour = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model'],
        watch: {
            model: function(val) {
                this.index = 0;
                this.enabled = false;
            }
        },
        data: function data() {
            return { 
                enabled: false , left: 10, width: 100, height: 10, top: 10, text: '', index: 0,
                windowHeight: window.innerHight,
                windowWidth: window.innerWidth,
                info: {width: null, height: null},
                noTransition: false
            }
        },
        computed: {
            edit: function edit() {
                return window.parent !== window && window.parent.$perAdminApp !== undefined
            },
            bottom: function bottom() { return this.top + this.height },
            right: function right() { return this.left + this.width },
            tourClass: function tourClass() {
                return '__pcms_tour'
            },
            tourItemStyle: function tourItemStyle() {
                return 'top: 0; left: 0;'
            },
            leftStyle: function leftStyle() {
                return { top: ((this.top) + "px"), left: '0px', height: ((this.height) + "px"), width: ((this.left) + "px")}
            },
            rightStyle: function rightStyle() {
                return { top: ((this.top) + "px"), left: ((this.right) + "px"), height: ((this.height) + "px"), width: ((this.windowWidth - this.right) + "px")}
            },
            bottomStyle: function bottomStyle() {
                return { top: ((this.bottom) + "px"), left: '0px', width: '100%', height: ((this.windowHeight - this.bottom) + "px")}
            },
            topStyle: function topStyle() {
                return { top: '0px', left: '0px', width: '100%', height: ((this.top) + "px")}
            },
            highliteStyle: function highliteStyle() {
                return { top: ((this.top) + "px"), left: ((this.left) + "px"), width: ((this.width) + "px"), height: ((this.height) + "px")}
            },
            infoStyle: function infoStyle() {
                var placeLeft  = {left: ((this.left - this.info.width - 20) + "px")};
                var placeRight = {left: ((this.right + 10) + "px")};
                var placeAbove = {top : ((this.top - this.info.height - 20) + "px")};
                var placeBelow = {top : ((this.bottom + 10) + "px")};

                //Use anchor if supplied
                var anchor = this.model.children[this.index].anchor;
                if (anchor) {
                    var horizontal = {left: this.left + this.info.width > window.innerWidth ? 
                        ((window.innerWidth - this.info.width) + "px") : ((this.left) + "px")};
                    var vertical = {top: this.top + this.info.height > window.innerHeight ? 
                        ((window.innerHeight - this.info.height) + "px") : ((this.top) + "px")};
                    // let vertical, horizontal = {}
                    if(anchor.indexOf('top') > -1) { vertical     = {top : 0}; }
                    if(anchor.indexOf('bottom') > -1) { vertical  = {top : ((window.innerHeight - this.info.height) + "px")}; }
                    if(anchor.indexOf('left') > -1) { horizontal  = {left: 0}; }
                    if(anchor.indexOf('right') > -1) { horizontal = {left: ((window.innerWidth - this.info.width) + "px")}; }
                    return Object.assign( vertical, horizontal);
                }

                var spaceLeft  = this.left;
                var spaceRight = window.innerWidth - this.right;
                var spaceAbove = this.top;
                var spaceBelow = window.innerHeight - this.bottom;

                //Favor side with more room
                var horizontalStyle = spaceLeft > spaceRight ? 
                    placeLeft : placeRight;
                var verticalStyle = spaceAbove > spaceBelow ? 
                    placeAbove : placeBelow;

                if ( spaceBelow > (this.info.height + 40) || spaceAbove > (this.info.height + 40)) {
                    var secondaryStyle = {left: this.left + this.info.width > window.innerWidth ? 
                        ((window.innerWidth - this.info.width) + "px") : ((this.left) + "px")};
                    return Object.assign( verticalStyle, secondaryStyle);
                }
                if ( spaceLeft > (this.info.width + 40) || spaceRight > (this.info.width + 40)) {
                    var secondaryStyle$1 = {top: this.top + this.info.height > window.innerHeight ? 
                        ((window.innerHeight - this.info.height) + "px") : ((this.top) + "px")};
                    return Object.assign( horizontalStyle, secondaryStyle$1);
                }
                return {
                    top: ((this.bottom - this.info.height) + "px"),
                    left:((this.right - this.info.width) + "px")
                }
            }
        },

        methods: {
            findElement: function findElement(node, path) {
                if(node) {
                    if(node.model && node.model.path === path) { return node.$el }
                    for(var i = 0; i < node.$children.length; i++) {
                        var ret = this.findElement(node.$children[i], path);
                        if(ret !== null) {
                            return ret
                        }
                    }
                }
                return null
            },
            showTour: function showTour(me, target) {
                me.enabled = true;
                me.showTourItem();
            },
            showTourItem: function showTourItem() {
                var root = this.findElement(this.$root, this.model.children[this.index].locator);
                var el = this.model.children[this.index].selector ? 
                    root.querySelector(this.model.children[this.index].selector) : root;
                if(el !== null) {
                    var child = this.model.children[this.index];
                    var rect = el.getBoundingClientRect();
                    this.left = rect.left;
                    this.top = rect.top;
                    this.width = rect.width;
                    this.height = rect.height;
                    if (child.experiences) {
                        this.text = this.$exp(child, 'text', child.text);
                    } else {
                        this.text = child.text;
                    }
                }
            },
            onNext: function onNext() {
                this.noTransition = false;
                this.index++;
                if(this.index === this.model.children.length) { this.index = 0; }
                this.showTourItem();
            },
            onPrevious: function onPrevious() {
                this.noTransition = false;
                this.index--;
                if(this.index === -1) { this.index = this.model.children.length -1; }
                this.showTourItem();
            },
            windowChange: function windowChange() {
                if(this.enabled) {
                    this.windowHeight = window.innerHeight;
                    this.windowWidth = window.innerWidth;
                    this.noTransition = true;
                    this.showTourItem();
                }
            }
        },
        mounted: function mounted() {
            this.index = 0;
            window.addEventListener('resize', this.windowChange);
            window.addEventListener('scroll', this.windowChange);
        },
        beforeUpdate: function beforeUpdate() {
            if ( this.model.children[0] != this.model.children[0] ) {
                this.index = 0;
            }
        },
        updated: function updated() {
            this.info.width = this.$refs.info ? this.$refs.info.offsetWidth : 0;
            this.info.height = this.$refs.info ?this.$refs.info.offsetHeight : 0;
        },
        beforeDestroy: function beforeDestroy() {
            window.removeEventListener('resize', this.windowChange);
            window.removeEventListener('scroll', this.windowChange);
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { attrs: { "data-per-path": _vm.model.path } }, [
        _vm.edit ? _c("div", [_vm._v("edit tour")]) : _vm._e(),
        _vm._v(" "),
        _vm.enabled
          ? _c(
              "div",
              { class: _vm.tourClass, attrs: { "data-per-path": _vm.model.path } },
              [
                _c("div", {
                  ref: "left",
                  class: [
                    { "no-transition": _vm.noTransition },
                    "__pcms_tour_overlay",
                    "tour-left"
                  ],
                  style: _vm.leftStyle
                }),
                _vm._v(" "),
                _c("div", {
                  ref: "right",
                  class: [
                    { "no-transition": _vm.noTransition },
                    "__pcms_tour_overlay",
                    "tour-right"
                  ],
                  style: _vm.rightStyle
                }),
                _vm._v(" "),
                _c("div", {
                  ref: "top",
                  class: [
                    { "no-transition": _vm.noTransition },
                    "__pcms_tour_overlay",
                    "tour-top"
                  ],
                  style: _vm.topStyle
                }),
                _vm._v(" "),
                _c("div", {
                  ref: "bottom",
                  class: [
                    { "no-transition": _vm.noTransition },
                    "__pcms_tour_overlay",
                    "tour-bot"
                  ],
                  style: _vm.bottomStyle
                }),
                _vm._v(" "),
                _c("div", {
                  ref: "highlite",
                  staticClass: "__pcms_tour_highlite",
                  style: _vm.highliteStyle
                }),
                _vm._v(" "),
                _c(
                  "div",
                  {
                    ref: "info",
                    class: [
                      { "no-transition": _vm.noTransition },
                      "__pcms_tour_info card"
                    ],
                    style: _vm.infoStyle
                  },
                  [
                    _c(
                      "button",
                      {
                        staticClass: "btn-flat btn-close",
                        on: {
                          click: function($event) {
                            _vm.enabled = false;
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "material-icons" }, [
                          _vm._v("close")
                        ])
                      ]
                    ),
                    _vm._v(" "),
                    _c("div", {
                      ref: "tourText",
                      staticClass: "card-content",
                      domProps: { innerHTML: _vm._s(_vm.text) }
                    }),
                    _vm._v(" "),
                    _c("div", { staticClass: "card-action" }, [
                      _c(
                        "button",
                        { staticClass: "btn", on: { click: _vm.onPrevious } },
                        [_vm._v(_vm._s(_vm.$i18n("prev")))]
                      ),
                      _vm._v(" "),
                      _c(
                        "button",
                        { staticClass: "btn", on: { click: _vm.onNext } },
                        [_vm._v(_vm._s(_vm.$i18n("next")))]
                      )
                    ])
                  ]
                )
              ]
            )
          : _vm._e()
      ])
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-220ed92b_0", { source: "\n.__pcms_tour {\n    pointer-events: none;\n    position: fixed;\n    z-index: 1003;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    left: 0;\n    bottom: 0;\n    right: 0;\n}\n.__pcms_tour_overlay {\n    position: fixed;\n    opacity: 0.75;\n    background: black;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    left: 0;\n    bottom: 0;\n    right: 0;\n}\n.__pcms_tour_highlite {\n    pointer-events: none;\n    position: fixed;\n    width: 100%;\n    height: 100%;\n    top: 0;\n    left: 0;\n    bottom: 0;\n    right: 0;\n}\n.__pcms_tour_info {\n    pointer-events: auto;\n    margin: 0;\n    min-width: 400px;\n    position: fixed;\n    max-width: 400px;\n    transition: top 0.25s, left 0.25s, height 0.25s;\n}\n.no-transition {\n    transition: none !important;\n}\n.__pcms_tour_info .btn-close{\n    float: right;\n}\n.__pcms_tour_info .card-action{\n    display: flex;\n    justify-content: space-between;\n}\n.tour-left  { transition: top 0.25s, width 0.25s, height 0.25s\n}\n.tour-right { transition: top 0.25s, left 0.25s, width 0.25s, height 0.25s\n}\n.tour-top   { transition: height 0.25s\n}\n.tour-bot   { transition: top 0.25s, height 0.25s\n}\n\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/tour/template.vue"],"names":[],"mappings":";AA0NA;IACA,oBAAA;IACA,eAAA;IACA,aAAA;IACA,WAAA;IACA,YAAA;IACA,MAAA;IACA,OAAA;IACA,SAAA;IACA,QAAA;AACA;AACA;IACA,eAAA;IACA,aAAA;IACA,iBAAA;IACA,WAAA;IACA,YAAA;IACA,MAAA;IACA,OAAA;IACA,SAAA;IACA,QAAA;AACA;AACA;IACA,oBAAA;IACA,eAAA;IACA,WAAA;IACA,YAAA;IACA,MAAA;IACA,OAAA;IACA,SAAA;IACA,QAAA;AACA;AAEA;IACA,oBAAA;IACA,SAAA;IACA,gBAAA;IACA,eAAA;IACA,gBAAA;IACA,+CAAA;AACA;AACA;IACA,2BAAA;AACA;AAEA;IACA,YAAA;AACA;AAEA;IACA,aAAA;IACA,8BAAA;AACA;AAEA,cAAA;AAAA;AACA,cAAA;AAAA;AACA,cAAA;AAAA;AACA,cAAA;AAAA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n    <div v-bind:data-per-path=\"model.path\">\n        <div v-if=\"edit\">edit tour</div>\n        <div v-if=\"enabled\" v-bind:class=\"tourClass\" v-bind:data-per-path=\"model.path\">\n            <div :class=\"[{'no-transition': noTransition}, '__pcms_tour_overlay', 'tour-left']\" ref=\"left\" v-bind:style=\"leftStyle\"></div>\n            <div :class=\"[{'no-transition': noTransition}, '__pcms_tour_overlay', 'tour-right']\" ref=\"right\" v-bind:style=\"rightStyle\"></div>\n            <div :class=\"[{'no-transition': noTransition}, '__pcms_tour_overlay', 'tour-top']\" ref=\"top\" v-bind:style=\"topStyle\"></div>\n            <div :class=\"[{'no-transition': noTransition}, '__pcms_tour_overlay', 'tour-bot']\" ref=\"bottom\" v-bind:style=\"bottomStyle\"></div>\n            <div class=\"__pcms_tour_highlite\" ref=\"highlite\" v-bind:style=\"highliteStyle\"></div>\n            <div :class=\"[{'no-transition': noTransition}, '__pcms_tour_info card']\" ref=\"info\" v-bind:style=\"infoStyle\">\n                <button v-on:click=\"enabled = false\" class=\"btn-flat btn-close\"><i class=\"material-icons\">close</i></button>\n                <div ref=\"tourText\" v-html=\"text\" class=\"card-content\">\n                </div>\n                <div class=\"card-action\">\n                    <button v-on:click=\"onPrevious\" class=\"btn\">{{ $i18n('prev') }}</button>\n                    <button v-on:click=\"onNext\" class=\"btn\">{{ $i18n('next') }}</button>\n                </div>\n            </div>\n        </div>\n    </div>\n</template>\n\n<script>\n    export default {\n        props: ['model'],\n        watch: {\n            model: function(val) {\n                this.index = 0;\n                this.enabled = false;\n            }\n        },\n        data() {\n            return { \n                enabled: false , left: 10, width: 100, height: 10, top: 10, text: '', index: 0,\n                windowHeight: window.innerHight,\n                windowWidth: window.innerWidth,\n                info: {width: null, height: null},\n                noTransition: false\n            }\n        },\n        computed: {\n            edit() {\n                return window.parent !== window && window.parent.$perAdminApp !== undefined\n            },\n            bottom() { return this.top + this.height },\n            right() { return this.left + this.width },\n            tourClass() {\n                return '__pcms_tour'\n            },\n            tourItemStyle() {\n                return 'top: 0; left: 0;'\n            },\n            leftStyle() {\n                return { top: `${ this.top }px`, left: '0px', height: `${ this.height }px`, width: `${ this.left }px`}\n            },\n            rightStyle() {\n                return { top: `${ this.top }px`, left: `${ this.right }px`, height: `${ this.height }px`, width: `${this.windowWidth - this.right}px`}\n            },\n            bottomStyle() {\n                return { top: `${ this.bottom }px`, left: '0px', width: '100%', height: `${this.windowHeight - this.bottom}px`}\n            },\n            topStyle() {\n                return { top: '0px', left: '0px', width: '100%', height: `${ this.top }px`}\n            },\n            highliteStyle() {\n                return { top: `${this.top}px`, left: `${this.left}px`, width: `${this.width}px`, height: `${this.height}px`}\n            },\n            infoStyle() {\n                const placeLeft  = {left: `${this.left - this.info.width - 20}px`}\n                const placeRight = {left: `${this.right + 10}px`}\n                const placeAbove = {top : `${this.top - this.info.height - 20}px`}\n                const placeBelow = {top : `${this.bottom + 10}px`}\n\n                //Use anchor if supplied\n                const anchor = this.model.children[this.index].anchor;\n                if (anchor) {\n                    let horizontal = {left: this.left + this.info.width > window.innerWidth ? \n                        `${window.innerWidth - this.info.width}px` : `${this.left}px`}\n                    let vertical = {top: this.top + this.info.height > window.innerHeight ? \n                        `${window.innerHeight - this.info.height}px` : `${this.top}px`}\n                    // let vertical, horizontal = {}\n                    if(anchor.indexOf('top') > -1) vertical     = {top : 0}\n                    if(anchor.indexOf('bottom') > -1) vertical  = {top : `${window.innerHeight - this.info.height}px`}\n                    if(anchor.indexOf('left') > -1) horizontal  = {left: 0}\n                    if(anchor.indexOf('right') > -1) horizontal = {left: `${window.innerWidth - this.info.width}px`}\n                    return Object.assign( vertical, horizontal);\n                }\n\n                const spaceLeft  = this.left;\n                const spaceRight = window.innerWidth - this.right;\n                const spaceAbove = this.top;\n                const spaceBelow = window.innerHeight - this.bottom;\n\n                //Favor side with more room\n                const horizontalStyle = spaceLeft > spaceRight ? \n                    placeLeft : placeRight;\n                const verticalStyle = spaceAbove > spaceBelow ? \n                    placeAbove : placeBelow;\n\n                if ( spaceBelow > (this.info.height + 40) || spaceAbove > (this.info.height + 40)) {\n                    const secondaryStyle = {left: this.left + this.info.width > window.innerWidth ? \n                        `${window.innerWidth - this.info.width}px` : `${this.left}px`}\n                    return Object.assign( verticalStyle, secondaryStyle);\n                }\n                if ( spaceLeft > (this.info.width + 40) || spaceRight > (this.info.width + 40)) {\n                    const secondaryStyle = {top: this.top + this.info.height > window.innerHeight ? \n                        `${window.innerHeight - this.info.height}px` : `${this.top}px`}\n                    return Object.assign( horizontalStyle, secondaryStyle);\n                }\n                return {\n                    top: `${this.bottom - this.info.height}px`,\n                    left:`${this.right - this.info.width}px`\n                }\n            }\n        },\n\n        methods: {\n            findElement(node, path) {\n                if(node) {\n                    if(node.model && node.model.path === path) return node.$el\n                    for(let i = 0; i < node.$children.length; i++) {\n                        const ret = this.findElement(node.$children[i], path)\n                        if(ret !== null) {\n                            return ret\n                        }\n                    }\n                }\n                return null\n            },\n            showTour(me, target) {\n                me.enabled = true\n                me.showTourItem()\n            },\n            showTourItem() {\n                const root = this.findElement(this.$root, this.model.children[this.index].locator)\n                const el = this.model.children[this.index].selector ? \n                    root.querySelector(this.model.children[this.index].selector) : root;\n                if(el !== null) {\n                    let child = this.model.children[this.index];\n                    const rect = el.getBoundingClientRect()\n                    this.left = rect.left\n                    this.top = rect.top\n                    this.width = rect.width\n                    this.height = rect.height\n                    if (child.experiences) {\n                        this.text = this.$exp(child, 'text', child.text);\n                    } else {\n                        this.text = child.text\n                    }\n                }\n            },\n            onNext() {\n                this.noTransition = false;\n                this.index++\n                if(this.index === this.model.children.length) this.index = 0\n                this.showTourItem()\n            },\n            onPrevious() {\n                this.noTransition = false;\n                this.index--\n                if(this.index === -1) this.index = this.model.children.length -1\n                this.showTourItem()\n            },\n            windowChange() {\n                if(this.enabled) {\n                    this.windowHeight = window.innerHeight;\n                    this.windowWidth = window.innerWidth;\n                    this.noTransition = true;\n                    this.showTourItem()\n                }\n            }\n        },\n        mounted() {\n            this.index = 0\n            window.addEventListener('resize', this.windowChange)\n            window.addEventListener('scroll', this.windowChange)\n        },\n        beforeUpdate() {\n            if ( this.model.children[0] != this.model.children[0] ) {\n                this.index = 0;\n            }\n        },\n        updated() {\n            this.info.width = this.$refs.info ? this.$refs.info.offsetWidth : 0;\n            this.info.height = this.$refs.info ?this.$refs.info.offsetHeight : 0;\n        },\n        beforeDestroy() {\n            window.removeEventListener('resize', this.windowChange)\n            window.removeEventListener('scroll', this.windowChange)\n        }\n    }\n</script>\n\n<style>\n    .__pcms_tour {\n        pointer-events: none;\n        position: fixed;\n        z-index: 1003;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        bottom: 0;\n        right: 0;\n    }\n    .__pcms_tour_overlay {\n        position: fixed;\n        opacity: 0.75;\n        background: black;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        bottom: 0;\n        right: 0;\n    }\n    .__pcms_tour_highlite {\n        pointer-events: none;\n        position: fixed;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        bottom: 0;\n        right: 0;\n    }\n\n    .__pcms_tour_info {\n        pointer-events: auto;\n        margin: 0;\n        min-width: 400px;\n        position: fixed;\n        max-width: 400px;\n        transition: top 0.25s, left 0.25s, height 0.25s;\n    }\n    .no-transition {\n        transition: none !important;\n    }\n\n    .__pcms_tour_info .btn-close{\n        float: right;\n    }\n\n    .__pcms_tour_info .card-action{\n        display: flex;\n        justify-content: space-between;\n    }\n\n    .tour-left  { transition: top 0.25s, width 0.25s, height 0.25s }\n    .tour-right { transition: top 0.25s, left 0.25s, width 0.25s, height 0.25s }\n    .tour-top   { transition: height 0.25s }\n    .tour-bot   { transition: top 0.25s, height 0.25s }\n\n</style>\n"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
