var cmpAdminComponentsMaterializemodal = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  var script = {
    props: {
      dismissible: {
        type: Boolean,
        default: true
      },
      opacity: {
        type: Number,
        default: .5
      },
      inDuration: {
        type: Number,
        default: 300
      },
      outDuration: {
        type: Number,
        default: 200
      },
      startingTop: {
        type: String,
        default: '4%'
      },
      endingTop: {
        type: String,
        default: '10%'
      },
      modalTitle: String
    },
    data: function data() {
      return {
        $modal: null
      }
    },
    computed: {
      id: function id() {
        return ("materializemodal-" + (this._uid))
      }
    },
    mounted: function mounted() {
      var vm = this;
      this.$modal = $(vm.$refs.modal);
      //this.$modal.appendTo('body')
      $(this.$modal).modal({
        dismissible: vm.dismissible,
        opacity: vm.opacity,
        inDuration: vm.inDuration,
        outDuration: vm.outDuration,
        startingTop: vm.startingTop,
        endingTop: vm.endingTop,
        ready: function ready(modal, trigger) {
          vm.$emit('ready', modal, trigger);
        },
        complete: function complete() {
          vm.$emit('complete');
        }
      });
    },
    methods: {
      open: function open() {
        this.$modal.modal('open');
      },
      close: function close() {
        this.$modal.modal('close');
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
  function createInjector(context) {
    return function (id, style) {
      return addStyle(id, style);
    };
  }
  var HEAD = document.head || document.getElementsByTagName('head')[0];
  var styles = {};

  function addStyle(id, css) {
    var group = isOldIE ? css.media || 'default' : id;
    var style = styles[group] || (styles[group] = {
      ids: new Set(),
      styles: []
    });

    if (!style.ids.has(id)) {
      style.ids.add(id);
      var code = css.source;

      if (css.map) {
        // https://developer.chrome.com/devtools/docs/javascript-debugging
        // this makes source maps inside style tags work properly in Chrome
        code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

        code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
      }

      if (!style.element) {
        style.element = document.createElement('style');
        style.element.type = 'text/css';
        if (css.media) { style.element.setAttribute('media', css.media); }
        HEAD.appendChild(style.element);
      }

      if ('styleSheet' in style.element) {
        style.styles.push(code);
        style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
      } else {
        var index = style.ids.size - 1;
        var textNode = document.createTextNode(code);
        var nodes = style.element.childNodes;
        if (nodes[index]) { style.element.removeChild(nodes[index]); }
        if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
      }
    }
  }

  var browser = createInjector;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      {
        ref: "modal",
        staticClass: "modal materialize-modal",
        attrs: { id: _vm.id }
      },
      [
        _vm.modalTitle
          ? _c("div", { staticClass: "modal-header" }, [
              _vm._v("\n    " + _vm._s(_vm.$i18n(_vm.modalTitle)) + "\n  ")
            ])
          : _vm._e(),
        _vm._v(" "),
        !!_vm.$slots.default
          ? _c("div", { staticClass: "modal-content" }, [_vm._t("default")], 2)
          : _vm._e(),
        _vm._v(" "),
        !!_vm.$slots.footer
          ? _c("div", { staticClass: "modal-footer" }, [_vm._t("footer")], 2)
          : _vm._e()
      ]
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = function (inject) {
      if (!inject) { return }
      inject("data-v-04e7e45a_0", { source: "\n.modal-header {\n    position: absolute;\n    top: 0;\n    left: 0;\n    right: 0;\n    height: 32px;\n    padding: 6px 10px;\n    font-size: 16px;\n    font-weight: bold;\n    background-color: #f5f5f5;\n    border-bottom: 1px solid #adadad;\n    text-align: center;\n}\n.modal .modal-content {\n  padding-top: 54px;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/materializemodal/template.vue"],"names":[],"mappings":";AA4GA;IACA,kBAAA;IACA,MAAA;IACA,OAAA;IACA,QAAA;IACA,YAAA;IACA,iBAAA;IACA,eAAA;IACA,iBAAA;IACA,yBAAA;IACA,gCAAA;IACA,kBAAA;AACA;AACA;EACA,iBAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n  <div ref=\"modal\" :id=\"id\" class=\"modal materialize-modal\">\n    <div v-if=\"modalTitle\" class=\"modal-header\">\n      {{$i18n(modalTitle)}}\n    </div>\n    <div v-if=\"!!$slots.default\" class=\"modal-content\">\n      <slot></slot>\n    </div>\n    <div v-if=\"!!$slots.footer\" class=\"modal-footer\">\n      <slot name=\"footer\"></slot>\n    </div>\n  </div>\n</template>\n\n<script>\n  export default {\n    props: {\n      dismissible: {\n        type: Boolean,\n        default: true\n      },\n      opacity: {\n        type: Number,\n        default: .5\n      },\n      inDuration: {\n        type: Number,\n        default: 300\n      },\n      outDuration: {\n        type: Number,\n        default: 200\n      },\n      startingTop: {\n        type: String,\n        default: '4%'\n      },\n      endingTop: {\n        type: String,\n        default: '10%'\n      },\n      modalTitle: String\n    },\n    data() {\n      return {\n        $modal: null\n      }\n    },\n    computed: {\n      id() {\n        return `materializemodal-${this._uid}`\n      }\n    },\n    mounted() {\n      const vm = this\n      this.$modal = $(vm.$refs.modal)\n      //this.$modal.appendTo('body')\n      $(this.$modal).modal({\n        dismissible: vm.dismissible,\n        opacity: vm.opacity,\n        inDuration: vm.inDuration,\n        outDuration: vm.outDuration,\n        startingTop: vm.startingTop,\n        endingTop: vm.endingTop,\n        ready(modal, trigger) {\n          vm.$emit('ready', modal, trigger)\n        },\n        complete() {\n          vm.$emit('complete')\n        }\n      })\n    },\n    methods: {\n      open() {\n        this.$modal.modal('open')\n      },\n      close() {\n        this.$modal.modal('close')\n      }\n    }\n  }\n</script>\n\n<style>\n    .modal-header {\n        position: absolute;\n        top: 0;\n        left: 0;\n        right: 0;\n        height: 32px;\n        padding: 6px 10px;\n        font-size: 16px;\n        font-weight: bold;\n        background-color: #f5f5f5;\n        border-bottom: 1px solid #adadad;\n        text-align: center;\n    }\n    .modal .modal-content {\n      padding-top: 54px;\n    }\n</style>"]}, media: undefined });

    };
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      browser,
      undefined
    );

  return template;

}());
