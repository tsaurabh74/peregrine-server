var cmpAdminComponentsEditor = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function set(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(vue) {
          Vue.set(node, path[0], value);
      }
      else {
          node[path[0]] = value;
      }
  }

  //

    var script = {
        props: ['model'],
          updated: function() {
              var stateTools = $perAdminApp.getNodeFromViewWithDefault("/state/tools", {});
              stateTools._deleted = {}; // reset to empty?
              if(this.schema && this.schema.hasOwnProperty('groups')) {
                  this.hideGroups();
              }
          },
        data: function data() {
          return {
            isTouch: false,
            formOptions: {
              validateAfterLoad: true,
              validateAfterChanged: true,
              focusFirstField: true
            },
            focus: {
              loop: null,
              timeout: null,
              interval: 100,
              delay: 700,
              inView: 0
            }
          }
        },
        computed: {
            view: function view() {
                return $perAdminApp.getView()
            },
          schema: function() {
              var view = $perAdminApp.getView();
              var component = view.state.editor.component;
              var schema = view.admin.componentDefinitions[component].model;
              return schema
          },
          dataModel: function() {
              var view = $perAdminApp.getView();
              var path = view.state.editor.path;
              var model = $perAdminApp.findNodeFromPath(view.pageView.page, path);
              return model
          },
          hasSchema: function() {
              if(this.schema) { return true }
              return false
          },
          isRootComponent: function() {
              return $perAdminApp.getView().state.editor.path == '/jcr:content'
          },
            title: function() {
                var view = $perAdminApp.getView();
                var componentName = view.state.editor.component.split('-').join('/');
                var components = view.admin.components.data;
                for(var i = 0; i < components.length; i++) {
                    var component = components[i];
                    if(component.path.endsWith(componentName) && component.group !== '.hidden') {
                        return component.title
                    }
                }
            }
        },
          watch: {
            'view.state.inline.model': function view_state_inline_model(val) {
                if (!val) { return }
                this.focusFieldByModel(val);
            }
          },
          mounted: function mounted(){
              this.isTouch = 'ontouchstart' in window || navigator.maxTouchPoints;
              if(this.schema && this.schema.hasOwnProperty('groups')) {
                  this.hideGroups();
              }
          },
        methods: {
          onOk: function onOk(e) {
              var this$1 = this;

              var data = JSON.parse(JSON.stringify(this.dataModel));
              var _deleted = $perAdminApp.getNodeFromViewWithDefault("/state/tools/_deleted", {});

              //Merge _deleted child items back into the object that we need to save.
              //Loop through the model for this object/page/asset and find objects that have children
              for ( var key in data) {
                  //If data[key] or deleted[key] is an array of objects
                  if (( data && Array.isArray(data[key]) && data[key].length && typeof data[key][0] === 'object') ||
                      ( _deleted && Array.isArray(_deleted[key]) && _deleted[key].length && typeof _deleted[key][0] === 'object') ) {

                      var node = data[key];

                      //Use an object to easily merge back in deleted nodes
                      var targetNode = {};
                      //Insert deleted children
                      if(_deleted) {
                          for ( var j in _deleted[key]) {
                              var deleted = _deleted[key][j];
                              targetNode[deleted.name] = deleted;
                          }
                      }
                      //Insert children
                      for ( var i in node ) {
                          var child = node[i];
                          targetNode[child.name] = child;
                      }
                      data[key] = Object.values(targetNode);
                  }
              }

              var view = $perAdminApp.getView();
              $perAdminApp.action(this, 'onEditorExitFullscreen');
              $perAdminApp.stateAction('savePageEdit', { data: data, path: view.state.editor.path } ).then( function () {
                $perAdminApp.action(this$1, 'unselect');
                $perAdminApp.getNodeFromView("/state/tools")._deleted = {};
              });
          },
          onCancel: function onCancel(e) {
              var view = $perAdminApp.getView();
              $perAdminApp.action(this, 'onEditorExitFullscreen');
              $perAdminApp.action(this, 'unselect');
              $perAdminApp.stateAction('cancelPageEdit', { pagePath: view.pageView.path, path: view.state.editor.path } ).then( function () {
                  $perAdminApp.getNodeFromView("/state/tools")._deleted = {};
              });
          },
            onDelete: function onDelete(e) {
                var vm = this;
                var view = $perAdminApp.getView();
                $perAdminApp.askUser('Delete Component?', 'Are you sure you want to delete the component?', {
                    yesText: 'Yes',
                    noText: 'No',
                    yes: function yes() {
                        $perAdminApp.action(vm, 'onEditorExitFullscreen');
                        $perAdminApp.stateAction('deletePageNode', { pagePath: view.pageView.path, path: view.state.editor.path } ).then( function () {
                            $perAdminApp.action(vm, 'unselect');
                            $perAdminApp.getNodeFromView("/state/tools")._deleted = {};
                        });
                    },
                    no: function no() {
                    }
                });
            },
          hideGroups: function hideGroups() {
              var $groups = $('.vue-form-generator fieldset');
              $groups.each( function(i) {
                  var $group = $(this);
                  var $title = $group.find('legend');
                  $title.click(function(e){
                      $group.find('div').toggle();
                      $group.toggleClass('active');
                  });
                  if(i !== 0) {
                      $group.find('div').hide();
                      $group.removeClass('active');
                  }
                  if(i === 0) { $group.addClass('active'); }
                  $group.addClass('vfg-group');
              });
          },
          getFieldAndIndexByModel: function getFieldAndIndexByModel(fields, model) {
            var formGenerator = this.$refs.formGenerator;
            var field;
            var index = -1;
            fields.some(function (f) {
              if (f.visible) {
                if (typeof f.visible === 'string') {
                  if (exprEval.Parser.evaluate(f.visible, formGenerator) === true) {
                    index++;
                  }
                } else if (formGenerator.fieldVisible(f) === true){
                  index++;
                }
              } else {
                index++;
              }
              if (f.model === model) {
                return field = f
              }
            });
            return {field: field, index: index}
          },
          focusFieldByModel: function focusFieldByModel(model) {
            if (!model) { return }

            model = model.split('.');
            model.reverse();
            var ref = this.getFieldAndIndexByModel(this.schema.fields, model.pop());
            var field = ref.field;
            var index = ref.index;
            if (!field) { return }
            if (['input', 'texteditor', 'material-textarea'].indexOf(field.type) >= 0) {
              this.$refs.formGenerator.$children[index].$el.scrollIntoView();
              set(this.view, '/state/inline/rich', this.isRichEditor(field));
            } else if (field.type === 'collection') {
              this.focusCollectionField(model, field, index);
            } else {
              console.warn('Unsupported field type: ', field.type);
            }

            set(this.view, '/state/inline/model', null);
          },
          focusCollectionField: function focusCollectionField(model, field, index) {
            var this$1 = this;

            var fieldCollection = this.$refs.formGenerator.$children[index].$children[0];
            fieldCollection.activeItem = parseInt(model.pop());
            this.$nextTick(function () {
              var formGen = fieldCollection.$children[0];
              var fieldAndIndex = this$1.getFieldAndIndexByModel(field.fields, model.pop());
              set(this$1.view, '/state/inline/rich', this$1.isRichEditor(fieldAndIndex.field));
              this$1.clearFocusStuff();
              this$1.focus.loop = setInterval(function () {
                formGen.$children[fieldAndIndex.index].$el.scrollIntoView();
              }, this$1.focus.interval);
              this$1.focus.timeout = setTimeout(function () {
                this$1.clearFocusStuff();
              }, this$1.focus.delay);
            });
          },
          clearFocusStuff: function clearFocusStuff() {
            this.focus.inView = 0;
            clearInterval(this.focus.loop);
            clearTimeout(this.focus.timeout);
          },
          isRichEditor: function isRichEditor(field) {
            return ['texteditor'].indexOf(field.type) >= 0
          }
        }
  //      ,
  //      beforeMount: function() {
  //        if(!perAdminView.state.editor) this.$set(perAdminView.state, 'editor', { })
  //      }
      };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", { ref: "editorPanel", staticClass: "editor-panel" }, [
      _c(
        "div",
        { staticClass: "editor-panel-content" },
        [
          _vm.schema !== undefined && _vm.dataModel !== undefined
            ? [
                _vm.title
                  ? _c("span", { staticClass: "panel-title" }, [
                      _vm._v(_vm._s(_vm.title))
                    ])
                  : _vm._e(),
                _vm._v(" "),
                !_vm.hasSchema
                  ? _c("div", [
                      _vm._v("this component does not have a dialog defined")
                    ])
                  : _vm._e(),
                _vm._v(" "),
                _c("vue-form-generator", {
                  key: _vm.dataModel.path,
                  ref: "formGenerator",
                  attrs: {
                    schema: _vm.schema,
                    model: _vm.dataModel,
                    options: _vm.formOptions
                  }
                })
              ]
            : _vm._e()
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "editor-panel-buttons" },
        [
          !_vm.isRootComponent
            ? _c(
                "button",
                {
                  staticClass: "waves-effect waves-light btn btn-raised",
                  attrs: { title: _vm.$i18n("deleteComponent") },
                  on: {
                    click: function($event) {
                      $event.stopPropagation();
                      $event.preventDefault();
                      return _vm.onDelete($event)
                    }
                  }
                },
                [_c("i", { staticClass: "material-icons" }, [_vm._v("delete")])]
              )
            : _vm._e(),
          _vm._v(" "),
          _c(
            "button",
            {
              staticClass: "waves-effect waves-light btn btn-raised",
              attrs: { title: _vm.$i18n("cancel") },
              on: {
                click: function($event) {
                  $event.stopPropagation();
                  $event.preventDefault();
                  return _vm.onCancel($event)
                }
              }
            },
            [_c("i", { staticClass: "material-icons" }, [_vm._v("close")])]
          ),
          _vm._v(" "),
          [
            _vm.hasSchema
              ? _c(
                  "button",
                  {
                    staticClass: "waves-effect waves-light btn btn-raised",
                    attrs: { title: _vm.$i18n("save") },
                    on: {
                      click: function($event) {
                        $event.stopPropagation();
                        $event.preventDefault();
                        return _vm.onOk($event)
                      }
                    }
                  },
                  [_c("i", { staticClass: "material-icons" }, [_vm._v("check")])]
                )
              : _c(
                  "button",
                  {
                    staticClass: "btn btn-raised disabled",
                    staticStyle: { opacity: "0" }
                  },
                  [_c("i", { staticClass: "material-icons" }, [_vm._v("check")])]
                )
          ]
        ],
        2
      )
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
