var cmpFieldCollection = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

    var script = {
      mixins: [ VueFormGenerator.abstractField ],
      beforeMount: function beforeMount(){
        if(!this.value) { this.value = []; }
      },
    	data: function data(){
    		return {
    			activeItem: null
    		}
    	},
      computed: {
      	itemModel: function itemModel(){
      		var model = {};
      		this.schema.fields.forEach( function (item, index) {
      			model[item.model] = '';
      		});
      		model.name = 'n' + Date.now();
      		return model
      	}
      },
      methods: {
  	    getSchemaForIndex: function getSchemaForIndex(schema, index) {
            var newSchema = JSON.parse(JSON.stringify(schema));
            newSchema.fields[0].model = ''+index;
            return newSchema
        },
        getItemClass: function getItemClass(item, index){
          if(!this.schema.multifield) { return }
          if(this.activeItem === index){
            return 'active'
          }
          if(item._opDelete){
            return 'deleted'
          }
          return false
        },
        itemName: function itemName(item, index) {
            if(this.schema.fieldLabel) {
                var len = this.schema.fieldLabel.length;
                for(var i=0; i<len; i++){
                    var label = this.schema.fieldLabel[i];
                    var childItem = this.value[index];
                    if(childItem[label]){
                        return childItem[label]
                    }
                }
            }
            return parseInt(index) + 1
        },
        prepModel: function prepModel(model, schema) {
              for(var i = 0; i < schema.fields.length; i++) {
                  var field = schema.fields[i].model;
                  if(!model[field]) {
                      Vue.set(model, field, '');
                  }
              }
              return model
          },

        onAddItem: function onAddItem(e){
          if(!this.schema.multifield){
            var newChild = '';
              if(!this.value || this.value === '')
              {
                  Vue.set(this, 'value', new Array());
              }
          } else {
              var newChild = { name: 'n' + Date.now()};
              this.prepModel(newChild, this.schema);
              newChild['sling:resourceType'] = this.schema.resourceType;
          }
          this.value.push(newChild);
          // Vue.set(this.value, this.value.length -1, newChild)
          this.onSetActiveItem(this.value.length - 1);
          this.$forceUpdate();
        },
        onRemoveItem: function onRemoveItem(item, index){
          this.value.splice(index, 1);
          if( this.schema.multifield ) {
            if( item.hasOwnProperty('path') ) {
              var _deleted = $perAdminApp.getNodeFromViewWithDefault("/state/tools/_deleted", {});
              var copy = JSON.parse(JSON.stringify(item));
              copy._opDelete = true;
              if(!_deleted[this.schema.model]) { _deleted[this.schema.model] = []; }
              _deleted[this.schema.model].push(copy);
            }
            this.activeItem = null;
          }
        },
        onSetActiveItem: function onSetActiveItem(index){
          if(!this.schema.multifield) { return }
          if(index === this.activeItem){
            $(this.$refs.collapsible).collapsible('close', this.activeItem);
            this.activeItem = null;
          } else {
            this.$nextTick(function () {
              if(this.activeItem !== null){
                $(this.$refs.collapsible).collapsible('close', this.activeItem);
              }
              $(this.$refs.collapsible).collapsible('open', index);
              this.activeItem = index;
              // focus first field of expanded item
              var firstField = this.$refs.collapsible.querySelector('li.active input');
              if(firstField) { firstField.focus(); }
            });
          }
        },
        onDragStart: function onDragStart(item, index, ev){
          ev.dataTransfer.setData('text', index);
        },
        onDragOver: function onDragOver(ev){
          var center = ev.target.offsetHeight / 2; 
          ev.target.classList.toggle('drop-after', ev.offsetY > center );
          ev.target.classList.toggle('drop-before', ev.offsetY < center );
        },
        onDragEnter: function onDragEnter(ev){
        },
        onDragLeave: function onDragLeave(ev){
          ev.target.classList.remove('drop-after','drop-before');
        },
        onDrop: function onDrop(item, index, ev) {
            ev.target.classList.remove('drop-after','drop-before');
            var oldIndex = parseInt(ev.dataTransfer.getData("text"));
            this.onReorder(oldIndex, index);
        },
        onReorder: function onReorder(old_index, new_index) {
          if (new_index >= this.length) {
              var k = new_index - this.length;
              while ((k--) + 1) {
                  this.value.push(undefined);
              }
          }
          this.value.splice(new_index, 0, this.value.splice(old_index, 1)[0]);
          this.$forceUpdate();
        },
        // animations with Velocity.js
        enter: function (el, done) {
          window.Materialize.Vel(el, "slideDown", { duration: 250 });
        },
        leave: function (el, done) {
          window.Materialize.Vel(el, "slideUp", { duration: 250 }, { complete: done });
        }
      }
    };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", { staticClass: "wrap" }, [
      _c("label", [_vm._v(_vm._s(_vm.schema.title) + " ")]),
      _vm._v(" "),
      !_vm.schema.preview
        ? _c(
            "ul",
            {
              ref: "collapsible",
              staticClass: "collapsible",
              class: _vm.schema.multifield ? "multifield" : "singlefield"
            },
            [
              _vm._l(_vm.value, function(item, index) {
                return _c(
                  "li",
                  { key: item.path, class: _vm.getItemClass(item, index) },
                  [
                    _vm._v(" " + _vm._s(item._opDelete) + "\n            "),
                    _c(
                      "div",
                      {
                        staticClass: "collapsible-header",
                        attrs: { draggable: "true" },
                        on: {
                          dragstart: function($event) {
                            return _vm.onDragStart(item, index, $event)
                          },
                          dragover: function($event) {
                            $event.preventDefault();
                            return _vm.onDragOver($event)
                          },
                          dragenter: function($event) {
                            $event.preventDefault();
                            return _vm.onDragEnter($event)
                          },
                          dragleave: function($event) {
                            $event.preventDefault();
                            return _vm.onDragLeave($event)
                          },
                          drop: function($event) {
                            $event.preventDefault();
                            return _vm.onDrop(item, index, $event)
                          },
                          click: function($event) {
                            $event.stopPropagation();
                            $event.preventDefault();
                            return _vm.onSetActiveItem(index)
                          }
                        }
                      },
                      [
                        _c("i", { staticClass: "material-icons" }, [
                          _vm._v("drag_handle")
                        ]),
                        _vm._v(" "),
                        _vm.schema.multifield
                          ? _c("span", [
                              _vm._v(_vm._s(_vm.itemName(item, index)))
                            ])
                          : _c("input", {
                              directives: [
                                {
                                  name: "model",
                                  rawName: "v-model",
                                  value: _vm.value[index],
                                  expression: "value[index]"
                                }
                              ],
                              domProps: { value: _vm.value[index] },
                              on: {
                                input: function($event) {
                                  if ($event.target.composing) {
                                    return
                                  }
                                  _vm.$set(_vm.value, index, $event.target.value);
                                }
                              }
                            }),
                        _vm._v(" "),
                        _c(
                          "i",
                          {
                            staticClass: "material-icons delete-icon",
                            on: {
                              click: function($event) {
                                return _vm.onRemoveItem(item, index)
                              }
                            }
                          },
                          [_vm._v("delete")]
                        )
                      ]
                    ),
                    _vm._v(" "),
                    _c(
                      "transition",
                      {
                        attrs: { css: false },
                        on: { enter: _vm.enter, leave: _vm.leave }
                      },
                      [
                        _vm.schema.multifield && _vm.activeItem === index
                          ? _c(
                              "div",
                              { staticClass: "collapsible-body" },
                              [
                                _c("vue-form-generator", {
                                  attrs: {
                                    schema: _vm.schema,
                                    model: _vm.prepModel(item, _vm.schema)
                                  }
                                })
                              ],
                              1
                            )
                          : _vm._e()
                      ]
                    )
                  ],
                  1
                )
              }),
              _vm._v(" "),
              _c(
                "button",
                {
                  staticClass: "btn-flat btn-add-item",
                  attrs: { type: "button" },
                  on: { click: _vm.onAddItem }
                },
                [_c("i", { staticClass: "material-icons" }, [_vm._v("add")])]
              )
            ],
            2
          )
        : _c(
            "ul",
            { staticClass: "collection" },
            [
              _vm._l(_vm.value, function(item, i) {
                return [
                  typeof item === "object"
                    ? _c(
                        "ul",
                        { key: item.name, staticClass: "collection z-depth-1" },
                        [
                          _vm.schema.multifield
                            ? _c("vue-form-generator", {
                                staticClass: "collection-item",
                                attrs: {
                                  schema: _vm.schema,
                                  model: _vm.prepModel(item, _vm.schema)
                                }
                              })
                            : _vm._e()
                        ],
                        1
                      )
                    : _c(
                        "li",
                        { key: item + i, staticClass: "collection-item" },
                        [_vm._v(_vm._s(item))]
                      )
                ]
              })
            ],
            2
          )
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
