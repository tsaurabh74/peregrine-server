var cmpAdminComponentsCreatetenantwizard = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

        var script = {
            props: ['model'],
            data:
                function() {
                    var this$1 = this;

                    return {
                        isLastStep: false,
                        reloadKey: 0,
                        colorPalettes: [],
                        formErrors: {
                            unselectedThemeError: false
                        },
                        formmodel: {
                            path: $perAdminApp.getNodeFromView('/state/tools/pages'),
                            name: '',
                            title: '',
                            tenantUserPwd: '',
                            templatePath: ''
                        },
                        formOptions: {
                            validationErrorClass: "has-error",
                            validationSuccessClass: "has-success",
                            validateAfterChanged: true,
                            focusFirstField: true
                        },
                        nameChanged: false,
                        nameSchema: {
                            fields: [
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Site Title",
                                    model: "title",
                                    required: true,
                                    onChanged: function (model, newVal, oldVal, field) {
                                      if(!this$1.nameChanged) {
                                          this$1.formmodel.name = $perAdminApp.normalizeString(newVal, '_');
                                      }
                                    }
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Site Name",
                                    model: "name",
                                    required: true,
                                    onChanged: function (model, newVal, oldVal, field) {
                                        this$1.nameChanged = true;
                                    },
                                    validator: [this.nameAvailable, this.validSiteName]
                                },
                                {
                                    type: "input",
                                    inputType: "text",
                                    label: "Tenant User Password",
                                    model: "tenantUserPwd",
                                    required: false,
                                    onChanged: function (model, newVal, oldVal, field) {
                                    }
                                }
                            ]
                        }
                    }

            },
            created: function() {
                //By default select the first item in the list;
                this.selectTheme(this, this.themes[0].name);
            },
            computed: {
                pageSchema: function() {
                },
                themes: function() {
                    var themes = $perAdminApp.getView().admin.tenants;
                    return themes.filter( function (item) {
                        return item.template === true;
                    })
                }
            },
            methods: {
                selectTheme: function(me, target){
                    if(me === null) { me = this; }
                    me.formmodel.templatePath = target;
                    me.formmodel.colorPalette = null;
                    me.colorPalettes = [];
                    this.validateTabOne(me);
                    $perAdminApp.getApi().getPalettes(me.formmodel.templatePath).then(function (data) {
                        if (data && data.children && data.children.length > 0) {
                            me.colorPalettes = data.children.reverse();
                        }
                        me.reloadKey++;
                    });
                },
                isSelected: function(target) {
                    return this.formmodel.templatePath === target
                },
                onComplete: function(edit) {
                    if ( edit === void 0 ) edit = true;

                    var payload = {
                        fromName: this.formmodel.templatePath,
                        toName: this.formmodel.name,
                        title: this.formmodel.title,
                        tenantUserPwd: this.formmodel.tenantUserPwd,
                        editHome: edit
                    };

                    if (this.formmodel.colorPalette && this.formmodel.colorPalette.length > 0) {
                        payload.colorPalette = this.formmodel.colorPalette;
                    }
                    $perAdminApp.stateAction('createTenant', payload);
                },
                validateTabOne: function(me) {
                    me.formErrors.unselectedThemeError = ('' === '' + me.formmodel.templatePath);

                    return !me.formErrors.unselectedThemeError;
                },
                leaveTabOne: function() {
                    if('' !== ''+this.formmodel.templatePath) ;

                    return this.validateTabOne(this);
                },
                nameAvailable: function nameAvailable(value) {
                    if(!value || value.length === 0) {
                        return ['name is required']
                    } else {
                        var folder = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, '/content');
                        if(folder && folder.children) {
                            for(var i = 0; i < folder.children.length; i++) {
                                if(folder.children[i].name === value) {
                                    return ['name aready in use']
                                }
                            }
                        }
                        return []
                    }
                },
                validSiteName: function validSiteName(value) {
                    if(!value || value.length === 0) {
                        return ['name is required']
                    }
                    if(value.match(/[^0-9a-z_]/)) {
                        return ['site names may only contain lowercase letters, numbers, and underscores']
                    }
                    return [];
                },
                leaveTabTwo: function() {
                    var isValid = this.$refs.nameTab.validate();
                    this.isLastStep = isValid;
                    return isValid
                },
                changeTab: function(prev, next) {
                    if(next < prev) { this.isLastStep = false; }
                },
                onColorPaletteSelect: function onColorPaletteSelect(colorPalette) {
                    this.formmodel.colorPalette = colorPalette;
                }
            }
        };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
    function createInjector(context) {
      return function (id, style) {
        return addStyle(id, style);
      };
    }
    var HEAD = document.head || document.getElementsByTagName('head')[0];
    var styles = {};

    function addStyle(id, css) {
      var group = isOldIE ? css.media || 'default' : id;
      var style = styles[group] || (styles[group] = {
        ids: new Set(),
        styles: []
      });

      if (!style.ids.has(id)) {
        style.ids.add(id);
        var code = css.source;

        if (css.map) {
          // https://developer.chrome.com/devtools/docs/javascript-debugging
          // this makes source maps inside style tags work properly in Chrome
          code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

          code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
        }

        if (!style.element) {
          style.element = document.createElement('style');
          style.element.type = 'text/css';
          if (css.media) { style.element.setAttribute('media', css.media); }
          HEAD.appendChild(style.element);
        }

        if ('styleSheet' in style.element) {
          style.styles.push(code);
          style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
        } else {
          var index = style.ids.size - 1;
          var textNode = document.createTextNode(code);
          var nodes = style.element.childNodes;
          if (nodes[index]) { style.element.removeChild(nodes[index]); }
          if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
        }
      }
    }

    var browser = createInjector;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "div",
        { staticClass: "container" },
        [
          _c(
            "form-wizard",
            {
              key: _vm.reloadKey,
              ref: "wizard",
              attrs: {
                title: "create a website",
                subtitle: "",
                "error-color": "#d32f2f",
                color: "#546e7a"
              },
              on: { "on-complete": _vm.onComplete, "on-change": _vm.changeTab }
            },
            [
              _c(
                "tab-content",
                {
                  attrs: { title: "select theme", "before-change": _vm.leaveTabOne }
                },
                [
                  _c("fieldset", { staticClass: "vue-form-generator" }, [
                    _c("div", { staticClass: "form-group required" }, [
                      _c("label", [_vm._v("Select Theme")]),
                      _vm._v(" "),
                      _c(
                        "ul",
                        { staticClass: "collection" },
                        _vm._l(_vm.themes, function(item) {
                          return _c(
                            "li",
                            {
                              key: item.name,
                              staticClass: "collection-item",
                              class: _vm.isSelected(item.name) ? "active" : "",
                              on: {
                                click: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.selectTheme(null, item.name)
                                }
                              }
                            },
                            [
                              _c("admin-components-action", {
                                attrs: {
                                  model: {
                                    command: "selectTheme",
                                    target: item.name,
                                    title: item.title ? item.title : item.name
                                  }
                                }
                              })
                            ],
                            1
                          )
                        }),
                        0
                      ),
                      _vm._v(" "),
                      _vm.formErrors.unselectedThemeError
                        ? _c("div", { staticClass: "errors" }, [
                            _c("span", { attrs: { "track-by": "index" } }, [
                              _vm._v("Selection required")
                            ])
                          ])
                        : _vm._e()
                    ])
                  ]),
                  _vm._v(" "),
                  _c("p", [
                    _vm._v(
                      "\n                This wizard allows you to create a website from an existing theme. If you'd like to create a more complex\n                website please use the commandline tool `percli create project <name>` to create a website managed as a\n                full project.\n            "
                    )
                  ])
                ]
              ),
              _vm._v(" "),
              _vm.colorPalettes && _vm.colorPalettes.length > 0
                ? _c(
                    "tab-content",
                    { attrs: { title: "choose color palette" } },
                    [
                      _c("admin-components-colorpaletteselector", {
                        attrs: {
                          palettes: _vm.colorPalettes,
                          "template-path": _vm.formmodel.templatePath
                        },
                        on: { select: _vm.onColorPaletteSelect }
                      })
                    ],
                    1
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "tab-content",
                {
                  attrs: { title: "choose name", "before-change": _vm.leaveTabTwo }
                },
                [
                  _c("vue-form-generator", {
                    ref: "nameTab",
                    attrs: {
                      model: _vm.formmodel,
                      schema: _vm.nameSchema,
                      options: _vm.formOptions
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c("tab-content", { attrs: { title: "verify" } }, [
                _vm._v(
                  "\n            Creating Site `" +
                    _vm._s(_vm.formmodel.name) +
                    "` from existing theme `" +
                    _vm._s(_vm.formmodel.templatePath) +
                    "`\n        "
                )
              ]),
              _vm._v(" "),
              _vm.isLastStep
                ? _c(
                    "span",
                    {
                      attrs: { slot: "custom-buttons-right", role: "button" },
                      slot: "custom-buttons-right"
                    },
                    [
                      _c(
                        "button",
                        {
                          staticClass: "wizard-btn outline",
                          attrs: { type: "button" },
                          on: {
                            click: function($event) {
                              return _vm.onComplete(false)
                            }
                          }
                        },
                        [_vm._v("\n                Create\n           ")]
                      )
                    ]
                  )
                : _vm._e(),
              _vm._v(" "),
              _c(
                "span",
                {
                  attrs: { slot: "finish", role: "button", tabindex: "0" },
                  slot: "finish"
                },
                [
                  _c(
                    "button",
                    {
                      staticClass: "wizard-btn finish",
                      attrs: { tabindex: "-1", type: "button" }
                    },
                    [_vm._v("\n            Create and Edit!\n            ")]
                  )
                ]
              )
            ],
            1
          )
        ],
        1
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = function (inject) {
        if (!inject) { return }
        inject("data-v-66469dfc_0", { source: "\n.feature-unavailable[data-v-66469dfc] {\n    display: flex;\n    justify-content: center;\n}\n.feature-unavailable .card[data-v-66469dfc]{\n    max-width: 700px;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/createtenantwizard/template.vue"],"names":[],"mappings":";AA4PA;IACA,aAAA;IACA,uBAAA;AACA;AAEA;IACA,gBAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n<div class=\"container\">\n    <form-wizard\n      v-bind:title=\"'create a website'\"\n      v-bind:subtitle=\"''\"\n      @on-complete=\"onComplete\"\n      @on-change=\"changeTab\"\n      error-color=\"#d32f2f\"\n      color=\"#546e7a\"\n      ref=\"wizard\"\n      :key=\"reloadKey\">\n        <tab-content title=\"select theme\" :before-change=\"leaveTabOne\">\n            <fieldset class=\"vue-form-generator\">\n                <div class=\"form-group required\">\n                    <label>Select Theme</label>\n                    <ul class=\"collection\">\n                        <li class=\"collection-item\"\n                            v-for=\"item in themes\"\n                            v-bind:key=\"item.name\"\n                            v-on:click.stop.prevent=\"selectTheme(null, item.name)\"\n                            v-bind:class=\"isSelected(item.name) ? 'active' : ''\">\n                            <admin-components-action v-bind:model=\"{ command: 'selectTheme', target: item.name, title: item.title ? item.title : item.name }\"></admin-components-action>\n                        </li>\n                    </ul>\n                    <div v-if=\"formErrors.unselectedThemeError\" class=\"errors\">\n                        <span track-by=\"index\">Selection required</span>\n                    </div>\n                </div>\n            </fieldset>\n            <p>\n                This wizard allows you to create a website from an existing theme. If you'd like to create a more complex\n                website please use the commandline tool `percli create project &lt;name&gt;` to create a website managed as a\n                full project.\n            </p>\n        </tab-content>\n        <tab-content v-if=\"colorPalettes && colorPalettes.length > 0\" title=\"choose color palette\">\n            <admin-components-colorpaletteselector\n                :palettes=\"colorPalettes\"\n                :template-path=\"formmodel.templatePath\"\n                @select=\"onColorPaletteSelect\"/>\n        </tab-content>\n        <tab-content title=\"choose name\" :before-change=\"leaveTabTwo\">\n            <vue-form-generator\n              :model   =\"formmodel\"\n              :schema  =\"nameSchema\"\n              :options =\"formOptions\"\n              ref      =\"nameTab\">\n            </vue-form-generator>\n        </tab-content>\n        <tab-content title=\"verify\">\n            Creating Site `{{formmodel.name}}` from existing theme `{{formmodel.templatePath}}`\n        </tab-content>\n        <span v-if=\"isLastStep\" slot=\"custom-buttons-right\" role=\"button\">\n            <button type=\"button\" class=\"wizard-btn outline\" @click=\"onComplete(false)\">\n                Create\n           </button>\n        </span>\n        <span slot=\"finish\" role=\"button\" tabindex=\"0\">\n            <button tabindex=\"-1\" type=\"button\" class=\"wizard-btn finish\">\n            Create and Edit!\n            </button>\n        </span>\n    </form-wizard>\n</div>\n</template>\n\n<script>\n    export default {\n        props: ['model'],\n        data:\n            function() {\n                return {\n                    isLastStep: false,\n                    reloadKey: 0,\n                    colorPalettes: [],\n                    formErrors: {\n                        unselectedThemeError: false\n                    },\n                    formmodel: {\n                        path: $perAdminApp.getNodeFromView('/state/tools/pages'),\n                        name: '',\n                        title: '',\n                        tenantUserPwd: '',\n                        templatePath: ''\n                    },\n                    formOptions: {\n                        validationErrorClass: \"has-error\",\n                        validationSuccessClass: \"has-success\",\n                        validateAfterChanged: true,\n                        focusFirstField: true\n                    },\n                    nameChanged: false,\n                    nameSchema: {\n                        fields: [\n                            {\n                                type: \"input\",\n                                inputType: \"text\",\n                                label: \"Site Title\",\n                                model: \"title\",\n                                required: true,\n                                onChanged: (model, newVal, oldVal, field) => {\n                                  if(!this.nameChanged) {\n                                      this.formmodel.name = $perAdminApp.normalizeString(newVal, '_');\n                                  }\n                                }\n                            },\n                            {\n                                type: \"input\",\n                                inputType: \"text\",\n                                label: \"Site Name\",\n                                model: \"name\",\n                                required: true,\n                                onChanged: (model, newVal, oldVal, field) => {\n                                    this.nameChanged = true;\n                                },\n                                validator: [this.nameAvailable, this.validSiteName]\n                            },\n                            {\n                                type: \"input\",\n                                inputType: \"text\",\n                                label: \"Tenant User Password\",\n                                model: \"tenantUserPwd\",\n                                required: false,\n                                onChanged: (model, newVal, oldVal, field) => {\n                                }\n                            }\n                        ]\n                    }\n                }\n\n        },\n        created: function() {\n            //By default select the first item in the list;\n            this.selectTheme(this, this.themes[0].name);\n        },\n        computed: {\n            pageSchema: function() {\n            },\n            themes: function() {\n                const themes = $perAdminApp.getView().admin.tenants\n                return themes.filter( (item) => {\n                    return item.template === true;\n                })\n            }\n        },\n        methods: {\n            selectTheme: function(me, target){\n                if(me === null) me = this;\n                me.formmodel.templatePath = target;\n                me.formmodel.colorPalette = null\n                me.colorPalettes = []\n                this.validateTabOne(me);\n                $perAdminApp.getApi().getPalettes(me.formmodel.templatePath).then((data) =>{\n                    if (data && data.children && data.children.length > 0) {\n                        me.colorPalettes = data.children.reverse()\n                    }\n                    me.reloadKey++\n                })\n            },\n            isSelected: function(target) {\n                return this.formmodel.templatePath === target\n            },\n            onComplete: function(edit = true) {\n                const payload = {\n                    fromName: this.formmodel.templatePath,\n                    toName: this.formmodel.name,\n                    title: this.formmodel.title,\n                    tenantUserPwd: this.formmodel.tenantUserPwd,\n                    editHome: edit\n                }\n\n                if (this.formmodel.colorPalette && this.formmodel.colorPalette.length > 0) {\n                    payload.colorPalette = this.formmodel.colorPalette\n                }\n                $perAdminApp.stateAction('createTenant', payload)\n            },\n            validateTabOne: function(me) {\n                me.formErrors.unselectedThemeError = ('' === '' + me.formmodel.templatePath);\n\n                return !me.formErrors.unselectedThemeError;\n            },\n            leaveTabOne: function() {\n                if('' !== ''+this.formmodel.templatePath) {\n//                    $perAdminApp.getApi().populateComponentDefinitionFromNode(this.formmodel.templatePath)\n                }\n\n                return this.validateTabOne(this);\n            },\n            nameAvailable(value) {\n                if(!value || value.length === 0) {\n                    return ['name is required']\n                } else {\n                    const folder = $perAdminApp.findNodeFromPath($perAdminApp.getView().admin.nodes, '/content')\n                    if(folder && folder.children) {\n                        for(let i = 0; i < folder.children.length; i++) {\n                            if(folder.children[i].name === value) {\n                                return ['name aready in use']\n                            }\n                        }\n                    }\n                    return []\n                }\n            },\n            validSiteName(value) {\n                if(!value || value.length === 0) {\n                    return ['name is required']\n                }\n                if(value.match(/[^0-9a-z_]/)) {\n                    return ['site names may only contain lowercase letters, numbers, and underscores']\n                }\n                return [];\n            },\n            leaveTabTwo: function() {\n                const isValid = this.$refs.nameTab.validate()\n                this.isLastStep = isValid\n                return isValid\n            },\n            changeTab: function(prev, next) {\n                if(next < prev) this.isLastStep = false\n            },\n            onColorPaletteSelect(colorPalette) {\n                this.formmodel.colorPalette = colorPalette\n            }\n        }\n    }\n</script>\n\n<style scoped>\n    .feature-unavailable {\n        display: flex;\n        justify-content: center;\n    }\n\n    .feature-unavailable .card{\n        max-width: 700px;\n    }\n</style>"]}, media: undefined });

      };
      /* scoped */
      var __vue_scope_id__ = "data-v-66469dfc";
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        browser,
        undefined
      );

    return template;

}());
