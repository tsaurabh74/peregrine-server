var cmpAdminComponentsColorpaletteselector = (function () {
  'use strict';

  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //
  //

  var script = {
    props: {
      templatePath: {
        type: String,
        required: true
      },
      palettes: {
        type: Array,
        required: true
      }
    },
    data: function data() {
      return {
        selectedPath: null,
        themes: ['light', 'dark', 'none'],
        colors: [
          {
            label: 'primary background color',
            var: 'bg-primary',
            text: 'var(--text-primary-color)'
          },
          {
            label: 'secondary background color',
            var: 'bg-secondary',
            text: 'var(--text-secondary-color)'
          },
          {
            label: 'primary text color',
            var: 'text-primary-color',
            text: 'var(--bg-primary)'
          },
          {
            label: 'secondary text color',
            var: 'text-secondary-color',
            text: 'var(--bg-secondary)'
          },
          {
            label: 'primary border color',
            var: 'border-primary-color',
            text: 'var(--text-primary-color)'
          }
        ]
      }
    },
    mounted: function mounted() {
      if (this.palettes && this.palettes.length > 0) {
        this.onSelect(this.palettes[0]);
      }
    },
    methods: {
      onSelect: function onSelect(palette) {
        this.selectedPath = palette.path;
        this.$emit('select', this.selectedPath);
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  var isOldIE = typeof navigator !== 'undefined' && /msie [6-9]\\b/.test(navigator.userAgent.toLowerCase());
  function createInjector(context) {
    return function (id, style) {
      return addStyle(id, style);
    };
  }
  var HEAD = document.head || document.getElementsByTagName('head')[0];
  var styles = {};

  function addStyle(id, css) {
    var group = isOldIE ? css.media || 'default' : id;
    var style = styles[group] || (styles[group] = {
      ids: new Set(),
      styles: []
    });

    if (!style.ids.has(id)) {
      style.ids.add(id);
      var code = css.source;

      if (css.map) {
        // https://developer.chrome.com/devtools/docs/javascript-debugging
        // this makes source maps inside style tags work properly in Chrome
        code += '\n/*# sourceURL=' + css.map.sources[0] + ' */'; // http://stackoverflow.com/a/26603875

        code += '\n/*# sourceMappingURL=data:application/json;base64,' + btoa(unescape(encodeURIComponent(JSON.stringify(css.map)))) + ' */';
      }

      if (!style.element) {
        style.element = document.createElement('style');
        style.element.type = 'text/css';
        if (css.media) { style.element.setAttribute('media', css.media); }
        HEAD.appendChild(style.element);
      }

      if ('styleSheet' in style.element) {
        style.styles.push(code);
        style.element.styleSheet.cssText = style.styles.filter(Boolean).join('\n');
      } else {
        var index = style.ids.size - 1;
        var textNode = document.createTextNode(code);
        var nodes = style.element.childNodes;
        if (nodes[index]) { style.element.removeChild(nodes[index]); }
        if (nodes.length) { style.element.insertBefore(textNode, nodes[index]); }else { style.element.appendChild(textNode); }
      }
    }
  }

  var browser = createInjector;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", [
      _c("div", { staticClass: "palette-stylsheet-wrapper" }, [
        _c("link", {
          attrs: {
            rel: "stylesheet",
            href: "/etc/felibs/" + this.templatePath + "/css/colors.css",
            type: "text/css"
          }
        }),
        _vm._v(" "),
        _c("link", {
          attrs: {
            rel: "stylesheet",
            href: "/content/" + this.templatePath + "/pages/css/commons.css",
            type: "text/css"
          }
        }),
        _vm._v(" "),
        _c("link", {
          attrs: { rel: "stylesheet", href: _vm.selectedPath, type: "text/css" }
        })
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "row" }, [
        _c("div", { staticClass: "col s12 m4 l4" }, [
          _c("label", [_vm._v("Select Color Palette")]),
          _vm._v(" "),
          _c(
            "ul",
            { staticClass: "collection" },
            _vm._l(_vm.palettes, function(palette) {
              return _c(
                "li",
                {
                  key: palette.name,
                  staticClass: "collection-item",
                  class: { active: _vm.selectedPath === palette.path },
                  on: {
                    click: function($event) {
                      $event.stopPropagation();
                      $event.preventDefault();
                      return _vm.onSelect(palette)
                    }
                  }
                },
                [_vm._v("\n          " + _vm._s(palette.name) + "\n        ")]
              )
            }),
            0
          )
        ]),
        _vm._v(" "),
        _c("div", { staticClass: "col s12 m8 l8" }, [
          _c(
            "div",
            { staticClass: "palette-previews", attrs: { id: "peregrine-app" } },
            [
              _vm._l(_vm.themes, function(theme) {
                return [
                  _c("label", { key: theme, staticClass: "theme-name" }, [
                    _vm._v(_vm._s(theme))
                  ]),
                  _vm._v(" "),
                  _c(
                    "div",
                    {
                      key: "theme-" + theme,
                      staticClass: "theme-preview",
                      class: "theme-" + theme
                    },
                    _vm._l(_vm.colors, function(color, idx) {
                      return _c(
                        "div",
                        {
                          key: idx,
                          staticClass: "palette-col",
                          style: {
                            background: "var(--" + color.var + ")",
                            color: color.text
                          },
                          attrs: { title: color.label }
                        },
                        [
                          _vm._v(
                            "\n              " +
                              _vm._s(color.label) +
                              "\n            "
                          )
                        ]
                      )
                    }),
                    0
                  )
                ]
              })
            ],
            2
          )
        ])
      ])
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = function (inject) {
      if (!inject) { return }
      inject("data-v-2935dee0_0", { source: "\n.palette-previews .theme-name[data-v-2935dee0] {\n  /* text-transform: uppercase; */\n  text-align: center;\n}\n.palette-previews .theme-preview[data-v-2935dee0] {\n  display: flex;\n  border: 1px solid #000000;\n  border-left-width: 0;\n  /* height: 150px; */\n  text-align: center;\n}\n.palette-previews .theme-preview > .palette-col[data-v-2935dee0] {\n  border-left: 1px solid #000000;\n  display: flex;\n  flex: 1;\n  justify-content: center;\n  align-content: center;\n  flex-direction: column;\n  padding: 1rem;\n}\n", map: {"version":3,"sources":["/home/rr/projects/release/peregrine-cms/admin-base/ui.apps/src/main/content/jcr_root/apps/admin/components/colorpaletteselector/template.vue"],"names":[],"mappings":";AAmIA;EACA,+BAAA;EACA,kBAAA;AACA;AAEA;EACA,aAAA;EACA,yBAAA;EACA,oBAAA;EACA,mBAAA;EACA,kBAAA;AACA;AAEA;EACA,8BAAA;EACA,aAAA;EACA,OAAA;EACA,uBAAA;EACA,qBAAA;EACA,sBAAA;EACA,aAAA;AACA","file":"template.vue","sourcesContent":["<!--\n  #%L\n  admin base - UI Apps\n  %%\n  Copyright (C) 2017 headwire inc.\n  %%\n  Licensed to the Apache Software Foundation (ASF) under one\n  or more contributor license agreements.  See the NOTICE file\n  distributed with this work for additional information\n  regarding copyright ownership.  The ASF licenses this file\n  to you under the Apache License, Version 2.0 (the\n  \"License\"); you may not use this file except in compliance\n  with the License.  You may obtain a copy of the License at\n  \n  http://www.apache.org/licenses/LICENSE-2.0\n  \n  Unless required by applicable law or agreed to in writing,\n  software distributed under the License is distributed on an\n  \"AS IS\" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY\n  KIND, either express or implied.  See the License for the\n  specific language governing permissions and limitations\n  under the License.\n  #L%\n  -->\n<template>\n  <div>\n    <div class=\"palette-stylsheet-wrapper\">\n      <link rel=\"stylesheet\"\n            :href=\"`/etc/felibs/${this.templatePath}/css/colors.css`\"\n            type=\"text/css\"/>\n      <link rel=\"stylesheet\"\n            :href=\"`/content/${this.templatePath}/pages/css/commons.css`\"\n            type=\"text/css\"/>\n      <link rel=\"stylesheet\"\n            :href=\"selectedPath\"\n            type=\"text/css\"/>\n    </div>\n    <div class=\"row\">\n      <div class=\"col s12 m4 l4\">\n        <label>Select Color Palette</label>\n        <ul class=\"collection\">\n          <li class=\"collection-item\"\n              v-for=\"palette in palettes\"\n              v-bind:key=\"palette.name\"\n              :class=\"{active: selectedPath === palette.path}\"\n              @click.stop.prevent=\"onSelect(palette)\">\n            {{ palette.name }}\n          </li>\n        </ul>\n      </div>\n      <div class=\"col s12 m8 l8\">\n        <div class=\"palette-previews\" id=\"peregrine-app\">\n          <template v-for=\"theme in themes\">\n            <label class=\"theme-name\" :key=\"theme\">{{ theme }}</label>\n            <div class=\"theme-preview\" :key=\"`theme-${theme}`\" :class=\"`theme-${theme}`\">\n              <div v-for=\"(color, idx) in colors\"\n                  :key=\"idx\"\n                  :style=\"{background: `var(--${color.var})`, color: color.text}\"\n                  :title=\"color.label\"\n                  class=\"palette-col\">\n                {{ color.label }}\n              </div>\n            </div>\n          </template>\n        </div>\n      </div>\n    </div>\n\n  </div>\n</template>\n\n<script>\n  export default {\n    props: {\n      templatePath: {\n        type: String,\n        required: true\n      },\n      palettes: {\n        type: Array,\n        required: true\n      }\n    },\n    data() {\n      return {\n        selectedPath: null,\n        themes: ['light', 'dark', 'none'],\n        colors: [\n          {\n            label: 'primary background color',\n            var: 'bg-primary',\n            text: 'var(--text-primary-color)'\n          },\n          {\n            label: 'secondary background color',\n            var: 'bg-secondary',\n            text: 'var(--text-secondary-color)'\n          },\n          {\n            label: 'primary text color',\n            var: 'text-primary-color',\n            text: 'var(--bg-primary)'\n          },\n          {\n            label: 'secondary text color',\n            var: 'text-secondary-color',\n            text: 'var(--bg-secondary)'\n          },\n          {\n            label: 'primary border color',\n            var: 'border-primary-color',\n            text: 'var(--text-primary-color)'\n          }\n        ]\n      }\n    },\n    mounted() {\n      if (this.palettes && this.palettes.length > 0) {\n        this.onSelect(this.palettes[0])\n      }\n    },\n    methods: {\n      onSelect(palette) {\n        this.selectedPath = palette.path\n        this.$emit('select', this.selectedPath)\n      }\n    }\n  }\n</script>\n\n<style scoped>\n  .palette-previews .theme-name {\n    /* text-transform: uppercase; */\n    text-align: center;\n  }\n\n  .palette-previews .theme-preview {\n    display: flex;\n    border: 1px solid #000000;\n    border-left-width: 0;\n    /* height: 150px; */\n    text-align: center;\n  }\n\n  .palette-previews .theme-preview > .palette-col {\n    border-left: 1px solid #000000;\n    display: flex;\n    flex: 1;\n    justify-content: center;\n    align-content: center;\n    flex-direction: column;\n    padding: 1rem;\n  }\n</style>\n"]}, media: undefined });

    };
    /* scoped */
    var __vue_scope_id__ = "data-v-2935dee0";
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      browser,
      undefined
    );

  return template;

}());
