var cmpAdminComponentsLogo = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model']
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c(
        "svg",
        {
          staticStyle: { "enable-background": "new 0 0 500 500" },
          attrs: {
            version: "1.1",
            xmlns: "http://www.w3.org/2000/svg",
            "xmlns:xlink": "http://www.w3.org/1999/xlink",
            x: "0px",
            y: "0px",
            viewBox: "0 0 500 500",
            "xml:space": "preserve"
          }
        },
        [
          _c("g", [
            _c("path", {
              staticClass: "st0",
              attrs: {
                d:
                  "M0.4,249.9c0,137.8,111.7,249.6,249.6,249.6c137.8,0,249.6-111.7,249.6-249.6C499.5,112,387.8,0.3,250,0.3\n            C112.1,0.3,0.4,112,0.4,249.9z M38.1,249.9C38.1,132.9,133,38,250,38s211.8,94.8,211.8,211.8S367,461.7,250,461.7\n            S38.1,366.9,38.1,249.9z"
              }
            })
          ]),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d:
                "M207.7,38c0,0,127.7,35.5,177.9,164.8c0,0,4.7,13.8-2.5,15.4c-7.2,1.7-21.7,3.6-21.7,3.6s10.5-7.4,6.9-16.8\n        c-3.6-9.4-63.9-132.4-223.6-156.7"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d:
                "M95.4,90.6c0,0,34.7-10.1,98.3,39.4c0,0,3-1.1,3-6.1c0-5,0.8-11.6,6.9-14l59.2,63.3c0,0-11-33.6-54.8-72.7\n        c0,0,48.7,22.3,69.4,60.8c20.6,38.5,25.9,49,58.6,58.9c0,0-28.9,5.5-52.6-5.8c0,0-22.3,11.6-50.1-1.7\n        c-27.8-13.2-117-81.8-215.8-13.8l46.3-95L95.4,90.6z"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d:
                "M380.4,231.5c0,0,35.2,77.4-21.8,133c0,0-8-46-81.8-101c0,0,11-2.2-1.1-8.8c-12.1-6.6-47.3-20.1-82.9-19.8\n        c-35.5,0.3-106.1,9.6-102.2,171.6l51.1,39c0,0-24.7-58.7-17.4-124.4c7.4-65.7,66.5-68.9,81.5-67c14.9,1.9,106,8.7,145.6,145.6\n        C351.4,399.7,454.1,329.5,380.4,231.5z"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d: "M349.5,445.5c0,0-105.6,24.1-175.5-76.2c0,0,25.2,73.3,100.6,103.6"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d: "M234.3,466.7c0,0-90.1-56.4-86.3-138.3c0,0-17.8,65.6,31.8,138.3"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d: "M25.1,287.4c0,0,32.8-46.3,77.1-48.7c0,0-55.4,21.2-60.3,96.4"
            }
          }),
          _vm._v(" "),
          _c("path", {
            staticClass: "st0",
            attrs: {
              d:
                "M374.1,263.2c0,0-13.5-20.7-18.3-20.7c-4.8,0,5.8-11,5.8-11S377.9,247.3,374.1,263.2z"
            }
          }),
          _vm._v(" "),
          _c("g", [
            _c("path", {
              staticClass: "st0",
              attrs: {
                d:
                  "M1.3,249.9c0,137.8,111.7,249.6,249.6,249.6c137.8,0,249.6-111.7,249.6-249.6C500.4,112,388.7,0.3,250.9,0.3\n            C113,0.3,1.3,112,1.3,249.9z M39,249.9C39,132.9,133.9,38,250.9,38s211.8,94.8,211.8,211.8s-94.8,211.8-211.8,211.8\n            S39,366.9,39,249.9z"
              }
            })
          ])
        ]
      )
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
