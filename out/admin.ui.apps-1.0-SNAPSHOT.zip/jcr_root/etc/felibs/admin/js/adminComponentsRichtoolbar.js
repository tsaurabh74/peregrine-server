var cmpAdminComponentsRichtoolbar = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var PathBrowser = {
    Type: {
      PAGE: 'page',
      ASSET: 'asset',
      IMAGE: 'image',
      OBJECT: 'object'
    }
  };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  function set(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(vue) {
          Vue.set(node, path[0], value);
      }
      else {
          node[path[0]] = value;
      }
  }

  function get(node, path, value) {

      var vue = $perAdminApp.getApp();
      path = path.slice(1).split('/').reverse();
      while(path.length > 1) {
          var segment = path.pop();
          if(!node[segment]) {
              if(vue) {
                  Vue.set(node, segment, {});
              } else {
                  node[segment] = {};
              }
          }
          node = node[segment];
      }
      if(value !== undefined && !node[path[0]]) {
          if(vue) {
              Vue.set(node, path[0], value);
          } else {
              node[path[0]] = value;
          }
      }
      return node[path[0]]
  }

  var saveSelection = function (containerEl, document) {
    if ( document === void 0 ) document=document;

    var window = document.defaultView;
    if (window.getSelection && document.createRange) {
      var range = window.getSelection().getRangeAt(0);
      var preSelectionRange = range.cloneRange();
      preSelectionRange.selectNodeContents(containerEl);
      preSelectionRange.setEnd(range.startContainer, range.startOffset);
      var start = preSelectionRange.toString().length;

      return {
        start: start,
        end: start + range.toString().length
      }
    } else if (document.selection) {
      var selectedTextRange = document.selection.createRange();
      var preSelectionTextRange = document.body.createTextRange();
      preSelectionTextRange.moveToElementText(containerEl);
      preSelectionTextRange.setEndPoint('EndToStart', selectedTextRange);
      var start$1 = preSelectionTextRange.text.length;

      return {
        start: start$1,
        end: start$1 + selectedTextRange.text.length
      }
    }
  };

  var restoreSelection = function (containerEl, savedSel, doc) {
    if ( doc === void 0 ) doc = document;

    var win = doc.defaultView;

    if (win.getSelection && doc.createRange) {
      var charIndex = 0, range = doc.createRange();
      range.setStart(containerEl, 0);
      range.collapse(true);
      var nodeStack = [containerEl], node, foundStart = false, stop = false;

      while (!stop && (node = nodeStack.pop())) {
        if (node.nodeType === 3) {
          var nextCharIndex = charIndex + node.length;
          if (!foundStart && savedSel.start >= charIndex && savedSel.start
              <= nextCharIndex) {
            range.setStart(node, savedSel.start - charIndex);
            foundStart = true;
          }
          if (foundStart && savedSel.end >= charIndex && savedSel.end
              <= nextCharIndex) {
            range.setEnd(node, savedSel.end - charIndex);
            stop = true;
          }
          charIndex = nextCharIndex;
        } else {
          var i = node.childNodes.length;
          while (i--) {
            nodeStack.push(node.childNodes[i]);
          }
        }
      }

      var sel = win.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    } else if (doc.selection) {
      var textRange = doc.body.createTextRange();
      textRange.moveToElementText(containerEl);
      textRange.collapse(true);
      textRange.moveEnd('character', savedSel.end);
      textRange.moveStart('character', savedSel.start);
      textRange.select();
    }
  };

  //

  var script = {
    name: 'RichToolbar',
    props: {
      showViewportBtn: {
        type: Boolean,
        default: true
      },
      showPreviewBtn: {
        type: Boolean,
        default: true
      }
    },
    data: function data() {
      return {
        key: 0,
        selection: {
          restore: false,
          buffer: null,
          doc: null,
          container: null,
          content: null
        },
        param: {
          cmd: null,
          value: null
        },
        browser: {
          element: null,
          open: false,
          header: '',
          root: '',
          type: 'image',
          withLinkTab: false,
          newWindow: false,
          linkTitle: '',
          path: {
            current: '',
            selected: null
          }
        }
      }
    },
    computed: {
      btns: function btns() {
        var this$1 = this;

        var btns = {
          alwaysActives: [],
          actions: [
            {title: 'undo', icon: 'undo', cmd: 'undo'},
            {title: 'redo', icon: 'repeat', cmd: 'redo'}
          ],
          textFormat: [
            {
              title: 'text format',
              icon: 'paragraph',
              items: this.formattingItems,
              isActive: this.formattingIsActive
            }
          ],
          boldItalic: [
            {
              title: 'bold',
              icon: 'bold',
              cmd: 'bold',
              isActive: function () { return this$1.queryCmdState('bold'); }
            },
            {
              title: 'italic',
              icon: 'italic',
              cmd: 'italic',
              isActive: function () { return this$1.queryCmdState('italic'); }
            }
          ],
          superSub: [
            {
              title: 'superscript',
              label: 'A<sup>2</sup>',
              cmd: 'superscript',
              isActive: function () { return this$1.itemIsTag('SUP'); }
            },
            {
              title: 'subscript',
              label: 'A<sub>2</sub>',
              cmd: 'subscript',
              isActive: function () { return this$1.itemIsTag('SUB'); }
            }
          ],
          link: [
            {
              title: function () { return this$1.itemIsTag('A') ? 'edit/remove link' : 'insert link'; },
              icon: 'link',
              cmd: 'link',
              items: function () { return this$1.itemIsTag('A') ? this$1.linkItems : null; },
              isActive: function () { return this$1.itemIsTag('A'); }
            }
          ],
          image: [
            {title: 'insert image', icon: 'picture-o', cmd: 'insertImage'}
          ],
          align: [
            {
              title: 'align left',
              icon: 'align-left',
              cmd: 'justifyLeft',
              isActive: function () { return this$1.queryCmdState('justifyLeft'); }
            },
            {
              title: 'align center',
              icon: 'align-center',
              cmd: 'justifyCenter',
              isActive: function () { return this$1.queryCmdState('justifyCenter'); }
            },
            {
              title: 'align right',
              icon: 'align-right',
              cmd: 'justifyRight',
              isActive: function () { return this$1.queryCmdState('justifyRight'); }
            },
            {
              title: 'justify',
              icon: 'align-justify',
              cmd: 'justifyFull',
              isActive: function () { return this$1.queryCmdState('justifyFull'); }
            }
          ],
          list: [
            {
              title: 'numbered list',
              icon: 'list-ol',
              cmd: 'insertOrderedList',
              isActive: function () { return this$1.queryCmdState('insertOrderedList'); }
            },
            {
              title: 'bulleted list',
              icon: 'list-ul',
              cmd: 'insertUnorderedList',
              isActive: function () { return this$1.queryCmdState('insertUnorderedList'); }
            }
          ],
          removeFormat: [
            {
              title: 'remove format',
              icon: 'format_clear',
              iconLib: 'material-icons',
              cmd: 'removeFormat'
            }
          ]
        };
        if (this.showPreviewBtn) {
          btns.alwaysActives.push({
            title: 'preview',
            icon: 'visibility',
            iconLib: 'material-icons',
            cmd: 'preview',
            class: 'always-active',
            isActive: function () { return this$1.preview === 'preview'; }
          });
          btns.alwaysActives.push({
            title: 'preview in new tab',
            icon: 'open_in_new',
            iconLib: 'material-icons',
            cmd: 'previewInNewTab',
            class: 'always-active separate',
            isActive: function () { return false; }
          });
        }
        if (this.showViewportBtn) {
          btns.alwaysActives.push({
            title: 'change viewport',
            icon: this.viewportIcon,
            iconLib: 'material-icons',
            items: this.viewportItems,
            class: 'always-active separate'
          });
        }
        Object.keys(btns).forEach(function (group) {
          btns[group].forEach(function (btn) {
            if (!btn.isActive) {
              btn.isActive = function () { return null; };
            }
          });
        });

        return btns
      },
      inline: function inline() {
        if (!$perAdminApp.getView() || !$perAdminApp.getView().state) { return null }
        return $perAdminApp.getView().state.inline
      },
      inlineRich: function inlineRich() {
        if (!this.inline) { return null }
        return this.inline.rich
      },
      viewport: function viewport() {
        return $perAdminApp.getNodeFromViewOrNull('/state/tools/workspace/view')
      },
      preview: function preview() {
        return $perAdminApp.getNodeFromViewOrNull('/state/tools/workspace/preview')
      },
      roots: function roots() {
        return $perAdminApp.getNodeFromViewOrNull('/state/tenant/roots')
      },
      specialCases: function specialCases() {
        return {
          link: this.link,
          insertImage: this.insertImage,
          editImage: this.editImage,
          preview: this.togglePreview,
          previewInNewTab: this.previewInNewTab
        }
      },
      formattingItems: function formattingItems() {
        var this$1 = this;

        var headlines = [];
        var loop = function ( i ) {
          headlines.push({
            label: ((this$1.$i18n('headline')) + " " + i),
            icon: 'title',
            class: function () { return this$1.itemIsTag(("H" + i)) ? 'active' : null; },
            click: function () { return this$1.exec('formatBlock', ("h" + i)); },
          });
        };

        for (var i = 1; i <= 6; i++) loop( i );
        return [
          {
            label: this.$i18n('paragraph'),
            icon: 'format_textdirection_l_to_r',
            class: function () { return this$1.itemIsTag('P') ? 'active' : null; },
            click: function () { return this$1.exec('formatBlock', 'p'); }
          } ].concat( headlines
        )
      },
      viewportItems: function viewportItems() {
        var this$1 = this;

        return [
          {
            id: 'mobile',
            label: this.$i18n('mobile'),
            icon: 'phone_android',
            class: function () { return this$1.viewport === 'mobile' ? 'active' : null; },
            click: function () { return this$1.setViewport('mobile'); }
          },
          {
            id: 'mobile-landscape',
            label: this.$i18n('mobile-landscape'),
            icon: 'stay_current_landscape',
            class: function () { return this$1.viewport === 'mobile-landscape' ? 'active' : null; },
            click: function () { return this$1.setViewport('mobile-landscape'); }
          },
          {
            id: 'tablet',
            label: this.$i18n('tablet'),
            icon: 'tablet_android',
            class: function () { return this$1.viewport === 'tablet' ? 'active' : null; },
            click: function () { return this$1.setViewport('tablet'); }
          },
          {
            id: 'tablet-landscape',
            label: this.$i18n('tablet-landscape'),
            icon: 'tablet',
            class: function () { return this$1.viewport === 'tablet-landscape' ? 'active' : null; },
            click: function () { return this$1.setViewport('tablet-landscape'); }
          },
          {
            id: 'laptop',
            label: this.$i18n('laptop'),
            icon: 'laptop_windows',
            class: function () { return this$1.viewport === 'laptop' ? 'active' : null; },
            click: function () { return this$1.setViewport('laptop'); }
          },
          {
            id: 'desktop',
            label: this.$i18n('desktop'),
            icon: 'desktop_windows',
            class: function () { return !this$1.viewport || this$1.viewport === 'desktop' ? 'active' : null; },
            click: function () { return this$1.setViewport('desktop'); }
          }
        ]
      },
      viewportIcon: function viewportIcon() {
        var this$1 = this;

        var currentItem = {};
        this.viewportItems.some(function (item) {
          if (item.id === this$1.viewport) {
            return currentItem = item
          }
        });
        return currentItem.icon || 'desktop_windows'
      },
      linkItems: function linkItems() {
        var this$1 = this;

        return [
          {
            label: this.$i18n('edit link'),
            icon: 'pencil',
            iconLib: 'font-awesome',
            click: function () { return this$1.editLink(); }
          },
          {
            label: this.$i18n('remove link'),
            icon: 'chain-broken',
            iconLib: 'font-awesome',
            click: function () { return this$1.removeLink(); }
          }
        ]
      }
    },
    methods: {
      pingRichToolbar: function pingRichToolbar(vm) {
        if ( vm === void 0 ) vm = this;

        vm.key = vm.key === 1 ? 0 : 1;
        $perAdminApp.action(vm, 'reWrapEditable');
      },
      getInlineDoc: function getInlineDoc() {
        if (!this.inline) { return null }
        return this.inline.doc
      },
      getInlineContainer: function getInlineContainer() {
        if (!this.getInlineDoc()) { return }
        return this.getInlineDoc().querySelector('.inline-edit.inline-editing')
      },
      execCmd: function execCmd(cmd, value, showUi) {
        if ( value === void 0 ) value = null;
        if ( showUi === void 0 ) showUi = false;

        if (!this.getInlineDoc() || !this.getInlineDoc().execCommand) { return }
        this.getInlineDoc().execCommand(cmd, showUi, value);
      },
      queryCmdState: function queryCmdState(cmd) {
        if (!this.getInlineDoc() || !this.getInlineDoc().queryCommandState) { return }
        return this.getInlineDoc().queryCommandState(cmd) || false
      },
      exec: function exec(cmd, value) {
        if ( value === void 0 ) value = null;

        if (Object.keys(this.specialCases).indexOf(cmd) >= 0) {
          this.specialCases[cmd](value);
        } else {
          this.execCmd(cmd, value);
        }
        this.pingRichToolbar();
      },
      link: function link() {
        if (!this.itemIsTag('A')) {
          this.insertLink();
        } else {
          this.removeLink();
        }
      },
      insertLink: function insertLink() {
        var selection = this.getSelection();
        if (!selection) { throw 'no selection found' }
        var range = selection.getRangeAt(0);
        if (!selection) { throw 'no selection-range found' }
        var len = range.endOffset - range.startOffset;
        var start = range.startOffset;
        var text = range.startContainer.textContent.substr(start, len);

        this.selection.content = range.startContainer.textContent.substr(start, len);

        this.param.cmd = 'createLink';
        this.browser.header = this.$i18n('Create Link');
        this.browser.path.current = this.roots.pages;
        this.browser.withLinkTab = true;
        this.browser.newWindow = false;
        this.browser.type = PathBrowser.Type.PAGE;
        this.saveSelection();
        this.selection.restore = true;
        this.startBrowsing();
      },
      editLink: function editLink() {
        var anchor;
        var document = this.getInlineDoc();
        if (!document || !document.defaultView) { return false }
        var window = document.defaultView;
        var selection = window.getSelection();
        if (!selection || selection.rangeCount <= 0) { return false }

        var range = document.createRange();
        range.setStart(selection.anchorNode, 0);
        range.setEnd(selection.anchorNode, selection.anchorNode.length);
        selection.removeAllRanges();
        selection.addRange(range);
        selection = selection.getRangeAt(0);

        if (selection.startContainer.parentNode.tagName === 'A') {
          anchor = selection.startContainer.parentNode;
        } else if (selection.endContainer.parentNode.tagName === 'A') {
          anchor = selection.endContainer.parentNode;
        }

        this.selection.content = anchor.innerHTML;
        var title = anchor.getAttribute('title');
        var target = anchor.getAttribute('target');
        var href = anchor.getAttribute('href');
        var hrefArr = href.substr(0, href.length - 5).split('/');
        this.param.cmd = 'editLink';
        this.browser.header = this.$i18n('Edit Link');
        this.browser.path.selected = hrefArr.join('/');
        hrefArr.pop();
        this.browser.path.current = hrefArr.join('/');
        this.browser.withLinkTab = true;
        this.browser.type = PathBrowser.Type.PAGE;
        this.browser.newWindow = target === '_blank';
        this.browser.linkTitle = title;
        this.browser.path.suffix = '.html';
        this.saveSelection();
        this.selection.restore = true;
        this.startBrowsing();
      },
      removeLink: function removeLink() {
        var this$1 = this;

        this.saveSelection();
        var document = this.getInlineDoc();
        if (!document || !document.defaultView) { return false }
        var window = document.defaultView;
        var selection = window.getSelection();
        if (!selection || selection.rangeCount <= 0) { return false }

        var range = document.createRange();
        range.setStart(selection.anchorNode, 0);
        range.setEnd(selection.anchorNode, selection.anchorNode.length);
        selection.removeAllRanges();
        selection.addRange(range);
        this.execCmd('unlink');
        this.selection.container.focus();
        this.selection.doc.body.focus();
        this.$nextTick(function () {
          this$1.restoreSelection();
        });
      },
      insertImage: function insertImage() {
        this.param.cmd = 'insertImage';
        this.browser.header = this.$i18n('Insert Image');
        this.browser.path.current = this.roots.assets;
        this.browser.withLinkTab = true;
        this.browser.newWindow = undefined;
        this.browser.type = PathBrowser.Type.ASSET;
        this.browser.path.suffix = '';
        this.saveSelection();
        this.selection.restore = true;
        this.startBrowsing();
      },
      editImage: function editImage(vm, target) {
        if ( vm === void 0 ) vm = this;

        var title = target.getAttribute('title');
        var src = target.getAttribute('src');
        var srcArr = src.split('/');
        vm.param.cmd = 'editImage';
        vm.browser.header = vm.$i18n('Edit Image');
        vm.browser.path.selected = srcArr.join('/');
        srcArr.pop();
        vm.browser.path.current = srcArr.join('/');
        vm.browser.withLinkTab = true;
        vm.browser.newWindow = undefined;
        vm.browser.type = PathBrowser.Type.ASSET;
        vm.browser.linkTitle = title;
        vm.browser.element = target;
        vm.startBrowsing();
      },
      setViewport: function setViewport(viewport) {
        set($perAdminApp.getView(), '/state/tools/workspace/view', viewport);
      },
      togglePreview: function togglePreview() {
        var view = $perAdminApp.getView();
        var current = get(view, '/state/tools/workspace/preview', null);
        $perAdminApp.stateAction('editPreview', current ? null : 'preview');
      },
      previewInNewTab: function previewInNewTab() {
        var view = $perAdminApp.getView();
        var page = get(view, '/pageView/path', null);
        window.open(page+'.html', 'viewer');
      },
      getButtonKey: function getButtonKey(btn, index) {
        var key = "btn-" + index + "-" + (btn.title);
        if (btn.isActive() !== null) {
          key += "-" + (this.key);
        }
        return key
      },
      itemIsTag: function itemIsTag(tagName) {
        var selection = this.getSelection(0);
        if (selection) {
          var start = selection.startContainer;
          var end = selection.endContainer;
          return (start && start.parentNode.tagName === tagName)
              || (end && end.parentNode.tagName === tagName)
        } else {
          return false
        }
      },
      formattingIsActive: function formattingIsActive() {
        var this$1 = this;

        var headlines = [];
        for (var i = 1; i <= 6; i++) {
          headlines.push(("H" + i));
        }
        var tags = ['P' ].concat( headlines);
        return tags.some(function (tag) { return this$1.itemIsTag(tag); })
      },
      startBrowsing: function startBrowsing() {
        var this$1 = this;

        $perAdminApp.getApi()
            .populateNodesForBrowser(this.browser.path.current, 'pathBrowser')
            .then(function () { return this$1.browser.open = true; })
            .catch(function (err) {
              $perAdminApp.getApi().populateNodesForBrowser('/content', 'pathBrowser');
            });
      },
      saveSelection: function saveSelection$1() {
        this.selection.buffer = saveSelection(this.getInlineContainer(), this.getInlineDoc());
        this.selection.doc = this.getInlineDoc();
        this.selection.container = this.getInlineContainer();
      },
      restoreSelection: function restoreSelection$1() {
        var this$1 = this;

        this.selection.doc.body.focus();
        this.selection.container.focus();
        this.$nextTick(function () {
          restoreSelection(this$1.selection.container, this$1.selection.buffer, this$1.selection.doc);
        });
      },
      onBrowserCancel: function onBrowserCancel() {
        this.browser.open = false;
        if (this.selection.restore) {
          this.restoreSelection();
          this.selection.restore = false;
        }
      },
      onBrowserSelect: function onBrowserSelect() {
        var this$1 = this;

        this.browser.open = false;

        if (this.selection.restore) {
          this.restoreSelection();
        }

        this.$nextTick(function () {
          if (['editLink', 'createLink'].includes(this$1.param.cmd)) {
            this$1.onLinkSelect();
            return;
          } else if (['insertImage', 'editImage'].includes(this$1.param.cmd)) {
            this$1.onImageSelect();
          }

          this$1.execCmd(this$1.param.cmd, this$1.param.value);
          this$1.param.cmd = null;
          this$1.param.value = null;
          this$1.browser.path.selected = null;
          this$1.browser.linkTitle = null;
          this$1.pingRichToolbar();

          if (this$1.selection.restore) {
            this$1.$nextTick(function () {
              this$1.restoreSelection();
              this$1.selection.restore = false;
            });
          }
        });
      },
      onLinkSelect: function onLinkSelect() {
        var this$1 = this;

        if (this.param.cmd === 'createLink') {
          if (this.browser.path.selected.startsWith('/')) {
            this.browser.path.selected += '.html';
          }

          var link = this.selection.doc.createElement('a');
          link.setAttribute('href', this.browser.path.selected);
          link.setAttribute('title', this.browser.linkTitle);
          link.setAttribute('target', this.browser.newWindow ? '_blank' : '_self');
          link.textContent = this.selection.content;
          this.restoreSelection();
          this.$nextTick(function () {
            var range = this$1.getSelection(0);
            range.deleteContents();
            range.insertNode(link);
            $perAdminApp.action(this$1, 'reWrapEditable');
            $perAdminApp.action(this$1, 'writeInlineToModel');
            this$1.$nextTick(function () {
              $perAdminApp.action(this$1, 'textEditorWriteToModel');
            });
          });
        } else {
          this.restoreSelection();
          this.$nextTick(function () {
            var selection = this$1.getSelection();
            var link = selection.focusNode.parentNode;
            link.setAttribute('href', this$1.browser.path.selected);
            link.setAttribute('title', this$1.browser.linkTitle);
            link.setAttribute('target', this$1.browser.newWindow ? '_blank' : '_self');
            link.textContent = this$1.selection.content;
            $perAdminApp.action(this$1, 'reWrapEditable');
            $perAdminApp.action(this$1, 'writeInlineToModel');
            this$1.$nextTick(function () {
              $perAdminApp.action(this$1, 'textEditorWriteToModel');
            });
          });
        }
      },
      onImageSelect: function onImageSelect() {
        var this$1 = this;

        if (this.param.cmd === 'editImage') {
          var imgEl = this.browser.element;
          var linkTitle = this.browser.linkTitle;
          imgEl.setAttribute('src', this.browser.path.selected);
          imgEl.setAttribute('alt', linkTitle ? linkTitle : '');
          imgEl.setAttribute('title', linkTitle ? linkTitle : '');
          $perAdminApp.action(this, 'reWrapEditable');
          $perAdminApp.action(this, 'writeInlineToModel');
          this.$nextTick(function () {
            $perAdminApp.action(this$1, 'textEditorWriteToModel');
          });
          this.browser.element = null;
        } else {
          this.param.cmd = 'insertHTML';
          this.param.value =
              "<img src=\"" + (this.browser.path.selected) + "\"\n                alt=\"" + (this.browser.linkTitle) + "\"\n                title=\"" + (this.browser.linkTitle) + "\"/>";
        }
      },
      setBrowserPathCurrent: function setBrowserPathCurrent(path) {
        this.browser.path.current = path;
      },
      setBrowserPathSelected: function setBrowserPathSelected(path) {
        this.browser.path.selected = path;
      },
      toggleBrowserNewWindow: function toggleBrowserNewWindow() {
        this.browser.newWindow = !this.browser.newWindow;
      },
      setBrowserLinkTitle: function setBrowserLinkTitle(event) {
        this.browser.linkTitle = event.target.value;
      },
      getSelection: function getSelection(index) {
        if ( index === void 0 ) index = null;

        var document = this.getInlineDoc();
        if (!document || !document.defaultView) { return false }
        var window = document.defaultView;
        var selection = window.getSelection();
        if (!selection || selection.rangeCount <= 0) { return false }
        if (index !== null && index >= 0) {
          selection = selection.getRangeAt(index);
        }

        return selection
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "div",
      {
        staticClass: "toolbar",
        class: { disabled: !_vm.inlineRich || _vm.preview === "preview" }
      },
      [
        _vm._l(_vm.btns, function(btnGroup, groupName) {
          return [
            btnGroup.length > 0
              ? _c(
                  "div",
                  { key: groupName, class: ["btn-group", "group-" + groupName] },
                  _vm._l(btnGroup, function(btn, i) {
                    return _c("admin-components-richtoolbarbtn", {
                      key: _vm.getButtonKey(btn, i),
                      class: btn.class,
                      attrs: {
                        items: btn.items,
                        icon: btn.icon,
                        "icon-lib": btn.iconLib,
                        label: btn.label,
                        title: _vm.$i18n(btn.title),
                        active: btn.isActive()
                      },
                      on: {
                        click: function($event) {
                          return _vm.exec(btn.cmd)
                        }
                      }
                    })
                  }),
                  1
                )
              : _vm._e()
          ]
        }),
        _vm._v(" "),
        _vm.browser.open
          ? _c("admin-components-pathbrowser", {
              attrs: {
                isOpen: _vm.browser.open,
                header: _vm.browser.header,
                browserRoot: _vm.browser.root,
                browserType: _vm.browser.type,
                withLinkTab: _vm.browser.withLinkTab,
                newWindow: _vm.browser.newWindow,
                toggleNewWindow: _vm.toggleBrowserNewWindow,
                linkTitle: _vm.browser.linkTitle,
                setLinkTitle: _vm.setBrowserLinkTitle,
                currentPath: _vm.browser.path.current,
                setCurrentPath: _vm.setBrowserPathCurrent,
                selectedPath: _vm.browser.path.selected,
                setSelectedPath: _vm.setBrowserPathSelected,
                onCancel: _vm.onBrowserCancel,
                onSelect: _vm.onBrowserSelect
              }
            })
          : _vm._e()
      ],
      2
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
