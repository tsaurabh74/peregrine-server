var cmpAdminComponentsNodetreeitem = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  /**
   * @enum {number}
   */
  var LogLevel = {
    OFF: 0,
    ERROR: 1,
    WARN: 2,
    INFO: 3,
    DEBUG: 4,
    FINE: 5,
  };

  var loggerFactoryInstance = null;

  var Logger = function Logger(name) {
        this.level = LogLevel.INFO;
        this.name = name;

        var displayName = "[" + name + "]";
        if(displayName.length > loggerFactoryInstance.getMaxNameLength()) {
            loggerFactoryInstance.setMaxNameLength(displayName.length);
        } else {
            displayName = displayName + repeatStr(' ',loggerFactoryInstance.getMaxNameLength() - displayName.length);
        }
        this.displayName = displayName;
    };

    Logger.prototype.setLevel = function setLevel (level) {
        this.level = level;
        return this
    };

    Logger.prototype.getDisplayName = function getDisplayName () {
        return this.displayName
    };

    Logger.prototype.setDisplayName = function setDisplayName (displayName) {
        this.displayName = displayName;
    };

    Logger.prototype.setLevelOff = function setLevelOff () {
        return this.setLevel(LogLevel.OFF)
    };

    Logger.prototype.setLevelError = function setLevelError () {
        return this.setLevel(LogLevel.ERROR)
    };

    Logger.prototype.setLevelWarn = function setLevelWarn () {
        return this.setLevel(LogLevel.WARN)
    };

    Logger.prototype.setLevelInfo = function setLevelInfo () {
        return this.setLevel(LogLevel.INFO)
    };

    Logger.prototype.setLevelDebug = function setLevelDebug () {
        return this.setLevel(LogLevel.DEBUG)
    };

    Logger.prototype.setLevelFine = function setLevelFine () {
        return this.setLevel(LogLevel.FINE)
    };

    Logger.prototype.applyTo = function applyTo (method, level, args) {
        if(typeof args[0] === 'string') {
            args[0] = level + ' ' + this.displayName + ' ' + args[0];
            method.apply(this, args);
        } else {
            args.unshift(this.displayName);
            args.unshift(level);
            method.apply(this, args);
        }
    };

    /* eslint-disable no-console */
    Logger.prototype.fine = function fine () {
        if(this.level < LogLevel.FINE) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[fine ]', args);
    };

    Logger.prototype.debug = function debug () {
        if(this.level < LogLevel.DEBUG) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[debug]', args);
    };

    Logger.prototype.info = function info () {
        if(this.level < LogLevel.INFO) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.log, '[info ]', args);
    };

    Logger.prototype.warn = function warn () {
        if(this.level < LogLevel.WARN) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.warn, '[warn ]', args);
    };

    Logger.prototype.error = function error () {
        if(this.level < LogLevel.ERROR) { return }
        var args = Array.prototype.slice.call(arguments);
        this.applyTo(console.error, '[error]', args);
    };

  function repeatStr(str, times) {
      var ret = "";
      for(var i = 0; i < times; i++) {
          ret += str;
      }
      return ret
  }

  var LoggerFactory = function LoggerFactory() {
        if(!loggerFactoryInstance) {
            loggerFactoryInstance = this;
            this.loggers = [];
        }
        return loggerFactoryInstance
    };

    LoggerFactory.prototype.getMaxNameLength = function getMaxNameLength () {
        return this.maxNameLength ? this.maxNameLength : 0
    };

    LoggerFactory.prototype.setMaxNameLength = function setMaxNameLength (length) {
        this.maxNameLength = length;
        for(var key in this.loggers) {
            var logger = this.loggers[key];
            var displayName = logger.getDisplayName();
            if(displayName.length < length) {
                logger.setDisplayName(displayName + repeatStr(' ',length - displayName.length));
            }
        }
    };

    LoggerFactory.logger = function logger (name) {
        return new LoggerFactory().getLogger(name)
    };

    LoggerFactory.getLoggers = function getLoggers () {
        return new LoggerFactory().loggers
    };

    LoggerFactory.prototype.getLogger = function getLogger (name) {
        var logger = this.loggers[name];
        if(!logger) {
            logger = new Logger(name);
            this.loggers[name] = logger;
        }
        return logger
    };

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */

  var logger = LoggerFactory.logger('utils').setLevelDebug();

  var capitalizeFirstLetter = function (str) {
      return str.charAt(0).toUpperCase() + str.slice(1);
  };

  //

  var script = {
    name: 'TreeItem',
    props: {
      item: Object,
      supportedResourceTypes: Array
    },
    data: function data() {
      return {
        isOpen: false
      }
    },
    computed: {
      expandIcon: function expandIcon() {
        return this.isOpen ? 'keyboard_arrow_down' : 'keyboard_arrow_right'
      },
      currentPath: function currentPath() {
        return $perAdminApp.getView().pageView.path || ''
      },
      isSelected: function isSelected() {
        return this.item.path === this.currentPath
      },
      section: function section() {
        return this.currentPath.split('/')[3] || null
      },
      sectionSingular: function sectionSingular() {
        return capitalizeFirstLetter(this.section.slice(0, -1)) || null
      },
      filteredChildren: function filteredChildren() {
        var this$1 = this;

        if (this.item.children) {
          return this.item.children.filter(function (ch) {
            return this$1.supportedResourceTypes.indexOf(ch.resourceType) >= 0
          })
        } else {
          return []
        }
      }
    },
    watch: {
      currentPath: function currentPath(newVal, oldVal) {
        this.initIsOpen();
      },
      'item.children': function item_children(newVal) {
        if (!newVal || newVal.length <= 0) {
          this.isOpen = false;
        }
      }
    },
    mounted: function mounted() {
      this.initIsOpen();
    },
    methods: {
      initIsOpen: function initIsOpen() {
        var currPathArr = this.currentPath.split('/');
        var pathArr = this.item.path.split('/');
        var partCurrPathArr = currPathArr.splice(0, pathArr.length);

        this.isOpen = !this.isSelected && partCurrPathArr.join('/') === this.item.path;
      },
      toggle: function toggle() {
        var this$1 = this;

        if (this.item.hasChildren) {
          if (!this.isOpen && (!this.item.children || this.item.children.length <= 0)) {
            this.loadChildren().then(function () {
              this$1.isOpen = !this$1.isOpen;
            });
          } else {
            this.isOpen = !this.isOpen;
          }
        }
      },
      editNode: function editNode() {
        if (!this.isSelected && this.section) {
          $perAdminApp.stateAction(("edit" + (this.sectionSingular)), this.item.path);
        }
        this.$emit('edit-node');
      },
      loadChildren: function loadChildren() {
        return $perAdminApp.stateAction('loadToolsNodesPath', {
          selected: this.item.path,
          path: '/state/tools/pages'
        })
      }
    }
  };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c(
      "li",
      {
        staticClass: "page-tree-item",
        class: { expandable: _vm.item.hasChildren, "is-open": _vm.isOpen }
      },
      [
        _c(
          "div",
          {
            staticClass: "title",
            class: { "is-selected": this.isSelected },
            on: {
              click: function($event) {
                $event.stopPropagation();
                return _vm.editNode($event)
              }
            }
          },
          [
            [
              _vm.item.hasChildren
                ? _c(
                    "i",
                    {
                      staticClass: "material-icons hover",
                      on: {
                        click: function($event) {
                          $event.stopPropagation();
                          $event.preventDefault();
                          return _vm.toggle($event)
                        }
                      }
                    },
                    [_vm._v("\n        " + _vm._s(_vm.expandIcon) + "\n      ")]
                  )
                : _c("i", { staticClass: "icon-placeholder" })
            ],
            _vm._v(" "),
            _c("i", { staticClass: "material-icons" }, [_vm._v("description")]),
            _vm._v("\n    " + _vm._s(_vm.item.name) + "\n  ")
          ],
          2
        ),
        _vm._v(" "),
        _vm.item.hasChildren
          ? _c(
              "ul",
              {
                directives: [
                  {
                    name: "show",
                    rawName: "v-show",
                    value: _vm.isOpen,
                    expression: "isOpen"
                  }
                ],
                staticClass: "content"
              },
              _vm._l(_vm.filteredChildren, function(child, index) {
                return _c("admin-components-nodetreeitem", {
                  key: "page-tree-item-" + child.path,
                  attrs: {
                    item: child,
                    "supported-resource-types": _vm.supportedResourceTypes
                  },
                  on: {
                    "edit-node": function($event) {
                      return _vm.$emit("edit-node")
                    }
                  }
                })
              }),
              1
            )
          : _vm._e()
      ]
    )
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
