var cmpAdminComponentsDebugger = (function () {
    'use strict';

    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //
    //

    var script = {
        props: ['model']
        ,
        beforeMount: function beforeMount() {
          this.selected = 'state';
        },
        computed: {
            jsonview: function() {
                if(this.selected) {
                    return JSON.stringify(this.$root.$data[this.selected], true, 2)
                }
                return JSON.stringify(this.$root.$data, true, 2)
            },
            elementStyle: function() {
                if(this.visible) {
                    return "visible"
                } else {
                    return ""
                }
            },
            consoleErrors: function() {
                return $perAdminApp.getView().admin.consoleErrors === true ? 'background-color: red;' : ''
            }

        },
        data: function() {
            if(!this.visible) {
                this.visible = false;
            }
            return { 
                visible: this.visible
            }
        },
        methods: {
            levelToName: function(level) {
                return ['off', 'error', 'warn', 'info', 'debug', 'fine'][level]
            },
            getLoggers: function() {
                var ret = [];
                var loggers = $perAdminApp.getLoggers();
                for(var key in loggers) {
                    ret.push({ name: loggers[key].name, level: loggers[key].level });
                }
                return ret
            },
            showDebugger: function(show) {
                this.visible = show;
            },
            select: function(name) {
                this.selected = name;
                this.$forceUpdate();
            },
            changeLogLevel: function(name) {
                var logger = $perAdminApp.getLogger(name);
                logger.level = ( logger.level + 1) % 6;
                this.$forceUpdate();
            }
        }
    };

    function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
    /* server only */
    , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
      if (typeof shadowMode !== 'boolean') {
        createInjectorSSR = createInjector;
        createInjector = shadowMode;
        shadowMode = false;
      } // Vue.extend constructor export interop.


      var options = typeof script === 'function' ? script.options : script; // render functions

      if (template && template.render) {
        options.render = template.render;
        options.staticRenderFns = template.staticRenderFns;
        options._compiled = true; // functional template

        if (isFunctionalTemplate) {
          options.functional = true;
        }
      } // scopedId


      if (scopeId) {
        options._scopeId = scopeId;
      }

      var hook;

      if (moduleIdentifier) {
        // server build
        hook = function hook(context) {
          // 2.3 injection
          context = context || // cached call
          this.$vnode && this.$vnode.ssrContext || // stateful
          this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
          // 2.2 with runInNewContext: true

          if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
            context = __VUE_SSR_CONTEXT__;
          } // inject component styles


          if (style) {
            style.call(this, createInjectorSSR(context));
          } // register component module identifier for async chunk inference


          if (context && context._registeredComponents) {
            context._registeredComponents.add(moduleIdentifier);
          }
        }; // used by ssr in case component is cached and beforeCreate
        // never gets called


        options._ssrRegister = hook;
      } else if (style) {
        hook = shadowMode ? function () {
          style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
        } : function (context) {
          style.call(this, createInjector(context));
        };
      }

      if (hook) {
        if (options.functional) {
          // register for functional component in vue file
          var originalRender = options.render;

          options.render = function renderWithStyleInjection(h, context) {
            hook.call(context);
            return originalRender(h, context);
          };
        } else {
          // inject component registration as beforeCreate hook
          var existing = options.beforeCreate;
          options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
        }
      }

      return script;
    }

    var normalizeComponent_1 = normalizeComponent;

    /* script */
    var __vue_script__ = script;

    /* template */
    var __vue_render__ = function() {
      var _vm = this;
      var _h = _vm.$createElement;
      var _c = _vm._self._c || _h;
      return _c("div", { class: "debugger " + _vm.elementStyle }, [
        !_vm.visible
          ? _c(
              "a",
              {
                staticClass: "toggle-debugger show-debugger",
                style: _vm.consoleErrors,
                attrs: { href: "#", title: _vm.$i18n("showDebugData") },
                on: {
                  click: function($event) {
                    $event.stopPropagation();
                    $event.preventDefault();
                    return _vm.showDebugger(true)
                  }
                }
              },
              [_c("i", { staticClass: "material-icons" }, [_vm._v("bug_report")])]
            )
          : _vm._e(),
        _vm._v(" "),
        _vm.visible
          ? _c(
              "a",
              {
                staticClass: "toggle-debugger hide-debugger",
                attrs: { href: "#", title: _vm.$i18n("hideDebugData") },
                on: {
                  click: function($event) {
                    $event.stopPropagation();
                    $event.preventDefault();
                    return _vm.showDebugger(false)
                  }
                }
              },
              [
                _c("i", { staticClass: "material-icons" }, [
                  _vm._v("highlight_off")
                ])
              ]
            )
          : _vm._e(),
        _vm._v(" "),
        _vm.visible
          ? _c("div", { staticClass: "debugger-content" }, [
              _c("div", { staticClass: "row" }, [
                _c("div", { staticClass: "col s12 m4 l3 debugger-levels" }, [
                  _c("h5", [_vm._v("Loggers")]),
                  _vm._v(" "),
                  _c(
                    "ul",
                    { staticClass: "collection" },
                    _vm._l(_vm.getLoggers(), function(logger, key) {
                      return _c(
                        "li",
                        { staticClass: "collection-item right-align" },
                        [
                          _c("span", { staticClass: "logger-name" }, [
                            _vm._v(_vm._s(logger.name) + ":")
                          ]),
                          _vm._v(" "),
                          _c(
                            "a",
                            {
                              staticClass: "logger-level",
                              attrs: {
                                title:
                                  _vm.$i18n("set") +
                                  " " +
                                  logger.name +
                                  " " +
                                  _vm.$i18n("loggingLevel") +
                                  ": " +
                                  _vm.levelToName(logger.level)
                              },
                              on: {
                                click: function($event) {
                                  $event.stopPropagation();
                                  $event.preventDefault();
                                  return _vm.changeLogLevel(logger.name)
                                }
                              }
                            },
                            [
                              _vm._v(
                                "\n                            " +
                                  _vm._s(_vm.levelToName(logger.level)) +
                                  "\n                        "
                              )
                            ]
                          )
                        ]
                      )
                    }),
                    0
                  )
                ]),
                _vm._v(" "),
                _c("div", { staticClass: "col s12 m8 l9 debugger-object-view" }, [
                  _c("h5", [_vm._v("Root Objects")]),
                  _vm._v(" "),
                  _c(
                    "ul",
                    { staticClass: "list-inline" },
                    _vm._l(this.$root.$data, function(value, key) {
                      return _c("li", [
                        _c(
                          "a",
                          {
                            class: _vm.selected === key ? "active" : "",
                            attrs: {
                              title:
                                _vm.$i18n("show") +
                                " '" +
                                key +
                                "' " +
                                _vm.$i18n("debugData")
                            },
                            on: {
                              click: function($event) {
                                $event.stopPropagation();
                                $event.preventDefault();
                                return _vm.select(key)
                              }
                            }
                          },
                          [_vm._v(_vm._s(key))]
                        )
                      ])
                    }),
                    0
                  ),
                  _vm._v(" "),
                  _c("code", [
                    _c("pre", [_vm._v(_vm._s(this.$root.$data[this.selected]))])
                  ])
                ])
              ])
            ])
          : _vm._e()
      ])
    };
    var __vue_staticRenderFns__ = [];
    __vue_render__._withStripped = true;

      /* style */
      var __vue_inject_styles__ = undefined;
      /* scoped */
      var __vue_scope_id__ = undefined;
      /* module identifier */
      var __vue_module_identifier__ = undefined;
      /* functional template */
      var __vue_is_functional_template__ = false;
      /* style inject */
      
      /* style inject SSR */
      

      
      var template = normalizeComponent_1(
        { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
        __vue_inject_styles__,
        __vue_script__,
        __vue_scope_id__,
        __vue_is_functional_template__,
        __vue_module_identifier__,
        undefined,
        undefined
      );

    return template;

}());
