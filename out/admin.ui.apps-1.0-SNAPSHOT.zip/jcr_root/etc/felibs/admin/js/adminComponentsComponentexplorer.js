var cmpAdminComponentsComponentexplorer = (function () {
  'use strict';

  /*-
   * #%L
   * admin base - UI Apps
   * %%
   * Copyright (C) 2017 headwire inc.
   * %%
   * Licensed to the Apache Software Foundation (ASF) under one
   * or more contributor license agreements.  See the NOTICE file
   * distributed with this work for additional information
   * regarding copyright ownership.  The ASF licenses this file
   * to you under the Apache License, Version 2.0 (the
   * "License"); you may not use this file except in compliance
   * with the License.  You may obtain a copy of the License at
   * 
   * http://www.apache.org/licenses/LICENSE-2.0
   * 
   * Unless required by applicable law or agreed to in writing,
   * software distributed under the License is distributed on an
   * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
   * KIND, either express or implied.  See the License for the
   * specific language governing permissions and limitations
   * under the License.
   * #L%
   */
  var IgnoreContainers = {
    ENABLED: 'ignore-containers',
    ON_HOLD: 'on-hold',
    DISABLED: ''
  };

  //

      var script = {
          props: ['model'],
  //        beforeCreate() {
  //            let perState = $perAdminApp.getNodeFromViewOrNull('/state');
  //            perState.componentExplorer = perState.componentExplorer || {
  //                accordion: {},
  //                filter: ""
  //            }
  //        },
  //
  //        data() {
  //            return {
  //                state: $perAdminApp.getNodeFromViewOrNull('/state/componentExplorer'),
  //            }
  //        },
          
  //        mounted() {
  //            $(this.$refs.groups).collapsible({
  //                accordion: false,
  //                onOpen: (el) => { Vue.set(this.state.accordion, el[0].dataset.groupIndex, true) },
  //                onClose: (el) => { Vue.set(this.state.accordion, el[0].dataset.groupIndex, false) }
  //            })
  //        },

  //        beforeDestroy() {
  //            $(this.$refs.groups).collapsible('destroy')
  //        },

          computed: {
              state: function state() {
                  var state = $perAdminApp.getNodeFromView('/state/componentExplorer');
                  if(state) {
                      return state
                  }
                  Vue.set($perAdminApp.getView().state, 'componentExplorer', {filter: '', group: ''});
                  return $perAdminApp.getNodeFromView('/state/componentExplorer')
              },
              filteredList: function() {
                  var this$1 = this;

                  var currentGroup = this.state.group;
                  if (!this.$root.$data.admin.components) { return {} }
                  // if(!this.$root.$data.admin.currentPageConfig) return {}
                  var componentPath = this.$root.$data.pageView.path.split('/');
                  var allowedComponents = ['/apps/' + componentPath[2]+ '/']; // this.$root.$data.admin.currentPageConfig.allowedComponents
                  var list = this.$root.$data.admin.components.data;
                  if (!list || !allowedComponents) { return {} }

                  var sorted = list.sort(function( left, right) {
                      var leftName = (left.group + '-' + left.title).toLowerCase();
                      var rightName = (right.group + '-' + right.title).toLowerCase();
                      if(leftName < rightName) { return -1; }
                      if(leftName > rightName) { return 1; }
                      return 0;
                  });

                  // Filter list to local components and with local filter
                  return sorted.filter(function (component) {
                      if (component.group === '.hidden') { return false; }
                      if((currentGroup && currentGroup !== '') && component.group !== currentGroup) { return false; }
                      if (component.title.toLowerCase().indexOf(this$1.state.filter.toLowerCase()) == -1) { return false; }
                      return component.path.startsWith(allowedComponents);

                  })
              },
              groupList: function() {
                  if (!this.$root.$data.admin.components) { return {} }
                  // if(!this.$root.$data.admin.currentPageConfig) return {}
                  var componentPath = this.$root.$data.pageView.path.split('/');
                  var allowedComponents = ['/apps/' + componentPath[2]]; // this.$root.$data.admin.currentPageConfig.allowedComponents
                  var list = this.$root.$data.admin.components.data;
                  if (!list || !allowedComponents) { return {} }

                  // Filter list to local components
                  var ret = list.filter(function (component) {
                      if (component.group === '.hidden') { return false; }
  //                    if (component.title.toLowerCase().indexOf(this.state.filter.toLowerCase()) == -1) return false;
                      return component.path.startsWith(allowedComponents);

                  });
                  return ret
              },
              groups: function () {
                  return this.filteredList.reduce( function ( obj, current ) {
                      if ( !current.group ) { current.group = 'General'; }
                      if ( !obj[ current.group ]) { Vue.set(obj, current.group, []); }
                      obj[ current.group ].push( current ); 
                      return obj;
                  }, {})
              },
              allGroups: function () {
                  var ret = this.groupList.reduce( function ( obj, current ) {
                      if ( !current.group ) { current.group = 'General'; }
                      if ( !obj[ current.group ]) { Vue.set(obj, current.group, []); }
                      obj[ current.group ].push( current );
                      return obj;
                  }, {});

                  // make sure the currently selected group is an actual group
                  if(!ret[this.state.group]) { this.state.group = '';}
                  return ret
              },
              isIgnoreContainersEnabled: function isIgnoreContainersEnabled() {
                  var view = $perAdminApp.getView();
                  return view.state.tools
                      && view.state.tools.workspace
                      && view.state.tools.workspace.ignoreContainers === IgnoreContainers.ENABLED;
              }
          },
          methods: {
              componentKey: function componentKey( component ) {
                  if(component.variation) {
                      return component.path+":"+component.variation
                  } else {
                      return component.path
                  }
              },
              isActive: function isActive( key, groupChildren) {
                  return (
                      this.state.accordion[ key ]
                  )
              },
              displayName: function displayName(component) {
                  if(component.title) {
                      return component.title
                  } else {
                      return component.path.split('/')[2] + ' ' + component.name
                  }
              },
              onDragStart: function(component, ev) {
                  if(ev) {
                      if(component.variation) {
                          ev.dataTransfer.setData('text', component.path+":"+component.variation);
                      } else {
                          ev.dataTransfer.setData('text', component.path);
                      }
                      var view = $perAdminApp.getView();
                      if (this.isIgnoreContainersEnabled) {
                          Vue.set(view.state.tools.workspace, 'ignoreContainers', IgnoreContainers.ON_HOLD);
                          Vue.set(view.pageView, 'view', view.state.tools.workspace.view);
                      }
                  }
              },
              onDragEnd: function(component, ev) {
                  var view = $perAdminApp.getView();
                  if (this.isIgnoreContainersEnabled) {
                      Vue.set(view.state.tools.workspace, 'ignoreContainers', IgnoreContainers.ENABLED);
                      Vue.set(view.pageView, 'view', IgnoreContainers.ENABLED);

                  }
              }
          }
      };

  function normalizeComponent(template, style, script, scopeId, isFunctionalTemplate, moduleIdentifier
  /* server only */
  , shadowMode, createInjector, createInjectorSSR, createInjectorShadow) {
    if (typeof shadowMode !== 'boolean') {
      createInjectorSSR = createInjector;
      createInjector = shadowMode;
      shadowMode = false;
    } // Vue.extend constructor export interop.


    var options = typeof script === 'function' ? script.options : script; // render functions

    if (template && template.render) {
      options.render = template.render;
      options.staticRenderFns = template.staticRenderFns;
      options._compiled = true; // functional template

      if (isFunctionalTemplate) {
        options.functional = true;
      }
    } // scopedId


    if (scopeId) {
      options._scopeId = scopeId;
    }

    var hook;

    if (moduleIdentifier) {
      // server build
      hook = function hook(context) {
        // 2.3 injection
        context = context || // cached call
        this.$vnode && this.$vnode.ssrContext || // stateful
        this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext; // functional
        // 2.2 with runInNewContext: true

        if (!context && typeof __VUE_SSR_CONTEXT__ !== 'undefined') {
          context = __VUE_SSR_CONTEXT__;
        } // inject component styles


        if (style) {
          style.call(this, createInjectorSSR(context));
        } // register component module identifier for async chunk inference


        if (context && context._registeredComponents) {
          context._registeredComponents.add(moduleIdentifier);
        }
      }; // used by ssr in case component is cached and beforeCreate
      // never gets called


      options._ssrRegister = hook;
    } else if (style) {
      hook = shadowMode ? function () {
        style.call(this, createInjectorShadow(this.$root.$options.shadowRoot));
      } : function (context) {
        style.call(this, createInjector(context));
      };
    }

    if (hook) {
      if (options.functional) {
        // register for functional component in vue file
        var originalRender = options.render;

        options.render = function renderWithStyleInjection(h, context) {
          hook.call(context);
          return originalRender(h, context);
        };
      } else {
        // inject component registration as beforeCreate hook
        var existing = options.beforeCreate;
        options.beforeCreate = existing ? [].concat(existing, hook) : [hook];
      }
    }

    return script;
  }

  var normalizeComponent_1 = normalizeComponent;

  /* script */
  var __vue_script__ = script;

  /* template */
  var __vue_render__ = function() {
    var _vm = this;
    var _h = _vm.$createElement;
    var _c = _vm._self._c || _h;
    return _c("div", { staticClass: "component-explorer" }, [
      _c("span", { staticClass: "panel-title" }, [
        _vm._v(_vm._s(_vm.$i18n("Components")))
      ]),
      _vm._v(" "),
      _c("input", {
        directives: [
          {
            name: "model",
            rawName: "v-model",
            value: _vm.state.filter,
            expression: "state.filter"
          }
        ],
        attrs: {
          type: "text",
          placeholder: _vm.$i18n("filterComponents"),
          tabindex: "1",
          autofocus: ""
        },
        domProps: { value: _vm.state.filter },
        on: {
          input: function($event) {
            if ($event.target.composing) {
              return
            }
            _vm.$set(_vm.state, "filter", $event.target.value);
          }
        }
      }),
      _vm._v(" "),
      _c(
        "select",
        {
          directives: [
            {
              name: "model",
              rawName: "v-model",
              value: _vm.state.group,
              expression: "state.group"
            }
          ],
          staticClass: "browser-default",
          on: {
            change: function($event) {
              var $$selectedVal = Array.prototype.filter
                .call($event.target.options, function(o) {
                  return o.selected
                })
                .map(function(o) {
                  var val = "_value" in o ? o._value : o.value;
                  return val
                });
              _vm.$set(
                _vm.state,
                "group",
                $event.target.multiple ? $$selectedVal : $$selectedVal[0]
              );
            }
          }
        },
        [
          _c("option", { attrs: { value: "" } }, [
            _vm._v(_vm._s(_vm.$i18n("allGroups")))
          ]),
          _vm._v(" "),
          _vm._l(_vm.allGroups, function(group, key) {
            return _c("option", { key: key, domProps: { value: key } }, [
              _vm._v(_vm._s(key))
            ])
          })
        ],
        2
      ),
      _vm._v(" "),
      _c(
        "ul",
        _vm._l(_vm.groups, function(group, key) {
          return _c("li", { key: key }, [
            _c("div", [
              _c(
                "ul",
                { staticClass: "collection" },
                _vm._l(group, function(component) {
                  return _c(
                    "li",
                    {
                      key: _vm.componentKey(component),
                      staticClass: "collection-item",
                      staticStyle: { cursor: "move" },
                      attrs: { draggable: "true" },
                      on: {
                        dragstart: function($event) {
                          return _vm.onDragStart(component, $event)
                        },
                        dragend: function($event) {
                          return _vm.onDragEnd(component, $event)
                        }
                      }
                    },
                    [
                      _c("div", [
                        _c("i", { staticClass: "material-icons" }, [
                          _vm._v("drag_handle")
                        ]),
                        _vm._v(" "),
                        _c("span", [_vm._v(_vm._s(_vm.displayName(component)))])
                      ]),
                      _vm._v(" "),
                      component.thumbnail
                        ? _c("img", { attrs: { src: component.thumbnail } })
                        : _vm._e()
                    ]
                  )
                }),
                0
              )
            ])
          ])
        }),
        0
      )
    ])
  };
  var __vue_staticRenderFns__ = [];
  __vue_render__._withStripped = true;

    /* style */
    var __vue_inject_styles__ = undefined;
    /* scoped */
    var __vue_scope_id__ = undefined;
    /* module identifier */
    var __vue_module_identifier__ = undefined;
    /* functional template */
    var __vue_is_functional_template__ = false;
    /* style inject */
    
    /* style inject SSR */
    

    
    var template = normalizeComponent_1(
      { render: __vue_render__, staticRenderFns: __vue_staticRenderFns__ },
      __vue_inject_styles__,
      __vue_script__,
      __vue_scope_id__,
      __vue_is_functional_template__,
      __vue_module_identifier__,
      undefined,
      undefined
    );

  return template;

}());
