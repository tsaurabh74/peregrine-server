<template>
    <hr class="hr"/>
</template>

<script>
    export default {
    }
</script>

<style scoped>
    .hr {
        width: 100%;
    }
</style>
