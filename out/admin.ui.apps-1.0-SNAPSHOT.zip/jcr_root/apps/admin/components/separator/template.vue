<template>
    <span class="separator"></span>
</template>

<script>
export default {
    props: ['model']
}
</script>

<style scoped>
    span.separator {
        border: 1px solid #ffffff;
        margin: 0 15px 0 10px;
        height: 25px;
        width: 0 !important;
        padding: 0 !important;
    }
</style>