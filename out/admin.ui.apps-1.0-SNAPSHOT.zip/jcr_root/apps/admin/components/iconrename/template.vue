<template>
    <i class="svg-icon">
        <svg 
            class="svg-content"
            version="1.1" 
            viewBox="0 0 24 24"
            preserveAspectRatio="xMinYMin meet">
            <path fill="none" stroke-width="2" stroke-miterlimit="10" d="M17 16h4V8h-4M12 8H3v8h9M6 12h5"/>
            <path fill="none" stroke-width="2" stroke-linejoin="round" stroke-miterlimit="10" d="M20 4h-2c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h2M12 20h2c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-2"/>
        </svg>
    </i>
</template>

<script>
    export default {}
</script>
