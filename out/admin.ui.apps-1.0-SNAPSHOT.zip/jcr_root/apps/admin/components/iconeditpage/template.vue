<template>
    <i class="svg-icon">
        <svg 
            class="svg-content"
            version="1.1" 
            viewBox="0 0 128 128" 
            preserveAspectRatio="xMinYMin meet">
            <path d="M100 109.5c0 3.6-2.9 6.5-6.5 6.5h-75c-3.6 0-6.5-2.9-6.5-6.5v-75c0-3.6 2.9-6.5 6.5-6.5h55.1l12-12H18.5C8.3 16 0 24.3 0 34.5v75C0 119.7 8.3 128 18.5 128h75c10.2 0 18.5-8.3 18.5-18.5V42.4l-12 12V109.5z"/><path d="M126.4 8.9l-7.2-7.3c-2.2-2.2-5.7-2.2-7.9 0L39.6 73.3 32 96l22.7-7.6 71.6-71.6C128.5 14.6 128.5 11 126.4 8.9z"/>
        </svg>
    </i>
</template>

<script>
    export default {}
</script>
